module.exports = {
    plugins: {
      autoprefixer: {},
    },
  };
