var genebankList_zh= [
    {
      text: "在景德镇市40多年来考古出土的海量标本基础上，景德镇御窑博物院（景德镇市陶瓷考古研究所）于2021年7月起筹备建设景德镇古陶瓷基因库。2022年6月11日，由江西省文物局授牌正式成立。",
      image: "/image/genebank/genebank_image1.jpg",
    },
    {
      text: "以多种物理和数字形态的标本为样本，全面涵盖景德镇瓷器的“考古信息片段”-“胎料技术片段”-“成型技术片段”-“釉料技术片段”-“装烧技术片段”-“彩绘装饰片段”等基因片段信息。",
      image: "/image/genebank/genebank_image2.jpg",
    },
    {
      text: "此外，开发了景德镇古陶瓷基因库信息管理平台，作为基因库管理者与使用者进行工作交流、数据交换的重要媒介。该平台将综合汇总每一件标准器物的三维数字模型、器物信息、样品状态、相关成果、分析数据等信息。",
      image: "/image/genebank/genebank_image3.jpg",
    },
    {
      text: "目前，景德镇古陶瓷基因库已收录古陶瓷基因标本1372套（2412件），采集数据近30万条。研究者可通过申请样品和数据使用等方式分享研究成果。未来的基因库数据不仅来源于景德镇市陶瓷考古研究所，还将广泛地与国内外各类博物馆和科研机构合作，在数据的采集和使用上实现开放共享。",
      image: "/image/genebank/genebank_image4.jpg",
    },
  ];

var genebankList_en= [
    {
      text: "Based on the abundant artifacts unearthed from archaeological excavations in Jingdezhen City over the past 40 years, the Jingdezhen Imperial Kiln Museum (Jingdezhen Ceramic Archaeological Research Institute) initiated the establishment of the Jingdezhen Ancient Ceramic Gene Bank in July 2021. On June 11, 2022, it was officially established and awarded by the Jiangxi Provincial Bureau of Cultural Relics.",
      image: "/image/genebank/genebank_image1.jpg",
    },
    {
      text: 'Using a variety of physical and digital forms of specimens as samples, the Jingdezhen Ceramic Gene Bank comprehensively covers genetic fragment information of Jingdezhen porcelain, including "archaeological information fragments," "body material technique fragments," "forming technique fragments," "glaze technique fragments," "firing and finishing technique fragments," and "painted decoration fragments."',
      image: "/image/genebank/genebank_image2.jpg",
    },
    {
      text: "In addition, the Jingdezhen Ceramic Gene Bank Information Management Platform has been developed as a crucial medium for communication and data exchange between the gene bank managers and users. This platform will comprehensively compile information such as the three-dimensional digital models of each standardized artifact, object details, sample status, related achievements, and analytical data.",
      image: "/image/genebank/genebank_image3.jpg",
    },
    {
      text: "Currently, the Jingdezhen Ceramic Gene Bank has collected 1,372 sets (2,412 pieces) of ancient ceramic genetic specimens, traced nearly 300,000 pieces of information. Researchers can share their research findings through means such as applying for sample and data usage. In the future, the gene bank data will not only come from the Jingdezhen Ceramic Archaeology Institute but will also be extensively collaborated with various museums and research institutions both domestically and internationally, aiming to achieve open sharing in data collection and utilization.",
      image: "/image/genebank/genebank_image4.jpg",
    },
  ];

  export function getGenebankListData(locale){
    var genebankList = [];
    if(locale === "zh") genebankList = genebankList_zh;
    else if(locale === "en") genebankList = genebankList_en;
    return genebankList;
  }