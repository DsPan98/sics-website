
// 国家列表
var countryList = [
  {
    id: 1,
    image: "/image/about/section5/countryList/Canada.png",
    ch: "加拿大",
    en: "Canada",
  },
  {
    id: 2,
    image: "/image/about/section5/countryList/China.png",
    ch: "中国",
    en: "China",
  },
  {
    id: 3,
    image: "/image/about/section5/countryList/France.png",
    ch: "法国",
    en: "France",
  },
  {
    id: 4,
    image: "/image/about/section5/countryList/Germany.png",
    ch: "德国",
    en: "Germany",
  },
  {
    id: 5,
    image: "/image/about/section5/countryList/Iran.png",
    ch: "伊朗",
    en: "Iran",
  },
  {
    id: 6,
    image: "/image/about/section5/countryList/Italy.png",
    ch: "意大利",
    en: "Italy",
  },
  {
    id: 7,
    image: "/image/about/section5/countryList/Japan.png",
    ch: "日本",
    en: "Japan",
  },
  {
    id: 8,
    image: "/image/about/section5/countryList/Korea.png",
    ch: "韩国",
    en: "Korea",
  },
  {
    id: 9,
    image: "/image/about/section5/countryList/Mexico.png",
    ch: "墨西哥",
    en: "Mexico",
  },
  {
    id: 10,
    image: "/image/about/section5/countryList/Netherlands.png",
    ch: "荷兰",
    en: "Netherlands",
  },
  {
    id: 11,
    image: "/image/about/section5/countryList/Philippines.png",
    ch: "菲律宾",
    en: "Philippines",
  },
  {
    id: 12,
    image: "/image/about/section5/countryList/Portuga.png",
    ch: "葡萄牙",
    en: "Portuga",
  },
  {
    id: 13,
    image: "/image/about/section5/countryList/Russia.png",
    ch: "俄罗斯",
    en: "Russia",
  },
  {
    id: 14,
    image: "/image/about/section5/countryList/Singapore.png",
    ch: "新加坡",
    en: "Singapore",
  },
  {
    id: 15,
    image: "/image/about/section5/countryList/Spain.png",
    ch: "西班牙",
    en: "Spain",
  },
  {
    id: 16,
    image: "/image/about/section5/countryList/Turkey.png",
    ch: "土耳其",
    en: "Turkey",
  },
  {
    id: 17,
    image: "/image/about/section5/countryList/USA.png",
    ch: "美国",
    en: "USA",
  },
  {
    id: 18,
    image: "/image/about/section5/countryList/UK.png",
    ch: "英国",
    en: "UK",
  },
  {
    id: 19,
    image: "/image/about/section5/countryList/Vietnam.png",
    ch: "越南",
    en: "Vietnam",
  },
];


export function getCountryList() {
  return countryList;
}

