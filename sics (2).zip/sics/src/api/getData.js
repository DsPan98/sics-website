//活动3 成立大会 没有相关链接 需要更改
export var newsList_zh = [
  {
    id: 1,
    title: "2023年英国陶瓷双年展日程公布",
    subtext:
      "从9月23日到11月5日，英国陶瓷双年展(BCB)将回到斯托克，在这座城市的工业遗产背景下举办为期六周的展览、装置和活动。从聚焦英国顶尖的陶艺家，到引进国际艺术家的作品和新鲜的人才，BCB 艺术节是一个庆祝粘土在故事讲述、游戏、冒险和行动主义方面的创造潜力的节日。2023年的艺术家包括 Osman Yousefzada，William Cobbing，Emilie Taylor 和 Stephen Dixon。",
    site: "https://www.britishceramicsbiennial.com/news/bcb-2023-festival-programme-announced/",
    date: "2023年5月12日",
    image: "/image/news/BCB.png",
    source: "British Ceramics Biennial 官网",
  },
  {
    id: 2,
    title: "马丁森奖获奖名单公布",
    subtext:
      "马丁森奖的评选是2023年拉脱维亚陶瓷双年展的重要活动，旨在向彼得里斯·马丁森致敬。马丁森是著名的陶瓷艺术家，被誉为拉脱维亚当代陶瓷艺术的奠基人。比赛面向全球艺术家开放，欢迎具有创新技术、独特风格和富有创造力的作品。今年，比赛以“浑浊的水域”为主题，共收到来自71个国家的685份申请。国际评委会从中挑选出了最佳的64份作品，最终展出了59个作品。",
    site: "https://arterritory.com/en/visual_arts/on_site/26872-winners_announced_for_the_martinsons_award/",
    date: "2023年9月15日",
    image: "/image/news/Martinsons.png",
    source: "Arterritory.com",
  },
  {
    id: 3,
    title: "“瓷的旅程”——2023景德镇国际陶瓷艺术双年展（竞赛展）作品征集方案",
    subtext:
      "陶瓷是人类最早的发明，几千年来这种土与火的艺术成为了人类文明最为绵长的纽带，书写了人类文明交流最为灿烂的篇章。景德镇是世界陶瓷文化的圣地，千年以来，精美的瓷器从这里出发，经历艰辛漫长的旅程，最终到达世界各地，瓷器成为世界认识中国的主要文化符号。在当今全球化的世界，让我们继续以陶瓷为媒介，使人类的好奇心、想象力和创造力在“瓷的旅程”中延续。",
    site: "http://www.cjicb.com/JICB.html",
    date: "2023年6月17日",
    image: "/image/news/news3.png",
    source: "景德镇国际陶瓷艺术双年展官网",
  },
  {
    id: 4,
    title: "CWD——陶瓷世界目的地诞生",
    subtext:
      "由朱迪思•施瓦茨（Judith S. Schwartz）担任主席的纽约现代艺术博物馆（MoCA）刚刚发布了一个名为 “陶瓷世界目的地”（CWD - Ceramic World destinations）的网站，介绍世界各地的与陶瓷相关的博物馆、大学、艺术家、历史遗迹和工作坊等。\n其中，MIC和Faenza等无数陶瓷机构都是不容错过的。\n请访问 https://moca-ny.org/cwd 并支持该项目。",
    site: "https://www.micfaenza.org/en/2023/08/cwd-ceramic-world-destinations-is-born/",
    date: "2023年8月8日",
    image: "/image/news/news4.png",
    source: "景德镇国际陶瓷艺术双年展官网",
  },
  {
    id: 5,
    title: "地中海当代陶瓷艺术大赛的获奖者已经揭晓",
    subtext:
      "近年来，地中海当代陶艺大赛在全球范围内扩大了影响，并在当代艺术界中逐渐崭露头角。第30届地中海现代陶艺大赛在意大利的格罗塔利举行，来自波兰、日本、英国、立陶宛、阿拉伯联合酋长国、德国、罗马尼亚和意大利的38件作品入选。",
    site: "https://www.ceramicsnow.org/news/the-winners-of-mediterraneo-the-30th-competition-of-contemporary-ceramic-art-have-been-announced/",
    date: "2023年7月14日",
    image: "/image/news/news4.png",
    source: "Ceramics Now",
  },
  {
    id: 6,
    title: "第13届日本美浓国际陶瓷展开放报名中",
    subtext:
      "“日本美浓国际陶瓷展”是“日本美浓国际陶瓷节”的主要活动，旨在通过全球陶瓷设计和文化交流，促进陶瓷工业的发展和文化的提升。这是自1986年首次举办以来的第13届国际陶瓷比赛。每届比赛都会设置评审团，来自世界各地的知名评委们，会对不同国家的参赛作品进行评选。在上一届比赛中，我们收到了来自64个国家和地区的1292名申请者的精彩作品，共计2435件。如此庞大的比赛规模和高质量的作品，让我们的陶瓷比赛真正成为当今世界的代表。",
    site: "https://www.ceramicsnow.org/news/applications-are-open-for-the-13th-international-ceramics-competition-mino-japan/",
    date: "2023年2月6日",
    image: "/image/news/news6.png",
    source: "Ceramics Now",
  },

  {
    id: 7,
    title:"“瓷的故事——中国与阿拉伯伊斯兰世界的世纪交流”文化交流活动在沙特利雅得举行",
    subtext:"盛夏时节的利雅得，热情似火，满目青翠。8月3日，由景德镇陶瓷文化国际交流中心、沙特科研与知识交流中心主办，景德镇御窑博物院协办的“瓷的故事——中国与阿拉伯伊斯兰世界的世纪交流”文化交流活动在沙特科研与知识交流中心举办。大家以瓷为媒、因瓷相约，深化陶瓷文化交流合作，赓续中沙传统友谊，携手开创更加美好未来。",
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/article/id/I00004774",
    date: "2023年8月6日",
    image: "/image/news/news7.png",
    source: "御窑博物院官网",
  },
];
export var newsList_en = [
  {
    id: 1,
    title: "British Ceramics Biennial 2023 Festival programme announced",
    subtext:
      "From 23 September to 5 November, the British Ceramics Biennial (BCB) Festival returns to Stoke-on-Trent for six weeks of exhibitions, installations and events shown against the backdrop of the city's industrial heritage. From spotlighting the UK's leading ceramicists to introducing work by international artists and fresh new talent, the BCB Festival is a celebration of the creative potential of clay for storytelling, playfulness, risk-taking and activism. Artists for 2023 include Osman Yousefzada, William Cobbing, Emilie Taylor and Stephen Dixon.",
    site: "https://www.britishceramicsbiennial.com/news/bcb-2023-festival-programme-announced/",
    date: "May 12, 2023",
    image: "/image/news/BCB.png",
    source: "British Ceramics Biennial official site",
  },
  {
    id: 2,
    title: "Winners announced for the Martinsons Award",
    subtext:
      'The Martinsons Award 2023 International Juried Exhibition is the star event of the Latvia Ceramics Biennale and a tribute Pēteris Martinsons - the distinguished Latvian ceramicist celebrated as the father of Latvian professional contemporary ceramics. The competition is open to artists from all over the world and welcomes submissions that embrace innovative techniques, demonstrate strong stylistic individualism and send a compelling creative message. This year, the award ran with the theme "Troubled Waters" and received a record 685 applications from 71 countries. An international jury selected 64 best submissions, which yielded 59 exhibits for the sweeping final show.',
    site: "https://arterritory.com/en/visual_arts/on_site/26872-winners_announced_for_the_martinsons_award/",
    date: "September 15, 2023",
    image: "/image/news/Martinsons.png",
    source: "Arterritory.com",
  },
  {
    id: 3,
    title:
      "Global Call for Submissions for The Journey of Ceramics:2023 Jingdezhen International Ceramic Art Biennale (Works for Juried Exhibition Section)",
    subtext:
      'Ceramics is one of the earliest inventions of mankind, and for thousands of years this art of clay and fire has become the most long-lasting link of human civilization, writing the most splendid chapter of global cultural exchanges. Jingdezhen is a sacred place of world ceramic culture. For thousands of years, exquisite porcelain has set out from here, undergone a long and arduous journey, and finally reached all over the world, becoming the main cultural symbol of China for the world to know. In today\'s globalized world, let us continue to use ceramics as a medium to perpetuate human curiosity, imagination, and creativity in "the journey of ceramics".',
    site: "http://www.cjicb.com/JICB.html",
    date: "June 17, 2023",
    image: "/image/news/news3.png",
    source: "Jingdezhen International Ceramic Art Biennale",
  },
  {
    id: 4,
    title: "CWD——Ceramic World destinations is born",
    subtext:
      "MoCA in New York, chaired by Judith S. Schwartz, has just published CWD - Ceramic World destinations a website that maps ceramics around the world, museums, universities, schools, workshops, artists, historical monuments, and workshops.\nMIC and Faenza with its countless realities could not be missed.\nTake a look and support the project: https://moca-ny.org/cwd",
    site: "https://www.micfaenza.org/en/2023/08/cwd-ceramic-world-destinations-is-born/",
    date: "August 8, 2023",
    image: "/image/news/news4.png",
    source: " Italy's International Museum of Ceramics in Faenza",
  },
  {
    id: 5,
    title:
      "The winners of Mediterraneo, the 30th Competition of Contemporary Ceramic Art, have been announced",
    subtext:
      "In recent years, the Mediterraneo Contemporary Ceramic Competition has expanded its reach globally and has established itself as a competition on a constant ascent in the contemporary art scene. Thirty-eight selected artworks from Poland, Japan, England, Lithuania, the United Arab Emirates, Germany, Romania, and Italy took center stage at the thirtieth edition of the Mediterraneo Contemporary Ceramic Competition in Grottaglie.",
    site: "https://www.ceramicsnow.org/news/the-winners-of-mediterraneo-the-30th-competition-of-contemporary-ceramic-art-have-been-announced/",
    date: "July 14, 2023",
    image: "/image/news/news4.png",
    source: "Ceramics Now",
  },
  {
    id: 6,
    title:
      "Applications are open for the 13th International Ceramics Competition Mino, Japan",
    subtext:
      "\"The International Ceramics Exhibition Mino, Japan\" is the main event of the \"International Ceramics Festival Mino, Japan,\" which is held with the aim of supporting the growth of the ceramics industry and the enhancement of culture through the global exchange of ceramics design and culture. This is the 13th international ceramics competition since the first one was held in 1986. Each competition is judged by a panel of distinguished judges from around the world, and entries are received from various countries. In the last competition, we had amazing 2,435 entries from 1,292 applicants coming from 64 countries and areas around the world. The scale and high quality made our ceramics competition truly the representative of the world today.",
    site: "https://www.ceramicsnow.org/news/applications-are-open-for-the-13th-international-ceramics-competition-mino-japan/",
    date: "February 6, 2023",
    image: "/image/news/news6.png",
    source: "Ceramics Now",
  },
  {
    id: 7,
    title: "The cultural exchange event titled \"The Story of Porcelain: Century-long Exchange between China and the Arab Islamic World\" was held in Riyadh, Saudi Arabia.",
  subtext:"In the scorching summer of Riyadh, exuding fiery passion and vibrant greenery, on August 3rd, a cultural exchange event titled \"The Story of Porcelain: Century-long Exchange between China and the Arab Islamic World\" was held at the Saudi Research and Knowledge Exchange Center. The event was organized by the Jingdezhen Ceramic Culture International Exchange Center, with the cooperation of the Jingdezhen Imperial Kiln Museum. Its purpose was to foster deeper cultural exchange and collaboration in the realm of ceramics, while also nurturing the longstanding friendship between China and Saudi Arabia, with a shared vision for a brighter future.",
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/article/id/I00004774",
    date: "August 6 , 2023",
    image: "/image/news/news7.png",
    source: "Jingdezhen Imperial Kiln Institute",
  },
];

export var eventsList_zh = [
  {
    id: 1,
    title: "明朝皇室赠送给伊斯兰世界的礼物",
    subtext:
      "这次讲座介绍了外交信函，包括那些在官方公文手册中编纂的信件，详细展示明代中国与伊斯兰世界之间的外交文化。它旨在为明朝赠送的物品、交流礼仪以及这些物品在伊斯兰文化中的接受方面带来新的认识。",
    type: "讲座",
    host: "东方陶瓷学会",
    date: "2023年10月10日",
    image: "/image/events/ming_court.png",
    site: "https://www.orientalceramicsociety.org.uk/events/gifts-from-the-ming-court-to-the-islamic-world",
  },
  {
    id: 2,
    title: "“黑石号”沉船的前世今生",
    subtext:
      "唐朝时期的沉船仍然是人们关注的焦点。在本讲座中，作者 Natali Pearson 博士将重点介绍这艘古船及其货物的“来世命运”、伴随其发现和展陈而来的争议，及其带来的关于海上丝绸之路的全新认知。“黑石号“揭示了古代商业活动的全球性规模以及海洋对这些贸易网络的重要意义。然而，这艘沉船的当代命运也待我们娓娓道来：各国出于种种目的将历史的遗物挪为己用，而国际社会也为了共享遗产的所有权和责任制争论不休。",
    type: "讲座",
    host: "东南亚陶瓷学会",
    date: "2023年6月27日",
    image: "/image/events/belitung.png",
    site: "https://www.seaceramic.org.sg/event/belitung-the-afterlives-of-a-shipwreck/",
  },
  {
    id: 3,
    title: "国际瓷器研究联盟成立大会",
    subtext:
      "会议介绍：由于瓷器的重要价值和意义，各国学者从艺术鉴赏、年代判定、窑口辨识、工艺分析、文化和技术交流、贸易往来等方面对其开展了多维度的研究。然而，资料的发布、成果的分享、观点的探讨、研究的合作等方面却明显存在着分散甚至割裂的情况，跨学科和跨国界的融合仍有极大的提升空间。有鉴于此，我们决定成立“国际瓷器研究联盟”，以推动相关领域的信息和资源在世界范围内的共建共享，打造相关学者和机构之间的国际交流合作新平台，共同促进瓷器及其相关文化的保护、传承和创新利用。",
    type: "会议",
    host: "景德镇御窑博物院",
    date: "2023年10月18日",
    image: "/image/events/SICS_assembly.jpg",
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/index",
  },
  {
    id: 4,
    title: "第 48 届国际先进陶瓷与复合材料会议暨博览会（ICACC2024）",
    subtext:
      "今年的会议包括19个专题研讨会、5个重点会议、1个特别研讨会和第13届全球青年研究者论坛。这些会议将包括口头报告和海报展示，为来自世界各地的科学家、研究人员和工程师提供一个开放的论坛，展示和交流与陶瓷科学和技术相关的各方面最新进展。",
    type: "会议",
    host: "美国陶瓷学会",
    date: "2024年1月28日—2024年2月2日",
    image: "/image/events/ICACC2024.png",
    site: "https://ceramics.org/event/48th-international-conference-and-expo-on-advanced-ceramics-and-composites-icacc2024/",
  },
  {
    id: 5,
    title: "宫廷粉彩陶艺工作坊",
    subtext:
      "光绪十二年（1886年），景德镇御窑为慈禧太后的五十二岁生辰专门烧造了一个黄地粉彩瓷花卉图捧盒。此次工作坊以此器物为灵感，让参加者学习古代宫廷工匠精湛的技艺，并发挥您的无限创意，亲手制作独一无二的陶瓷珍宝。",
    type: "工作坊",
    host: "地点：中国香港故宫文化博物馆",
    date: "2023年10月22日",
    image: "/image/events/fencai.png",
    site: "https://www.hkpm.org.hk/en/event/imperial-fencai-ceramic-workshop",
  },
  {
    id: 6,
    title: "苏格兰之旅",
    subtext: "学会分别于 9 月 12-15 日和 26-29 日组织了两次苏格兰之旅。",
    type: "实地考察",
    host: "东方陶瓷学会",
    date: "2022年9月",
    image: "/image/events/scotland.png",
    site: "https://www.orientalceramicsociety.org.uk/lectures-events/tours-visits",
  },
  {
    id: 7,
    title: "东南亚陶瓷学会成员对越南窑厂的考察",
    subtext:
      "SEACS 安排了一次实地考察之旅，参观泰国北部素可泰（Sukhothai）和西萨查那莱（Si Satchanalai）的窑炉和历史遗迹。此行仅限学会会员及其直系亲属参加，陪同将是两位重要的的泰国陶瓷专家。",
    type: "实地考察",
    host: "东南亚陶瓷学会",
    date: "2023年11月9日—2023年11月11日",
    image: "/image/events/SEACS.png",
    site: "https://www.orientalceramicsociety.org.uk/lectures-events/tours-visits",
  },
];
export var eventsList_en = [
  {
    id: 1,
    title: "Gifts from the Ming Court to the Islamic World",
    subtext:
      "This talk presents diplomatic letters, including those compiled in chancery manuals, as source materials that illustrate in detail the material culture of diplomacy between Ming China and the Islamic world. It seeks to shed new light on the Ming items sent as gifts, the exchange etiquette, and the reception of such objects in the Islamic culture of gift giving.",
    type: "Lectures",
    host: "The Oriental Ceramic Society ",
    date: "October 10, 2023",
    image: "/image/events/ming_court.png",
    site: "https://www.orientalceramicsociety.org.uk/events/gifts-from-the-ming-court-to-the-islamic-world",
  },
  {
    id: 2,
    title: "Belitung: The Afterlives of a Shipwreck",
    subtext:
      "The Tang Dynasty-era shipwreck continues to be the centre of attention. In this talk, author Dr. Natali Pearson focuses on the afterlives of the ship and its cargo: the new knowledge it has brought to the surface about the maritime silk route, and the controversies that have accompanied its discovery and display.  It is one of the most significant shipwreck discoveries of recent times, revealing the global scale of ancient commercial endeavors and the importance of the ocean to these trading networks. But this shipwreck also has a modern tale to tell, of how nation-states appropriate the remnants of the past for their own purposes, and of the international debates about who owns—and is responsible for—shared heritage.",
    type: "Lectures",
    host: "Southeast Asian Ceramic Society",
    date: "June 27, 2023",
    image: "/image/events/belitung.png",
    site: "https://www.seaceramic.org.sg/event/belitung-the-afterlives-of-a-shipwreck/",
  },
  {
    id: 3,
    title: "Society of International Ceramic Studies Inaugural Assembly",
    subtext:
      'Due to the important value and significance of porcelain, scholars from various countries have conducted multidimensional and systematic research on it from aspects such as art appreciation, dating, production kiln identification, process analysis, cultural and technological exchanges, and trade exchanges. However, there is a significant dispersion or even fragmentation in the dissemination of materials, sharing of achievements, exploration of viewpoints, and cooperation in research, and there is great room for improvement in interdisciplinary and cross-border integration. In view of this, we have decided to establish the "Society of International Ceramic Studies" to promote the co-construction and sharing of information and resources in related fields worldwide, create a new platform for international exchange and cooperation between relevant scholars and institutions, and jointly promote the protection, inheritance, and innovative utilization of porcelain and its related culture.',
    type: "Conferences",
    host: "Jingdezhen Imperial Kiln Institute",
    date: "October 18, 2023",
    image: "/image/events/SICS_assembly.jpg",
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/index",
  },
  {
    id: 4,
    title:
      "48th International Conference and Expo on Advanced Ceramics and Composites (ICACC2024)",
    subtext:
      "This year, the technical program consists of nineteen Symposia, five Focused Sessions, and one Special Focused Session, and the 13th Global Young Investigator Forum. These technical sessions, consisting of both oral and poster presentations, will provide an open forum for scientists, researchers, and engineers from all over the world to present and exchange findings on recent advances on various aspects related to ceramic science and technology.",
    type: "Conferences",
    host: "The American Ceramic Society (ACerS)",
    date: "January 28, 2024 - February 2, 2024",
    image: "/image/events/ICACC2024.png",
    site: "https://ceramics.org/event/48th-international-conference-and-expo-on-advanced-ceramics-and-composites-icacc2024/",
  },
  {
    id: 5,
    title: "Imperial Fencai Ceramic Workshop",
    subtext:
      "In 1886, the Imperial Kilns in Jingdezhen specially made a porcelain lidded box with flowers for Empress Dowager Cixi's 52nd birthday. Get inspired by the treasure's exceptional craftsmanship and let your creativity run wild in our ceramic workshop!",
    type: "Workshops",
    host: "The Hong Kong Palace Museum",
    date: "October 22, 2023",
    image: "/image/events/fencai.png",
    site: "https://www.hkpm.org.hk/en/event/imperial-fencai-ceramic-workshop",
  },
  {
    id: 6,
    title: "Tours to Scotland",
    subtext:
      "Two tours to Scotland were organised for 12-15 and 26-29 September respectively.  Both were based in Edinburgh and included visits to Newhailes House, Bowhill House, Abbotsford House, the newly reopened Burrell Collection and Pollok House.",
    type: "Field Trips",
    host: "The Oriental Ceramic Society",
    date: "September, 2022",
    image: "/image/events/scotland.png",
    site: "https://www.orientalceramicsociety.org.uk/lectures-events/tours-visits",
  },
  {
    id: 7,
    title:
      "SEACS Members' Field Trip to the kilns of Sukhothai & Si Satchanalai, Thailand",
    subtext:
      "SEACS has arranged a field trip to the kilns and historic sites of Sukhothai and Si Satchanalai in northern Thailand. This trip is limited to Society members plus members of their immediate family. Accompanying us will be two of the foremost experts on Thai ceramics, the much-published author and Thai resident, Dr. Dawn Rooney, and the former Asst. Curator of the Southeast Asian Ceramics Museum (Bangkok University) Khun Atthasit Sukkham.",
    type: "Field Trips",
    host: "Southeast Asian Ceramic Society",
    date: "November 9, 2023—November 11, 2023",
    image: "/image/events/SEACS.png",
    site: "https://www.orientalceramicsociety.org.uk/lectures-events/tours-visits",
  },
];

export var exhibitionsList_zh = [
  {
    id: 1,
    title: "榷陶清晖：馆藏康雍乾官窑瓷器展",
    subtext:
      "本次展览遴选馆藏康雍乾精品官窑瓷器74件，以继承与创新为展览脉络，以彩绘瓷、颜色釉两单元展开叙事，向公众集中呈现清康雍乾官窑瓷器文化，展示康雍乾官窑瓷器的突出成就，对于宣传、展示陶瓷文化具有重要意义。",
    site: "https://www.lnmuseum.com.cn/#/exhibition/detail?id=1702164960958169089&amp;pageType=1",
    host: "辽宁省博物馆",
    date: "2023年08月29日-2023年12月31日",
    image: "/image/exhibitions/quetao.png",
  },
  {
    id: "2",
    title: "中国白：德化白瓷展",
    host: "国家博物馆",
    date: "2023年08月26日起",
    subtext:
      "本次展览精选从古至今400余件（组）德化白瓷作品，分为“一白独秀”和“百技争艳”两个单元，涵盖“何朝宗”款观音像、“筍江山人”款观音等传世精品，尾林窑遗址、华光礁一号沉船等德化窑古代珍品，其中不乏极具西方审美意趣的铜口筒瓶、莲瓣纹军持等，并集中展现了现当代德化艺术家的杰作，体现了德化瓷精湛的制瓷技艺和一脉相承的传承创新。",
    site: "https://www.chnmuseum.cn/portals/0/web/zt/202309dhbc/",
    image: "/image/exhibitions/blanc.png",
  },
  {
    id: "3",
    title: "凝固的韵律：国际当代陶艺作品展",
    host: "清华大学艺术博物馆",
    date: "2023年07月12日-2023年10月15日",
    subtext:
      "此次展览共展出86组件国内外当代陶艺精品，其中以清华大学艺术博物馆馆藏的31组件国际知名陶艺家作品为基础，联合浙江上虞青·现代国际陶艺中心27位国际优秀陶艺家的36组件作品和15位国内特邀当代陶艺家的19组件作品共同呈现。展览将不同形态、观念和制作技术的作品并置展出，使观众在观赏和思考中获得差异性或均质性的认识，以展现陶艺如何在当代文化格局中谱写独特的艺术乐章。",
    site: "https://www.artmuseum.tsinghua.edu.cn/cpsj/zlxx/zzzl/lszl/202307/t20230711_18481.shtml",
    image: "/image/exhibitions/melody.jpg",
  },
  {
    id: "4",
    title: "丝路瓷缘•釉见敦煌：瓷画艺术展",
    host: "江西博物馆",
    date: "2023年6月8日 - 10月7日",
    subtext:
      "本次展览由江西省博物馆、敦煌研究院和景德镇陶瓷艺术研究院联合主办，通过80件（套）展品呈现景德镇瓷画与敦煌艺术之间的碰撞和对话，解读敦煌壁画的历史与工艺。",
    site: "https://www.jxmuseum.cn/exhibition/tempexhibition/3891ca7599faf9a27a15a5ad1c5eeb54?groupId=4a75e398b5f34f77868572a063d80c84",
    image: "/image/exhibitions/Dunhuang.png",
  },
  {
    id: "5",
    title: "御窑天下·青花秘境",
    host: "景德镇御窑博物院",
    date: "2022年10月1日-2023年5月31日",
    subtext:
      "本次“御窑天下”特展以“青花秘境”为主题，以讲述青花瓷的源流与发展脉络为线索，从宏观和微观两个层面讲述御窑和世界的关系。",
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/article/id/E00004156",
    image: "/image/exhibitions/imperial.png",
  },
  {
    id: "6",
    title: "日本茶道里的中国瓷器：茶具、怀石料理等",
    host: "旧金山亚洲艺术博物馆",
    date: "2023年11月17日——2024年5月6日",
    subtext:
      "展览通过探讨中国瓷器与陶器在日本茶文化中的角色，展示中日之间的艺术及文化交流。12世纪左右，中国茶风传入日本后，茶的社会仪式在禅寺、武士家庭和其他上层社会的高僧之间传播开来。",
    site: "https://exhibitions.asianart.org/exhibitions/japanese-tastes-in-chinese-ceramics/",
    image: "/image/exhibitions/teaUtensils.png",
  },
  {
    id: "7",
    title: "生于陶土：普韦布洛陶器精神",
    host: "大都会艺术博物馆",
    date: "2023年7月14日 -2024年6月4日",
    subtext:
      "本次展览展出了百逾件历史时期与现当代的陶器作品，涉及美国新墨西哥州、西得克萨斯、亚利桑那州的多个原住民社群，重点呈现11世纪至今美洲土著普韦布洛人的观念和审美，探讨原住民陶器的视觉语言和跨代叙事。",
    site: "https://www.metmuseum.org/exhibitions/grounded-in-clay",
    image: "/image/exhibitions/clay.png",
  },
  {
    id: "8",
    title: "拥抱色彩：1300-1900年中国装饰艺术中的珐琅",
    host: "大都会艺术博物馆",
    date: "2022年7月2日 -2026年1月4日",
    subtext:
      "珐琅是中国装饰艺术的重要元素，却长期以来一直被忽视。本次展览将分批轮换展出超过100件主要来自大都会艺术博物馆的藏品，展示中国明清时期珐琅器的审美、技术和文化。",
    site: "https://www.metmuseum.org/exhibitions/embracing-color",
    image: "/image/exhibitions/enamel.png",
  },
  {
    id: "9",
    title: "事物之间：阿尔伯塔陶瓷展",
    host: "阿尔伯塔美术馆",
    date: "2023年9月2日 -2024年3月3日",
    subtext:
      "本次联展展出了加拿大阿尔伯塔省艺术家的陶艺作品。展览旨在探讨陶瓷对我们与周围世界的体验以及我们与外界世界的关系的影响。本次展览通过三个相互关联的概念来审视陶瓷物体：陶瓷与其材料和工艺的关系；陶瓷与其周围环境的关系；陶瓷与我们身体和情感的关系。参加此次展览的艺术家们制作的当代陶艺作品重新将我们与物质世界彼此联系在一起。",
    site: "https://www.youraga.ca/exhibitions/between-things-alberta-ceramics",
    image: "/image/exhibitions/Alberta.png",
  },
  {
    id: "10",
    title: "丹波烧的世界",
    host: "兵库陶艺美术馆",
    date: "2023年3月11日 -2024年2月25日",
    subtext:
      "丹波烧是日本最古老的六大窑之一，诞生于平安时代末期，基于当地的须惠器（土器）的生产体系，融合了东海地区常滑烧和渥美烧（均位于爱知县）的陶瓷技术。本次展览介绍了 2018 年 3 月被指定为兵库县重要有形文化遗产的“田中宽收藏”，以及开馆以来收集的丹波烧精品。",
    site: "https://www.mcart.jp/exhibition/e3506/",
    image: "/image/exhibitions/TAMBA.png",
  },
];
export var exhibitionsList_en = [
  {
    id: 1,
    title: "Exhibition of  Qing Dynasty imperial kiln ceramics",
    subtext:
      "On Aug 29, the Liaoning Provincial Museum unveiled an exhibition, highlighting imperial kiln ceramics from its collection, dating back to the Kangxi (r.1662-1722), Yongzheng (r.1723-35) and Qianlong (r.1736-95) reigns of the Qing Dynasty (1644-1911). A total of 74 selected ceramics present different craftsmanship from the three periods.(Source: China daily)",
    site: "https://www.lnmuseum.com.cn/#/exhibition/detail?id=1702164960958169089&amp;pageType=1",
    host: "Liaoning Provincial Museum",
    date: "August 29, 2023 - December 31, 2023",
    image: "/image/exhibitions/quetao.png",
  },
  {
    id: "2",
    title: "Blanc de Chine: Dehua White Porcelain",
    host: "National Museum of China",
    date: "From August 26, 2023",
    subtext:
      "An exhibition featuring over 400 pieces and sets of Dehua porcelain, also known in French as \"Blanc de Chine,\" kicked off Saturday at the National Museum of China in Beijing. Located in east China's coastal province of Fujian, Dehua is famous for its centuries-old legacy of white porcelain production. Dehua ceramics were exported overseas during as early as the Song Dynasty (960-1279) and the Yuan Dynasty (1271-1368). To this day, the county remains one of China's largest producers and exporters of porcelain craftwork. The exhibition will last for three months. The ceramics on display include both relics and contemporary and modern artworks produced in Dehua kilns. (Source: China daily)",
    site: "https://www.chnmuseum.cn/portals/0/web/zt/202309dhbc/",
    image: "/image/exhibitions/blanc.png",
  },
  {
    id: "3",
    title:
      "Stilled Melody: Exhibition of International Contemporary Ceramic Art Works",
    host: "Tsinghua University Art Museum",
    date: "July 12, 2023 - October 15, 2023",
    subtext:
      "This exhibition is based on internationally renowned ceramic artists' works from our museum's collection, combined with works from Shangyu Celadon Modern International Ceramic Art Center in Shangyu, Zhejiang Province and several domestic contemporary ceramic artists. This exhibition presents works with different forms, concepts, and production techniques side by side so that viewers can observe and contemplate differences or similarities between them. The aim of this exhibition is to demonstrate how ceramics play a unique artistic role within the context of contemporary culture.",
    site: "https://www.artmuseum.tsinghua.edu.cn/cpsj/zlxx/zzzl/lszl/202307/t20230711_18481.shtml",
    image: "/image/exhibitions/melody.jpg",
  },
  {
    id: "4",
    title: "Decoding Dunhuang In Glaze: Porcelain Painting Art Exhibition",
    host: "Jiangxi Provincial Museum",
    date: "June 8, 2023 - October 7 , 2023",
    subtext:
      "This exhibition is jointly organized by the Jiangxi Provincial Museum, Dunhuang Academy and Jingdezhen Ceramic Art Research Institute, through 80 pieces (sets) of exhibits presenting the collision and dialogue between Jingdezhen porcelain paintings and Dunhuang art, interpreting the history of Dunhuang frescoes and craftsmanship.",
    site: "https://www.jxmuseum.cn/exhibition/tempexhibition/3891ca7599faf9a27a15a5ad1c5eeb54?groupId=4a75e398b5f34f77868572a063d80c84",
    image: "/image/exhibitions/Dunhuang.png",
  },
  {
    id: "5",
    title: "Imperial Kiln Universe · Mystery of Blue and White",
    host: "Jingdezhen Imperial Kiln Institute",
    date: "October 1, 2022 - May 31, 2023",
    subtext:
      'The current special exhibition "Imperial Kiln Universe" takes "Mystery of Blue and White" as its theme, aiming to explore the origin and development of blue and white porcelain. It tells the story of the relationship between imperial kilns and the world, providing insights from both a macro and micro perspective.',
    site: "http://www.jdzyybwy.com/jdzmu/frontend/pg/article/id/E00004156",
    image: "/image/exhibitions/imperial.png",
  },
  {
    id: "6",
    title:
      "Japanese Tastes in Chinese Ceramics: Tea Utensils, Kaiseki Dishes, and More",
    host: " Asian Art Museum of San Francisco",
    date: "November 17, 2023 - May 6, 2024",
    subtext:
      "Japanese Tastes in Chinese Ceramics: Tea Utensils, Kaiseki Dishes, and More illuminates the artistic and cultural exchange between China and Japan by exploring the role of Chinese ceramics in Japanese tea culture. After Chinese tea customs were introduced in Japan around the 12th century, the social ritual of tea spread among eminent monks at Zen temples, samurai families, and other members of the upper class.",
    site: "https://exhibitions.asianart.org/exhibitions/japanese-tastes-in-chinese-ceramics/",
    image: "/image/exhibitions/teaUtensils.png",
  },
  {
    id: "7",
    title: "Grounded in Clay: The Spirit of Pueblo Pottery",
    host: "The Metropolitan Museum of Art",
    date: "July 14, 2023 - June 4, 2024",
    subtext:
      "The effort features more than one hundred historical, modern, and contemporary clay works and offers a critical understanding of Pueblo pottery as community-based knowledge and personal experience. Dating from the eleventh century to the present day, the featured artworks represent the aesthetic lineages of New Mexico's nineteen Río Grande Pueblos as well as the West Texas community of Ysleta del Sur and the Hopi tribe of Arizona—sovereign Indigenous nations where pots and other ceramic works have been made and used for millennia. Visual and material languages of pottery and intergenerational narratives are highlighted throughout the exhibition.",
    site: "https://www.metmuseum.org/exhibitions/grounded-in-clay",
    image: "/image/exhibitions/clay.png",
  },
  {
    id: "8",
    title: "Embracing Color: Enamel in Chinese Decorative Arts, 1300-1900",
    host: "The Metropolitan Museum of Art",
    date: "July 2, 2022 - January 4, 2026",
    subtext:
      "Enamel decoration is a significant element of Chinese decorative arts that has long been overlooked. This exhibition reveals the aesthetic, technical, and cultural achievement of Chinese enamel wares by demonstrating the transformative role of enamel during the Ming (1368-1644) and Qing (1644-1911) dynasties.",
    site: "https://www.metmuseum.org/exhibitions/grounded-in-clay",
    image: "/image/exhibitions/enamel.png",
  },
  {
    id: "9",
    title: "Between Things: Alberta Ceramics",
    host: "Art Gallery of Alberta",
    date: "September 2, 2023 - March 3, 2024",
    subtext:
      "At a moment when ceramics are everywhere, Between Things: Alberta Ceramics includes sculptures and installations made by contemporary artists committed to clay to ask how ceramics can activate our experience of and relationship to the world around us. This exhibition examines the ceramic object through three interconnected ideas—the ceramic object in relation to its materials and processes; the ceramic object in relation to its context; and the affective nature of the ceramic object in relation to the self and body. The artists in this exhibition make contemporary ceramics that reconnect us with the material world and each other",
    site: "https://www.youraga.ca/exhibitions/between-things-alberta-ceramics",
    image: "/image/exhibitions/Alberta.png",
  },
  {
    id: "10",
    title: "World of TAMBA",
    host: "The Museum of Ceramic Art, Hyogo",
    date: "March 11, 2023 - February 25, 2024",
    subtext:
      "Tamba ware was first established towards the end of the Heian era based around the local production framework for creating Sueki pottery (unglazed ceramics). It also incorporated techniques from Tokoname ware and Atsumi ware produced in the Tokai region.This exhibition introduces the Kan Tanaka Collection, which were recognized as Important Cultural Property of Hyogo Prefecture in  collected since the opening of the museum.",
    site: "https://www.mcart.jp/exhibition/e3506/",
    image: "/image/exhibitions/TAMBA.png",
  },
];

export function getNewsData(newsId, locale) {
  // 根据语言类型不同获取
  var newsList = [];
  if (locale === "zh") newsList = newsList_zh;
  else if (locale === "en") newsList = newsList_en;
  console.log("newsList: ", newsList);
  for (var news in newsList) {
    if (newsList[news].id == newsId) {
      return newsList[news];
    }
  }
}

export function getEventsData(eventsId, locale) {
  var eventsList = [];
  if (locale === "zh") eventsList = eventsList_zh;
  else if (locale === "en") eventsList = eventsList_en;
  console.log("eventsList: ", eventsList);
  for (var events in eventsList) {
    if (eventsList[events].id == eventsId) {
      return eventsList[events];
    }
  }
}

export function getExhibitionsData(exhibitionsId, locale) {
  var exhibitionsList = [];
  if (locale === "zh") exhibitionsList = exhibitionsList_zh;
  else if (locale === "en") exhibitionsList = exhibitionsList_en;
  console.log("exhibitionsList: ", exhibitionsList);
  for (var exhibitions in exhibitionsList) {
    if (exhibitionsList[exhibitions].id == exhibitionsId) {
      return exhibitionsList[exhibitions];
    }
  }
}
