// 标本列表
var specimenList = [
  {
    id: 1,
    image: "/image/workStation/specimen/1tang.jpg",
    ch: "唐代",
    en: "Tang",
  },
  {
    id: 2,
    image: "/image/workStation/specimen/2song.jpg",
    ch: "宋代",
    en: "Song",
  },
  {
    id: 3,
    image: "/image/workStation/specimen/3yuan.JPG",
    ch: "元代",
    en: "Yuan",
  },
  {
    id: 4,
    image: "/image/workStation/specimen/4ming.JPG",
    ch: "明代",
    en: "Ming",
  },
];


// 设备列表
var equipmentList = [
  {
    id: 1,
    position: 'side',
    image: "/image/workStation/devices/left1X射线荧光分析仪.jpeg",
    ch: "X射线荧光分析仪",
    en: "X射线荧光分析仪",
  },
  {
    id: 2,
    position: 'side',
    image: "/image/workStation/devices/right1金刚石线切割机.jpeg",
    ch: "金刚石线切割机",
    en: "金刚石线切割机",
  },
  {
    id: 3,
    position: 'bottom',
    image: "/image/workStation/devices/bottom1低速精密切割机.jpeg",
    ch: "低速精密切割机",
    en: "低速精密切割机",
  },
  {
    id: 4,
    position: 'bottom',
    image: "/image/workStation/devices/bottom2古陶瓷基因标本机器人柔性制样系统.jpeg",
    ch: "古陶瓷基因标本机器人柔性制样系统",
    en: "古陶瓷基因标本机器人柔性制样系统",
  },
  {
    id: 5,
    position: 'bottom',
    image: "/image/workStation/devices/bottom3真空泵.jpeg",
    ch: "真空泵",
    en: "真空泵",
  },
  {
    id: 6,
    position: 'bottom',
    image: "/image/workStation/devices/bottom4紫外3瓦激光打标机.jpeg",
    ch: "紫外3瓦激光打标机",
    en: "紫外3瓦激光打标机",
  },
  {
    id: 7,
    position: 'center',
    image: "/image/workStation/devices/center1拉曼光谱仪.jpeg",
    ch: "拉曼光谱仪",
    en: "拉曼光谱仪",
  },
  {
    id: 8,
    position: 'center',
    image: "/image/workStation/devices/center2扫描电镜-能谱仪.jpeg",
    ch: "扫描电镜-能谱仪",
    en: "扫描电镜-能谱仪",
  },
  {
    id: 9,
    position: 'center',
    image: "/image/workStation/devices/center3台锯.jpeg",
    ch: "台锯",
    en: "台锯",
  },
  {
    id: 10,
    position: 'center',
    image: "/image/workStation/devices/center4磨抛机.jpeg",
    ch: "磨抛机",
    en: "磨抛机",
  },
  {
    id: 11,
    position: 'center',
    image: "/image/workStation/devices/center5镶嵌机.jpeg",
    ch: "镶嵌机",
    en: "镶嵌机",
  },
  {
    id: 12,
    position: 'center',
    image: "/image/workStation/devices/center6全自动金相试样磨抛机.jpeg",
    ch: "全自动金相试样磨抛机",
    en: "全自动金相试样磨抛机",
  },
];


export function getEquipmentList() {
  return equipmentList;
}

export function getSpecimenList() {
  return specimenList;
}

