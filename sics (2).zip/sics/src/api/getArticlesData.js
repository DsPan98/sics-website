var articlesList_en = [
    {
        title: "Chapter 1 General Provisions",
        subtext:"Article 1: The name of this society is \"Society of International Ceramic Studies\", abbreviated as SICS. \nArticle 2: This society is an academic, international, and non-profit professional research organization voluntarily formed by institutions and individuals related to ceramic collection, research, and preservation. \nArticle 3: The purpose of this society is to take \"the origin, spread, and globalization of ceramics\" as the main research theme, promote the co-construction and sharing of information and resources in related fields worldwide, create a new platform for international exchange and cooperation between relevant scholars and institutions, and jointly promote the protection, inheritance, and innovative utilization of ceramics and its related culture.",
    },
    {
        title:"Chapter 2 Members",
        subtext:"Article 4: The society shall establish group members and individual members, and membership fees are not charged temporarily.\nArticle 5: Group Members: Research institutions, museums, universities, and other organizations related to ceramic collection, research, and preservation shall submit an application for membership to the Secretariat upon recommendation by a member of the Advisory Committee or the Secretariat. After approval, they shall become group members and enjoy the rights and obligations of group membership. \nArticle 6: Individual Members: Those who have a certain influence in the fields of collection, research, and preservation related to ceramics and are recommended by two members or the Secretariat to submit an application for membership to the Secretariat. After approval, they become individual members and enjoy the rights and obligations of individual members. \nArticle 7: Members shall have the following rights\n1. Individual members and group members enjoy the recommendation power of new members; \n2. Individual members and group members are given priority to participate in relevant activities of this society; \n3. Group members have the priority to host society related activities; \n4. Priority in obtaining services from this society; \n5. Provide opinions, suggestions, and supervise the work of the society. \nArticle 8: Members shall fulfill the following obligations \n1. Implement the resolutions of the society; \n2. Safeguard the legitimate rights and interests of the society; \n3. Group members provide convenience for visiting to members of this society. \nArticle 9: Resignation of Members \n1. Group members and individual members can apply for withdrawal from the society, and must submit a written withdrawal application, which will take effect after being approved by the Secretariat; \n2. If group members and individual members violate the provisions of the society\'s articles or engage in serious harm to the interests of the society, the society secretariat has the right to request the general meeting of members to consider and dismiss them.",
    },
    {
        title:"Chapter 3 Organizational Structure",
        subtext:"Article 10: General Meeting of Members \nAll members have the right to participate in the general meeting to review the drafting or modification of the articles of society, as well as the work reports of the advisory committee and the secretariat. The general meeting of members is generally held every two years. Modifications to the articles must be approved by more than two-thirds of the participating members.\nArticle 11: Advisory Committee \nThe members of the Advisory Committee are nominated by the Secretariat and selected through deliberation by the General Meeting of Members. Responsible for providing suggestions on the development direction of the society; Provide consultation on major activities of the society; Coordinate international academic exchanges. The advisory committee shall hold at least one committee meeting per year. \nArticle 12: Secretariat\nThe Secretariat is responsible for the daily operation and transaction processing of the society, located at the Jingdezhen Imperial Kiln Institute in Jingdezhen City, Jiangxi Province, China; The Secretariat shall have a Secretary General, Deputy Secretary General, and several secretaries. Their responsibilities include: \n1. Responsible for drafting or modifying the society charter; \n2. Responsible for providing related services such as membership, withdrawal, and daily communication for society members; \n3.Responsible for convening member meetings and advisory committee meetings; \n4.Under the guidance of the advisory committee, responsible for the specific planning, organization, and preparation of the society\'s academic activities; \n5.Responsible for the construction and maintenance of the society website and database; \n6.Responsible for raising funds;\n7.Responsible for other affairs entrusted by the general meeting of members or advisory committee.",
    },
    {
        title:"Chapter 4 Activities",
        subtext:"Article 13: Establish a member communication platform and publications for information exchange and research results sharing among members. \nArticle 14: Build shared scientific research bases and promote international scientific research cooperation among members. \nArticle 15: Establish an international ceramic database to achieve intuitive and convenient sharing of collection, research, and preservation data on ceramics. \nArticle 16: Establish and improve relevant international standards in the fields of restoration, protection, display, and utilization of ceramics.\nArticle 17: In principle, the society shall hold a large-scale academic seminar every two years, with the advisory committee and the secretariat agreeing on the conference theme and determining the conference venue. \nArticle 18: The society shall hold small-scale academic seminars and exchange activities from time to time every year, which shall be proposed by group members or the secretariat, and shall be held in selected locations after being approved by the secretariat.",
    },
    {
        title:"Chapter 5 Supplementary Provisions",
        subtext:"Article 19: These articles of association shall come into effect from the date of adoption by the general meeting of the society members. \nArticle 20: The power of interpretation of this Articles of Association belongs to the Secretariat of the society.",
    }
];

var articlesList_zh = [
    {
        title:"第一章  总则",
        subtext:"第一条 本联盟的名称为“国际瓷器研究联盟”（Society of International Ceramic Studies），简称SICS。\n第二条 本联盟是由与瓷器收藏、研究、保护等相关机构和个人自愿结成的学术性、国际性、非营利性的专业研究组织。\n第三条 本联盟的宗旨是以“瓷器起源、传播与全球化”为研究主线，推动相关领域的信息和资源在世界范围内的共建共享，打造相关学者和机构之间的国际交流合作新平台，共同促进瓷器及其相关文化的保护、传承和创新利用。",
    },{
        title:"第二章  会员",
        subtext:"第四条 联盟设立团体会员和个人会员，暂不收取会员费用。\n第五条 团体会员：研究机构、博物馆、高等院校等与陶瓷收藏、研究、保护相关的团体，经顾问委员会委员或秘书处推荐，向秘书处提交入会申请书，经批准后成为团体会员，享受团体会员权利，履行团体会员义务。\n第六条 个人会员：在陶瓷收藏、研究、保护领域具有一定影响力，经两名会员或秘书处推荐，向秘书处提交入会申请书，经批准后成为个人会员，享受个人会员权利，履行个人会员义务。\n第七条  会员享有下列权利 \n（一）推荐新会员；\n（二）优先参加联盟的相关活动；\n（三）团体会员有联盟相关活动的主办优先权;\n（四）优先获得本联盟服务；\n（五）对联盟工作提出意见、建议并实施监督。\n第八条  会员履行下列义务\n（一）执行联盟的决议；\n（二）维护联盟的合法权益；\n（三）团体会员应向本联盟会员提供参观、考察便利。\n第九条  会员离退会\n（一）会员可以申请退会，须书面提交退会申请，经秘书处通过后生效；\n（二）会员因违反联盟章程的规定或有严重损害联盟利益的行为，联盟秘书处有权提请会员大会审议将其开除。",
    },
    {
        title:"第三章  机构构成",
        subtext:"第十条 会员大会\n全体会员均有权参加会员大会，负责对章程的拟定或修改，以及顾问委员会和秘书处的工作报告进行审议。会员大会原则上每两年召开一次。对章程的修改需经参会会员的三分之二以上通过。\n第十一条 顾问委员会\n顾问委员会委员由秘书处提名，由会员大会审议产生。负责对联盟的发展方向提出建议；对联盟的重大活动提供咨询；对国际学术交流进行协调。顾问委员会每年至少召开一次委员会议。\n第十二条 秘书处\n秘书处负责联盟的日常运营和事务处理，设在中国江西省景德镇市景德镇御窑博物院；秘书处设秘书长一名，副秘书长和秘书若干名。其职责包括：\n一、起草或修改联盟章程；\n二、联盟会员入会、退会、日常联络等相关服务；\n三、召集会员大会和顾问委员会会议；\n四、在顾问委员会的指导下，策划、组织和筹备联盟学术活动；\n五、联盟网站和数据库的建设与维护；\n六、筹集经费；\n七、会员大会或顾问委员会委托的其他事务。",
    },
    {
        title:"第四章  活动",
        subtext:"第十三条 建立会员通讯平台和出版物，用于会员之间信息互通和研究成果分享。\n第十四条 建设共享科研基地，促进会员开展国际科研合作。\n第十五条 建设国际瓷器数据库，实现陶瓷的收藏、研究、保护数据的直观呈现和便捷共享。\n第十六条 在陶瓷的修复、保护、展示、利用等领域建立和完善相关国际标准。\n第十七条 联盟原则上每两年举办一次大型学术研讨会，由顾问委员会和秘书处商定会议主题、确定会议地点。\n第十八条 联盟每年不定期举办小型学术研讨会和交流活动，由团体会员或秘书处提出，经秘书处审定后择地举办。",
    },
    {
        title:"第五章  附则",
        subtext:"第十九条 本章程自联盟会员大会通过之日起生效。\n第二十条 本章程的解释权属于联盟秘书处。",
    }
];
export function getArticlesListData(locale){
    var articlesList = [];
    if(locale === "zh") articlesList = articlesList_zh;
    else if(locale === "en") articlesList = articlesList_en;
    return articlesList;
}

