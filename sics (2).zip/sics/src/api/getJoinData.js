var memberInfoList_en = [
  {
    title: "Individual Members",
    subtext:
      "Those who have a certain influence in the fields of collection, research, and preservation related to ceramics and are recommended by two members or the Secretariat to submit an application for membership to the Secretariat. After approval, they become individual members and enjoy the rights and obligations of individual members.",
  },
  {
    title: "Group Members",
    subtext:
      "Research institutions, museums, universities, and other organizations related to ceramic collection, research, and preservation shall submit an application for membership to the Secretariat upon recommendation by a member of the Advisory Committee or the Secretariat. After approval, they shall become group members and enjoy the rights and obligations of group membership. ",
  },
  {
    title: "Rights",
    subtext:
      "Members shall have the following rights<br>1. Individual members and group members enjoy the recommendation power of new members; <br />2. Individual members and group members are given priority to participate in relevant activities of this society; <br />3. Group members have the priority to host society related activities; <br />4. Priority in obtaining services from this society; <br /> 5. Provide opinions, suggestions, and supervise the work of the society. ",
  },
  {
    title: "Obligations",
    subtext:
      " Members shall fulfill the following obligations<br>1. Implement the resolutions of the society; <br />2. Safeguard the legitimate rights and interests of the society; <br />3. Group members provide convenience for visiting to members of this society. ",
  },
  {
    title: "Resignation",
    subtext:
      "1. Group members and individual members can apply for withdrawal from the association, and must submit a written withdrawal application, which will take effect after being approved by the Secretariat; <br />2. If group members and individual members violate the provisions of the society's articles of association or engage in serious harm to the interests of the society, the society secretariat has the right to request the general meeting of members to consider and dismiss them.",
  },
];
var memberInfoList_zh = [
  {
    title: "个人会员",
    subtext:
      "在陶瓷收藏、研究、保护领域具有一定影响力，经两名会员或秘书处推荐，向秘书处提交入会申请书，经批准后成为个人会员，享受个人会员权利，履行个人会员义务。",
  },
  {
    title: "团体会员",
    subtext:
      "研究机构、博物馆、高等院校等与陶瓷收藏、研究、保护相关的团体，经顾问委员会委员或秘书处推荐，向秘书处提交入会申请书，经批准后成为团体会员，享受团体会员权利，履行团体会员义务。",
  },
  {
    title: "会员权利",
    subtext:
      "1、推荐新会员；<br>2、优先参加联盟的相关活动；<br />3、团体会员有联盟相关活动的主办优先权;<br />4、优先获得本联盟服务；<br />5、对联盟工作提出意见、建议并实施监督。",
  },
  {
    title: "会员义务",
    subtext:
      "1、执行联盟的决议；<br />2、维护联盟的合法权益；<br />3、团体会员应向本联盟会员提供参观、考察便利。",
  },
  {
    title: "会员离退",
    subtext:
      "1、会员可以申请退会，须书面提交退会申请，经秘书处通过后生效；<br />2、会员因违反联盟章程的规定或有严重损害联盟利益的行为，联盟秘书处有权提请会员大会审议将其开除。",
  },
];

var benefitsList_en = [
  {
    title: "Global Collaboration and Exchange",
    subtext:
      "As a member of the International Society, you will have the opportunity to connect and collaborate with members from different countries and backgrounds. The Society provides a platform for cultural and artistic exchange.",
    number: "01",
  },
  {
    number: "02",
    title: "Common Goals and Impact",
    subtext:
      "The Society is committed to advancing common goals and values, and your membership will enable you to work together with other members, raise collective voices, and achieve greater influence and change.",
  },
  {
    number: "03",
    title: "Professional Resources and Support",
    subtext:
      "As a member, you will have access to professional resources and support provided by the Society. This may include training opportunities, industry insights, research reports, collaborative projects, and more.",
  },
  {
    number: "04",
    title: "Porcelain Conservation and Restoration",
    subtext:
      "The Society typically focuses on the conservation and restoration of porcelain. As a member, you will gain access to the latest knowledge and techniques in porcelain preservation and restoration.",
  },
];
var benefitsList_zh = [
  {
    title: "全球合作与交流",
    subtext:
      "作为国际联盟的成员，您将有机会与来自不同国家和背景的会员建立联系和合作，联盟将为成员提供文化与艺术交流的平台。",
    number: "01",
  },
  {
    number: "02",
    title: "共同目标和影响力",
    subtext:
      "联盟致力于推动共同的目标和价值观，您的加入将使您能够与其他成员共同努力，共同发声，以实现更大的影响力和变革。",
  },
  {
    number: "03",
    title: "专业资源与支持",
    subtext:
      "作为成员，您将获得联盟提供的专业资源和支持。这可能包括培训机会、行业洞察、研究报告、合作项目等。",
  },
  {
    number: "04",
    title: "瓷器保护与修复",
    subtext:
      "联盟通常关注瓷器的保护与修复工作。作为会员，您将获得有关瓷器保护与修复的最新知识和技术。",
  },
];

export function getJoinMemberInfoListData(locale) {
  var infoList = [];
  if (locale === "zh") infoList = memberInfoList_zh;
  else if (locale === "en") infoList = memberInfoList_en;
  return infoList;
}
export function getJoinBenefitsListData(locale){
    var benefitsList = [];
    if (locale === "zh") benefitsList = benefitsList_zh;
    else if (locale === "en") benefitsList= benefitsList_en;
    return benefitsList;
}
