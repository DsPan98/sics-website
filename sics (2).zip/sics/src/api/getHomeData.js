
// 首页新闻与活动页
var section3RightList_zh = [
  {
    id: 3,
    image: "/image/home/section3/right/section3_right_news0.jpg",
    text: "国际瓷器研究联盟————成立大会",
    date: "2023/10/18",
    link: "eventsDetail",
  },
  {
    id: 1,
    image: "/image/home/section3/right/section3_right_news1.jpg",
    text: "2023年英国陶瓷双年展日程公布",
    date: "2023-10-18",
    link: "newsDetail",
  },
  {
    id: 3,
    image: "/image/home/section3/right/section3_right_news2.jpg",
    text: "瓷的旅程—2023景德镇国际陶瓷艺术双年展",
    date: "2023-09-18",
    link: "newsDetail",
  },
  {
    id: 6,
    image: "/image/home/section3/right/section3_right_news3.jpg",
    text: "第13届日本美浓国际陶瓷展开放报名中",
    date: "2023-10-18",
    link:"newsDetail",
  },
];
var section3RightList_en = [
  {
    id: 3,
    image: "/image/home/section3/right/section3_right_news0.jpg",
    text: "SICS——Inaugural Assembly",
    date: "2023/10/18",
    link: "eventsDetail",
  },
  {
    id: 1,
    image: "/image/home/section3/right/section3_right_news1.jpg",
    text: " British Ceramics Biennial 2023 Festival programme announced",
    date: "2023-10-18",
    link: "newsDetail",
  },
  {
    id: 3,
    image: "/image/home/section3/right/section3_right_news2.jpg",
    text:
      "The Journey of Ceramics: 2023 Jingdezhen International Ceramic Art Biennale",
    date: "2023-09-18",
    link: "newsDetail",
  },
  {
    id: 6,
    image: "/image/home/section3/right/section3_right_news3.jpg",
    text:
      "Applications are open for the 13th International Ceramics Competition Mino, Japan",
    date: "2023-10-18",
    link: "newsDetail",
  },
];


/*[l]加入讲座，工作坊等链接，动态数组实现*/
var section4List_zh = [
  {
    number: "01",
    text: "讲座",
    subtext: "权威专家解读陶瓷的历史与文化，一起探索陶瓷的世界。",
    link: "",
  },
  {
    number: "02",
    text: "会议",
    subtext: "汇聚陶瓷行业的智慧，共同探讨未来发展的策略与机遇。",
    link: "",
  },
  {
    number: "03",
    text: "工作坊",
    subtext: "亲手体验陶瓷制作的乐趣，激发创造力与艺术潜能。",
    link: "",
  },
  {
    number: "04",
    text: "实地考察",
    subtext: "踏上陶瓷之旅，探索各地工艺传承和文化遗产。",
    link: "",
  },
];
var section4List_en = [
  {
    number: "01",
    text: "Lectures",
    subtext:
      "Authoritative experts interpret the history and culture of ceramics, exploring the world of ceramics together.",
    link: "",
  },
  {
    number: "02",
    text: "Meetings",
    subtext:
      "Gathering the wisdom of the ceramics industry, discussing strategies and opportunities for future development.",
    link: "",
  },
  {
    number: "03",
    text: "Workshops",
    subtext:
      "Experience the joy of creating ceramics firsthand, unleashing creativity and artistic potential.",
    link: "",
  },
  {
    number: "04",
    text: "Field Trips",
    subtext:
      "Embark on a journey through ceramics, exploring the heritage of craftsmanship and cultural legacy in different regions.",
    link: "",
  },
];

export function getHomeNewsDataById(newsId, locale) {
  // 根据语言类型不同获取 
  var newsList = [];
  if (locale === "zh")
    newsList = section3RightList_zh;
  else if (locale === "en")
    newsList = section3RightList_en;
  // console.log("newsList: ", newsList)
  for (var news in newsList) {
    if (newsList[news].id == newsId) {
      return newsList[news];
    }
  }
}

export function getHomeNewsData(locale) {
  // 根据语言类型不同获取 
  var newsList = [];
  if (locale === "zh")
    newsList = section3RightList_zh;
  else if (locale === "en")
    newsList = section3RightList_en;
  // console.log("newsList: ", newsList)
  return newsList;
}
export function getHomeLecturesData(locale) {
  // 根据语言类型不同获取 
  var lecturesList = [];
  if (locale === "zh")
    lecturesList = section4List_zh;
  else if (locale === "en")
    lecturesList = section4List_en;
  // console.log("newsList: ", newsList)
  return lecturesList;
}
