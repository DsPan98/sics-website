
// 展览列表
var exhibitList = [
  {
    id: 4,
    image: "/image/newsAndEvent/exhibit/exhibit1.png",
    titleCh: "丝路瓷缘•釉见敦煌——瓷画艺术展",
    titleEn: "Decoding Dunhuang In Glaze",
  },
  {
    id: 2,
    image: "/image/newsAndEvent/exhibit/exhibit2.png",
    titleCh: "中国白——德化白瓷展",
    titleEn: "Blanc de Chine",
  },
  {
    id: 10,
    image: "/image/newsAndEvent/exhibit/exhibit3.jpg",
    titleCh: "丹波烧的世界",
    titleEn: "World of TAMBA",
  },
  {
    id: 7,
    image: "/image/newsAndEvent/exhibit/exhibit4.png",
    titleCh: "生于陶土：普韦布洛陶器精神",
    titleEn: "Grounded in Clay",
  },
];

// 活动列表
var eventsList = [
  {
    id: 2,
    image: "/image/newsAndEvent/events/events1.jpg",
    titleCh: "“黑石号”沉船的前世今生",
    titleEn: "Belitung: The Afterlives of a Shipwreck",
  },
  {
    id: 3,
    image: "/image/newsAndEvent/events/events2.jpg",
    titleCh: "国际瓷器研究联盟成立大会",
    titleEn: "Meetings",
  },
  {
    id: 5,
    image: "/image/newsAndEvent/events/events3.png",
    titleCh: "宫廷粉彩陶艺工作坊",
    titleEn: "Workshops",
  },
  {
    id: 6,
    image: "/image/newsAndEvent/events/events4.jpg",
    titleCh: "苏格兰之旅",
    titleEn: "Field Trips",
  },
];

// 新闻列表
var newsList = [
  {
    id: 1,
    image: "/image/newsAndEvent/news/news1.jpg",
    titleCh: "2023年英国陶瓷双年展日程公布",
    titleEn: " British Ceramics Biennial 2023 Festival programme announced",
    contentCh: "从9月23日到11月5日，英国陶瓷双年展(BCB)将回到斯托克，在这座城市的工业遗产背景下举办为期六周的展览、装置和活动。从聚焦英国顶尖的陶艺家，到引进国际艺术家的作品和新鲜的人才，BCB 艺术节是一个庆祝粘土在故事讲述、游戏、冒险和行动主义方面的创造潜力的节日。2023年的艺术家包括 Osman Yousefzada，William Cobbing，Emilie Taylor 和 Stephen Dixon。",
    contentEn: "From 23 September to 5 November, the British Ceramics Biennial (BCB) Festival returns to Stoke-on-Trent for six weeks of exhibitions, installations and events shown against the backdrop of the city's industrial heritage. From spotlighting the UK's leading ceramicists to introducing work by international artists and fresh new talent, the BCB Festival is a celebration of the creative potential of clay for storytelling, playfulness, risk-taking and activism. Artists for 2023 include Osman Yousefzada, William Cobbing, Emilie Taylor and Stephen Dixon.",
  },
  {
    id: 4,
    image: "/image/newsAndEvent/news/news2.jpg",
    titleCh: " CWD——陶瓷世界目的地诞生",
    titleEn: "Ceramic World destinations",
    contentCh: "由朱迪思•施瓦茨（Judith S. Schwartz）担任主席的纽约现代艺术博物馆（MoCA）刚刚发布了一个名为 “陶瓷世界目的地”（CWD - Ceramic World destinations）的网站，介绍世界各地的与陶瓷相关的博物馆、大学、艺术家、历史遗迹和工作坊等。\n其中，MIC和Faenza等无数陶瓷机构都是不容错过的。",
    contentEn: "MoCA in New York, chaired by Judith S. Schwartz, has just published CWD - Ceramic World destinations a website that maps ceramics around the world, museums, universities, schools, workshops, artists, historical monuments, and workshops.\nMIC and Faenza with its countless realities could not be missed.\nTake a look and support the project: https://moca-ny.org/cwd",
    site: "https://www.micfaenza.org/en/2023/08/cwd-ceramic-world-destinations-is-born/",
  },
  {
    id: 6,
    image: "/image/newsAndEvent/news/news3.jpg",
    titleCh: "第13届日本美浓国际陶瓷展开放报名中",
    titleEn: "13th International Ceramics Competition Mino, Japan",
    contentCh: "“日本美浓国际陶瓷展”是“日本美浓国际陶瓷节”的主要活动，旨在通过全球陶瓷设计和文化交流，促进陶瓷工业的发展和文化的提升。这是自1986年首次举办以来的第13届国际陶瓷比赛。每届比赛都会设置评审团，来自世界各地的知名评委们，会对不同国家的参赛作品进行评选。在上一届比赛中，我们收到了来自64个国家和地区的1292名申请者的精彩作品，共计2435件。如此庞大的比赛规模和高质量的作品，让我们的陶瓷比赛真正成为当今世界的代表。",
    contentEn: "\"The International Ceramics Exhibition Mino, Japan\" is the main event of the \"International Ceramics Festival Mino, Japan,\" which is held with the aim of supporting the growth of the ceramics industry and the enhancement of culture through the global exchange of ceramics design and culture. This is the 13th international ceramics competition since the first one was held in 1986. Each competition is judged by a panel of distinguished judges from around the world, and entries are received from various countries. In the last competition, we had amazing 2,435 entries from 1,292 applicants coming from 64 countries and areas around the world. The scale and high quality made our ceramics competition truly the representative of the world today.",
  },
];

export function getExhibit() {
  return exhibitList;
}

export function getNews() {
  return newsList;
}
export function getEvents() {
  return eventsList;
}
