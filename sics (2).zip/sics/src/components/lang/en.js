const en = {
  menu:{
    homePage: 'Home',
    about: 'About',
    newsAndEvents:'News & Events',
    news1:'News',
    news2:'Exhibitions',
    news3:'Events',
    research: 'Research',
    research1: 'Work Station',
    research2: 'Gene Bank',
    research3: 'Robotic System',
    research4: 'Projects',
    research: 'Research',
    map: 'Map',
    join: 'Join',
    clickHere:'Click here',
    //TODO 暂译名：研究research
    //TODO2
    langSwitch: 'Switch Language',
    enter:'Go',
  },
  section1:{
    title:'Society of International Ceramic Studies',
    // title:'CERAMIC',
    porcelainSeg1:'Through ceramic',
    porcelainSeg2:'',
    porcelainSeg3:'',
    porcelainSeg4:'Explore the material civilization of humanity',
    porcelainSeg5:'',
    porcelainSeg6:'',
    button:'About Us',
  },
  section2:{
    workStation:'SICS Work Station',
    archaeology:'Archaeology',
    restoration:'Restoration',
    research:'Research',
    geneBank:'Ceramic Gene Bank',
    sets:' sets',
    specimens:' specimens',
    workStation_label:'more',
    dataSeg1:'',
    dataSeg2:' 300,000',
    dataSeg3:' pieces of information',
    genebank_label:'more'
  },
  genebank:{
    geneBank:'Gene Bank',
    sets:' sets',
    specimens:' specimens',
    dataSeg1:'',
    dataSeg2:' 300,000',
    dataSeg3:' pieces of information',
    explore:'Gene Bank',
    research:'Research',
    genebankCurrent:'Gene Bank',
    introduction:'Introduction',
  },

  section3:{
    news:'News and Events',
    news1:'The cultural exchange event titled "The Story of Porcelain:Century-long Exchange between China and the Arab Islamic World:" was held in Riyadh, Saudi Arabia.',
    news2:'section3.news2 placeHolder, currently no translation',
    news3:'section3.news3 placeHolder, currently no translation',

  },
  section5:{
    text1:'Imperial Kiln Universe ',
    text2:'Mystery of Blue and White',
    subtext:' Online Exhibition',
  },
  section6:{
    global:'Collaboration',
    goals:'Membership',
    support:'Support',
    restoration:'Conservation',
    join:'Join',
  },
  /*
  section6:{
    global:'Global Collaboration and Exchange',
    goals:'Common Goals and Impact',
    support:'Professional Resources and Support',
    restoration:'Porcelain Conservation and Restoration',
    join:'Join',
  },*/

  /*[u]国家文物局 官网翻译*/
  /*[u]景德镇博物院 官网翻译*/
  section7:{
    contact:'Contact Us',
    website:'Related Sites',
    administration:'National Cultural Heritage Administration',
    society:'Oriental Ceramic Society',
    jingdezhen:'Jingdezhen Imperial Kiln Institute',
    address:'Address: No.169, Lianshe North Road, Zhushan District, Jingdezhen City, Jiangxi Province, China.',
    tel:'Phone: 0798-8210396'
  },
  aboutPage: {
    section1: {
      title: 'West Encounters East',
      subTitle: '',
    },
    introduction: {
      title: 'Introduction',
      text: 'This society is an academic, international, and non-profit professional research organization voluntarily formed by institutions and individuals involved in porcelain collection, research, preservation, and related fields. With data as our foundation and research as our means, we aim to establish collaborations within and across disciplines, sharing research facilities and resources worldwide. Through this, we strive to tackle research topics that require international cooperation and hold global significance.',
    },
    mission: {
      title: 'Mission',
      text: 'With the research theme of "Origin, Dissemination, and Globalization of Porcelain," we aim to facilitate the collaborative construction and sharing of information and resources in related fields on a global scale. We seek to establish a new platform for international exchange and cooperation among scholars and institutions, fostering the protection, inheritance, and innovative utilization of porcelain and its associated culture',
    },
    declaration: {
      title: 'Declaration',
      text: "Porcelain, as a great invention of ancient society, is a milestone in human development history. It has greatly changed the world's production and trade patterns and people's social lifestyles, and has also become an important carrier for human civilization exchange and mutual learning. ",
    },
    rules: {
      title: 'Articles',
      text1: 'The name of this society is "Society of International Ceramic Studies", abbreviated as SICS.',
      text2: '',
      text3: ''
    },
    institution: {
      committee: 'Advisory Committee',
      constitute: 'Organizational Structure',
      meeting: 'General Meeting of Members',
      secretariat: 'Secretariat',
    },
    member: {
      title: 'Member Origins',
      info: '*Sort by alphabetical order',
    },
  },
  newsAndEventsPage: {
    exhibitTitle: 'Exhibitions',
    eventsTitle: 'Events',
    newsTitle: 'News',
    more: 'more',
  },
  researchPage: {
    researchBanner: 'RESEARCH',
    workStation: 'Work Station',
    workStationText: 'The workstation is equipped with state-of-the-art software and hardware, providing comprehensive support for the archaeology, research, and restoration of ceramics. In addition, our workstation serves as a ceramics research and learning center, dedicated to promoting the popularization and education of ceramic culture.',
    geneBank: 'Gene Bank',
    geneBankText: 'The gene bank was built on June 11, 2022 to trace information such as the body, glaze, pigment, and craftsmanship of more than 20 million pieces of ancient ceramic fragments unearthed in Jingdezhen.',
    roboticSystem: 'Robotic System',
    roboticSystemText: 'A robotic system for making "gene" specimens of ancient ceramics jointly developed by the Jingdezhen Imperial Kiln Museum and the Academy for Engineering and Technology under Fudan University, the first of its kind in the world, was put into use in the gene bank this year, significantly improving the efficiency of making "gene" specimens.',
    project: 'Projects',
    project1: 'Restoration',
    project2: 'Research',
    project3: 'Archaeology',
  },
  workStation: {
    research: "Research",
    workStation: "Work Station",
    title: 'Society of International\n Ceramic Studies\n Work Station',
    introduction: 'The work station aims to become a comprehensive center for ceramic research and learning, fostering academic exchange, knowledge inheritance, and research innovation. We welcome individuals interested in ancient ceramics to join our workstation and together explore the charm and history of ceramics.',
    researchTitle: 'Research and Learning Resources',
    researchText: 'The work station possesses a vast collection of ceramic specimens from the Tang, Song, Yuan, Ming, and Qing dynasties, including official kilns and folk kilns. These specimens serve as crucial resources for research and academic exchange. Researchers can study various aspects of ancient ceramics, such as body composition, decorative patterns, and glaze colors.',
    equipmentTitle: 'Scientific Research Equipment',
    equipmentText: 'The work station is equipped with comprehensive facilities and a professional team for ceramic archaeology, categorization, restoration, and scientific analysis. These resources enable in-depth exploration of ceramic history, production techniques, and cultural backgrounds. Through scientific methods, ceramics can be analyzed and authenticated.',
    studyTitle: 'Study Base',
    studyText: 'The work station has a study base that provides comfortable accommodations and a multifunctional lecture hall for researchers and students. Researchers can engage in academic exchanges within this environment, collectively driving the development and advancement of the ceramic field. Students have the opportunity to closely interact with diverse ceramic specimens, immersing themselves in the enchantment of ancient ceramics.',
  },
  word:{
    aboutUs:'About us'
  },
  language: {
    language: 'Language',
    zh: 'Chinese',
    en: 'English',
    switch: '中文'
  },

  articles:{    
    title:'Society of International Ceramic Studies',
    about:'About',
    articles:'Articles',

  },
  declaration:{
    about:'About',
    title:'Society of International Ceramic Studies',
    subtitle:'Society of International Ceramic Studies Declaration of Establishment',
    declaration:'Declaration',
    subtext: 'Ceramics, as a great invention of ancient society, is a milestone in human development history. It has greatly changed people\'s lifestyles, and was able to be produced, exchanged, and evolved around the world, ultimately forming a rich and colorful ceramic culture and world ceramic civilization circle. Thus, the study of ceramics has important value and significance for a profound understanding of the past, present, and future of human civilization exchange and mutual learning.\nDue to the important value and significance of ceramics, scholars from various countries have conducted multidimensional and systematic research on it from aspects such as art appreciation, dating, production kiln identification, process analysis, cultural and technological exchanges, and trade exchanges. However, there is a significant dispersion or even fragmentation in the dissemination of materials, sharing of achievements, exploration of viewpoints, and cooperation in research, and there is great room for improvement in interdisciplinary and cross-border integration.\nIn view of this, we have decided to establish the \"Society of International Ceramic Studies\" to promote the co-construction and sharing of information and resources in related fields worldwide, create a new platform for international exchange and cooperation between relevant scholars and institutions, and jointly promote the protection, inheritance, and innovative utilization of ceramics and its related culture.\nFirstly, we believe that the community is the foundation. This society is an international, non-profit, non-governmental academic organization voluntarily formed by institutions and individuals related to collection, research, and preservation of ceramics. The society encourages rigorous academic attitudes and methods, respects different cultures and traditions, and actively builds an interactive and mutually beneficial exchange atmosphere and community.\nSecondly, we believe that information is the pillar. Academia cannot do without data. Building a common platform for information dissemination and sharing, while respecting and protecting intellectual property rights, is crucial for the comprehensive sharing of world ceramic collection, research, and preservation materials in the new era of ceramic research. \nOnce again, we believe that project work is the means. The society will focus on the study of the origin, spread, and globalization of ceramics, exploring the origin and background of ceramics in different porcelain producing regions around the world; Discuss the distribution and development of ceramic products, processes, and culture; Explore the exchange and mutual learning of ceramics and related culture on a global scale, as well as contemporary inspiration.\nFinally, we believe that cooperation is the key. Cooperation includes both team composition and interdisciplinary collaboration, as well as advocating for the sharing of relevant research facilities and resources worldwide, in order to establish and tackle research topics that require more international cooperation and global significance.\nAs the saying goes: \"Like-minded individuals do not take mountains and seas as their distance.\" Let\'s join hands to form a close community of information sharing and multi-dimensional cooperation, vigorously promote the prosperity and development of ceramic research, inherit and enjoy such spiritual home and great wealth created by humanity for a long history!',
  },
  newsList:{
    title:'News',
    newsAndEvents:'News & Events',
    newsList:'News',
    details:'Details',
    news:'News ',
    source:'Source: ',
    date:'Updated: ',
    more:'For more details: '
  },
  eventsList:{
    title:'Events',
    newsAndEvents:'News & Events',
    eventsList:'Events',
    details:'Details',
    events:'Events ',
    source:'Source: ',
    dates:'Dates: ',
    location:'Location: ',
    more:'For more details: ',
    host:'Host: ',
    space:' ',
  },
  exhibitionsList:{
    title:'Exhibitions',
    newsAndEvents:'News & Events',
    exhibitionsList:'Exhibitions',
    details:'Details',
    exhibitions:'Exhibitions ',
    source:'Source: ',
    dates:'Dates: ',
    more:'For more details: ',
    location:'Location: ',

  
  },
  join:{
    become:'Become a member',
    benefits:'Member benefits',
  },
  map:{
    title:'Interactive Map of World Ceramic',
    titleEn:'',
    subtitle:'',
    subtitleEn:'',
    intro:'What\'s the map',
    introSubtext:'It is a cross-regional, cross-organizational, multi-lingual platform for building and sharing a world porcelain knowledge base. Through the deduction of spatial and temporal relationships and the correlation of multiple sources of knowledge, it can better demonstrate the spatial and temporal laws of the origin, dissemination and exchange of world porcelain, and reveal the development of porcelain in various countries as well as the far-reaching influence of Chinese porcelain.',
    discover:'Discover',
    bottomItem1:'Collection Search',
    bottomItem2:'Map Interactive',
    bottomItem3:'Knowledge Visualization Mapping',
    bottomItem4:'Exhibition Summary',
  },

  footer:{
    contact:'Contact Us',
    website:'Related Sites',
    administration:'National Cultural Heritage Administration',
    society:'Oriental Ceramic Society',
    jingdezhen:'Jingdezhen Imperial Kiln Institute',
    address:'Address: No.169, Lianshe North Road, Zhushan District, Jingdezhen City, Jiangxi Province, China.',
    tel:'Phone: 0798-8210396'
  },
  miscellaneous:{
    space:'',
  }
  
}
export default en;
