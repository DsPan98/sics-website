const state = {
  newsId: 1,
  exhibitionsId: 1,
  eventsId: 1,
  // 标题栏背景颜色
  pageHeaderBackcolor: "",
  count: 0,
  // 当前首页（分类或地域），未设定时默认为分类
  homepage: "category",
  // 当前浏览的地域id，默认为北京
  regionid: "1",
  // 当前浏览的分类id，默认为民间文学
  categoryid: "1",
  // 当前浏览的主题分类id，默认为t1
  topictype: "t1"
};

const mutations = {
  increment(state) {
    state.count++;
  },
  updateNewsId(state,newsId) {
    state.newsId = newsId
  },
  updateExhibitionsId(state,exhibitionsId) {
    state.exhibitionsId = exhibitionsId
  },
  updateEventsId(state,eventsId) {
    state.eventsId = eventsId
  },
  updatePageHeaderBackcolor(state,pageHeaderBackcolor) {
    state.pageHeaderBackcolor = pageHeaderBackcolor
  },
  updateHomePage(state,homepage) {
    state.homepage = homepage
  },
  updateRegionId(state,regionid) {
    state.regionid = regionid
  },
  updateCategoryId(state,categoryid) {
    state.categoryid = categoryid
  },
  updateTopicType(state,topictype) {
    state.topictype = topictype
  },
};

const actions = {
  increment({ commit }) {
    commit('increment');
  },
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
};
