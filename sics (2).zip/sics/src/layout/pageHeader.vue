<template>
  <div id="fullPageClass">
    <div id="header" :style="{ background: headerBackground }">
      <div id="leftBox">
        <img src="/image/head/sics_logo.png" class="iconImgClass" />
      </div>
      <div id="rightBox">
        <div
          class="header-right-gap header-link-style header-link-underline"
          :class="currentPageName == 'home' ? 'header-link-underline-active' : ''"
          @click="navigateTo('/home', 'home')"
        >
          {{ $t("menu.homePage") }}
        </div>
        <div
          class="header-right-gap header-link-style header-link-underline"
          :class="currentPageName == 'about' ? 'header-link-underline-active' : ''"
          @click="navigateTo('/about', 'about')"
        >
          {{ $t("menu.about") }}
        </div>
        <div class="header-right-gap header-link-style header-link-underline">
          <el-dropdown
            :hide-on-click="false"
            trigger="hover"
            placement="bottom"
            @click.native="navigateTo('/newsAndEvent', 'newsAndEvent')"
          >
            <span
              class="header-link-style"
              :class="currentPageName == 'newsAndEvent' ? 'header-link-active' : ''"
              >{{ $t("menu.newsAndEvents") }}<i class="el-icon-arrow-down"></i
            ></span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                @click.native="navigateTo('/news', 'news')"
                class="el-dropdown-style"
                >{{ $t("menu.news1") }}</el-dropdown-item
              >
              <el-dropdown-item
                @click.native="navigateTo('/exhibitions', 'news')"
                class="el-dropdown-style"
                >{{ $t("menu.news2") }}</el-dropdown-item
              >
              <el-dropdown-item
                @click.native="navigateTo('/events', 'news')"
                class="el-dropdown-style"
                >{{ $t("menu.news3") }}</el-dropdown-item
              >
            </el-dropdown-menu>
          </el-dropdown>
        </div>

        <div class="header-right-gap header-link-style-lang header-link-underline">
          <el-dropdown :hide-on-click="false" trigger="hover" placement="bottom" 
            @click.native="navigateTo('/research', 'research')">
            <span
              class="header-link-style"
              :class="currentPageName == 'research' ? 'header-link-active' : ''"
              >{{ $t("menu.research") }}<i class="el-icon-arrow-down"></i
            ></span>

            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                @click.native="navigateTo('/workStation', 'workStation')"
                class="el-dropdown-style"
                >{{ $t("menu.research1") }}</el-dropdown-item
              >
              <el-dropdown-item
                @click.native="navigateTo('/genebank', 'genebank')"
                class="el-dropdown-style"
                >{{ $t("menu.research2") }}</el-dropdown-item
              >
              <!-- <el-dropdown-item
                @click.native="navigateTo('/news3', 'news')"
                class="el-dropdown-style"
                >{{ $t("menu.research3") }}</el-dropdown-item
              >
              <el-dropdown-item
                @click.native="navigateTo('/news3', 'news')"
                class="el-dropdown-style"
                >{{ $t("menu.research4") }}</el-dropdown-item
              > -->
            </el-dropdown-menu>
          </el-dropdown>
        </div>

        <div
          class="header-right-gap header-link-style header-link-underline"
          :class="currentPageName == 'map' ? 'header-link-underline-active' : ''"
          @click="navigateTo('/map', 'map')"
        >
          {{ $t("menu.map") }}
        </div>

        <div
          class="header-right-gap header-link-style header-link-underline"
          :class="currentPageName == 'join' ? 'header-link-underline-active' : ''"
          @click="navigateTo('/join', 'join')"
        >
          {{ $t("menu.join") }}
        </div>
        <div class="header-right-gap header-link-style-lang">
          <el-dropdown
            style="cursor: pointer"
            :hide-on-click="false"
            trigger="hover"
            placement="bottom"
          >
            <span class="header-link-style"
              >{{ getMenuLangText }}<i class="el-icon-arrow-down"></i
            ></span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item @click.native="changeLang('zh')">{{
                $t("language.zh")
              }}</el-dropdown-item>
              <el-dropdown-item @click.native="changeLang('en')">{{
                $t("language.en")
              }}</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <div
          id="header-button"
          :hide-on-click="false"
          trigger="hover"
          @click="intoMapWebSite()"
        >
          <img src="/image/head/header_enter_icon.png" class="header-button-label" />
          <div class="header-button-text">
            {{ $t("menu.enter") }}<i class="el-icon-arrow-right"></i>
          </div>
        </div>
      </div>
    </div>
    <div class="contents" :key="componentKey">
      <div class="content">
        <router-view></router-view>
      </div>
    </div>
    <div id="footer">
      <div id="footer">
        <div class="footer-label"></div>
        <div id="footer-content">
          <div id="footer-content-left">
            <div class="footer-content-left-text">
              {{ $t("footer.contact") }}
            </div>
            <div class="footer-content-left-subtext">
              {{ $t("footer.address") }}<br />{{ $t("footer.tel") }}
            </div>
          </div>
          <div id="footer-content-right">
            <div class="footer-content-right-text">
              {{ $t("footer.website") }}
            </div>
            <div id="footer-content-right-subtext">
              <a
                href="http://www.ncha.gov.cn/index.html"
                target="_blank"
                class="footer-content-right-link"
                >{{ $t("footer.administration") }}</a
              >
              <a
                href="https://www.orientalceramicsociety.org.uk/"
                target="_blank"
                class="footer-content-right-link"
                >{{ $t("footer.society") }}</a
              >
              <a
                href="http://www.jdzyybwy.com/jdzmu/frontend/pg/index"
                target="_blank"
                class="footer-content-right-link"
                >{{ $t("footer.jingdezhen") }}</a
              >
            </div>
          </div>
        </div>
        <div id="footer-bottom">
          <template v-if="currentLanguage == 'en'">
            <div class="footer-bottom-left">Copyright © 2023 sics.link All rights reserved 赣ICP备2023010628号-1</div>
          </template>
          <template v-else>
            <div class="footer-bottom-left">赣ICP备2023010628号-1</div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "pageHeader",
  methods: {
    navigateTo(path, name) {
      this.currentPageName = name;
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    intoMapWebSite() {
      window.open("https://www.baidu.com", "_blank");
    },
    changeLang(lang) {
      this.$i18n.locale = lang;
      this.componentKey += 1;
      localStorage.setItem("language", lang);
    },
    scrollTo(sectionId) {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: "smooth" });
      }
    },
    currentScroll() {
      if (window.scrollY <= 50) {
        //at top
        this.headerBackground = "rgba(255,255,255,0)";
      } else {
        this.headerBackground = "rgba(255,255,255,0.9)";
      }
    },
  },
  data() {
    return {
      currentPageName: "home",
      componentKey: 0,
      headerBackground: "rgba(255,255,255,0)",
    };
  },
  mounted() {
    this.currentPageName = this.$route.name;
    window.addEventListener("scroll", this.currentScroll);
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.currentScroll);
  },
  watch: {
    $route(to, from) {
      console.log(to);
      this.currentPageName = to.name;
    },
    getPageHeaderBackColor(to, from) {
      this.headerBackground = to;
    },
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
    getPageHeaderBackColor() {
      return this.$store.state.state.pageHeaderBackcolor;
    },
    getMenuLangText() {
      var text = "language." + this.$i18n.locale;
      return this.$t(text);
    },
  },
};
</script>

<style></style>

<style lang="scss" scoped>
.contents {
  width: 100%;
  margin: 0;
  padding: 0;
}
.content {
  width: 100%;
  margin: 0;
  padding: 0;
}
/* 去除el-dropdown下拉框三角 */
.el-popper {
  overflow: auto;
}
.el-dropdown-menu {
  box-shadow: none;
  min-width: 120px;
}

.el-dropdown-menu__item {
  text-align: center;
  font-family: "AlibabaPuHuiTiR";
  font-size: 16px;
  color: #666666;
}

.pageHeaderElDropdownMenuItem {
  text-align: center;
  font-family: "AlibabaPuHuiTiR";
  font-size: 16px;
  color: #666666;
}

.el-dropdown-menu__item:hover {
  background: #f3f3f3 !important;
  color: #666666 !important;
}

// 下拉框居中
::v-deep .el-dropdown-menu {
  position: absolute !important;
  left: auto !important;
  right: 0;
  .popper__arrow {
    left: 50% !important;
  }
}
// .dropdown-menu-research-class /deep/ .el-dropdown-menu {
//   /* transform-origin: center center; */
//   /* margin-left: 3vw; */
//   // width: 200px;
//   transform: translateX(4vw);
// }

#fullPageClass {
  width: 100vw;
  overflow: hidden;
  // width: 100%;
  height: 100%;
  display: flex;
  /* align-items: center; */
  flex-direction: column;
  justify-content: space-between;
  min-width: 910px;
  // overflow-x: hidden;
  overflow-x: auto;
}
#header {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  // height: 4.2vw;
  // height: 4.2vw;
  height: 65px;
  min-height: 50px;
  max-height: 65px;
  width: 100%;
  background: rgb(255, 255, 255);
  background-size: cover;
  flex-grow: 1;
  transform-origin: top left; /* for scaling */
  padding-left: 3%;
  padding-right: 2%;
  // min-width: 890px;
}
#leftBox {
  // border: 1px solid black;
  display: flex;
  flex-direction: center;
  justify-content: center;
  min-width: 160px;
  .iconImgClass {
    /* height: 60px; */
    width: 8.3vw;
    min-width: 95px;
  }
}
#header-button {
  height: 30px;
  min-width: 90px;
  border: 2px grey solid;
  /* object-fit: cover; */
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  margin-left: 5px;
  cursor: pointer;

  .header-button-label {
    height: 18px;
  }
  .header-button-text {
    /* border: 1px solid black; */
    margin-left: 5px;
    height: 100%;
    width: 50%;
    font-family: "AlibabaPuHuiTiR", sans-serif;
    font-size: 15px;
    white-space: nowrap;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
#rightBox {
  // border: 1px blue solid;
  // flex: 0.6;
  // min-width: 50%;
  flex-direction: row;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-left: 3vw;
  height: 100%;
  // min-width: 800px;
}

.header-right-gap {
  margin-right: 3vw;
}

// 此处上下边界设置用于调整下拉框的位置
.header-link-style:hover,
.header-link-style:active,
.header-link-style a,
.header-link-style,
.header-link-style-lang:hover,
.header-link-style-lang:active,
.header-link-style-lang a,
.header-link-style-lang {
  // border: 1px red solid;
  display: flex;
  align-items: center;
  // margin-right: 0.8vw;
  padding: 1vw 0vw 1vw 0vw;
  white-space: nowrap;
  color: black;
  font-family: "AlibabaPuHuiTir";
  font-size: 18px;
  height: 100%;
  //给当前元素添加相对定位,也就是after的父级
  position: relative;
  cursor: pointer;
}
.header-link-style-lang:hover,
.header-link-style-lang:active,
.header-link-style-lang a,
.header-link-style-lang {
  /* margin-right: 0%;
  padding-right: 0%; */
  font-family: "AlibabaPuHuiTiB";
}

.header-link-style:hover,
.header-link-style:active {
  color: #2775b6;
  font-weight: bold;
  font-family: "AlibabaPuHuiTiR";
}

/* .header-link-underline {
  
  transform: scaleX(1);
  transform-origin: bottom left;
} */

// hover及点击后的首页按钮下划线
.header-link-underline:hover,
.header-link-underline:active {
  &:after {
    content: " ";
    // width: 2.8vw;
    width: 100%;
    min-width: 36px;
    height: 6px;
    background: #2775b6;
    position: absolute;
    //  bottom: -0.1rem;
    left: 50%;
    top: 92%;
    transform: translateX(-50%); //居中处理
  }
}
.header-link-underline-active {
  font-weight: bold;
  color: #2775b6;
  font-family: "AlibabaPuHuiTiR";
  &:after {
    content: " ";
    // width: 2.8vw;
    width: 100%;
    min-width: 36px;
    height: 6px;
    background: #2775b6;
    position: absolute;
    //  bottom: -0.1rem;
    left: 50%;
    top: 92%;
    transform: translateX(-50%); //居中处理
  }
}

.header-link-active {
  color: #2775b6;
  font-family: "AlibabaPuHuiTiR";
}

#navClass {
  flex: 1;
  // border: 2px purple;
  display: flex;
  text-align: right;
  font-family: "italicFont";
  font-size: 2vw;
}

#header-research {
  object-fit: flex;
  flex-direction: column;
  flex-grow: 1;
  position: relative;
}

#footer {
  // flex-grow: 1;
  align-self: center;
  width: 100%;
  min-width: 100%;
  margin: 0;
  padding: 0;
  background-size: contain;
  background-color: #144a74;
  background-repeat: no-repeat;
  background-position: center;
  flex-direction: column;
  justify-content: space-between;
  object-fit: cover;
  position: relative;
  // margin: auto;
}
.footer-label {
  background-size: contain;
  background-repeat: no-repeat;
  align-self: left;
  background-image: url("/image/home/section7/sics_logo_transparent.png");
  height: 3vw;
  margin-left: 12.5%;
  margin-top: 3%;
  margin-right: 10%;
}
#footer-content {
  flex: 1;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  color: white;
  margin-top: 1%;
  margin-left: 11%;
  text-align: left;
  font-size: 1.2vw;
  font-family: AlibabaPuHuiTiB;
  margin-bottom: 2%;
}
#footer-content-left {
  flex: 0.6;
}
#footer-content-right {
  margin-left: 5%;
  flex: 0.4;
}
#footer-content-right-subtext a,
#footer-content-right-subtext:hover,
#footer-content-right-subtext {
  background-color: #144a74;
  color: white;
  font-family: "AlibabaPuHuiTiR";
}
.footer-content-left-text {
  margin: 3%;
  font-size: 1.3vw;
  font-family: "AlibabaPuHuiTiH";
}
.footer-content-left-subtext {
  margin: 3%;
  font-size: 1.2vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  font-family: "AlibabaPuHuiTiR";
}
.footer-content-right-text {
  margin: 3%;
  font-size: 1.3vw;
  font-family: "AlibabaPuHuiTiH";
}

.footer-content-right-link {
  margin: 3%;
  color: white;
  flex: 1;
  display: flex;
  font-size: 1.2vw;
  font-family: "AlibabaPuHuiTiR";
}
.section-content-right {
  flex: 1;
}
#footer-bottom {
  flex: 1;
  color: white;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 3%;
  font-size: 1.2vw;
  font-family: "AlibabaPuHuiTiR";
}
.footer-bottom-left {
  // flex: 1;
  text-align: center;
  color: white;
}
.footer-bottom-right {
  // flex: 1;
  text-align: center;
  color: white;
}

html {
  scroll-behavior: smooth !important;
}
</style>
