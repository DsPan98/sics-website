<template>
  <div id="container">
    <!--section0 placeholder
            section1 背景图片
            section2 成为一员部分
            section3 成员优势
    -->
    <!--1.比例问题 62.5% 中间 两侧分别为18.75%
2.顶部图片占比100%
3.成为会员
	title 40px H #3565a7 左对齐 ->
	圈内文字 22px B #2775b6 ->
	五个圆圈等比分，左右贴边 中间加入横线
	subtext框
	subtitle 左对齐 26px H #333333 左对齐, #E6F4FF框 ->
	subtext 左对齐整体 #2775b6 24px R #F4FAFF框->

4.成员优势
	title同成为一员title ->
	child 左右贴边 等分 背景色rgba(39, 117, 182, 0.21)
	数字 40px 白色 B，背景#2775B6
	subtitle 居中 26px H #2775B6
	subtext 左对齐 20px R #FAFAFA

    40px -> 同章程大字30px
    26px -> 小于第一章28。。。，大于文字24 ->19px
    22px ->小于文字24 ->17px
    20px -> 16px
    -->
    <div id="section0"></div>
    <div id="section1">
      <img src="/image/join/join_background.jpg" style="width: 1920px; height: auto" />
    </div>
    <div id="section2">
      <div class="section2-spacing"></div>
      <div id="section2-content">
        <div id="section2-content-member">
          <div class="section2-content-member-title">
            {{ $t("join.become") }}
          </div>
          <div id="section2-content-member-circles">
            <div class="member-dashed-line"></div>
            <div
              class="section2-content-member-circle"
              v-for="(item, index) in memberInfoList"
              :key="index"
              @click="selectedInfo = index"
              :class="{ 'active-button-style': selectedInfo === index }"
            >
              {{ item.title }}
            </div>
            <!--用 v-for实现-->
          </div>
          <div
            id="section2-content-member-info"
            v-for="(item, index) in memberInfoList"
            :key="index"
            v-if="selectedInfo === index"
          >
            <div class="section2-content-member-subtitle">{{ item.title }}</div>
            <div class="section2-content-member-subtext">
              <span v-html="item.subtext" />
              <!-- {{ item.subtext }} -->
            </div>
          </div>
        </div>
        <div id="section2-content-benefits">
          <div class="section2-content-benefits-title">
            {{ $t("join.benefits") }}
          </div>
          <div id="section2-content-benefits-items">
            <div
              class="section2-content-benefits-item"
              v-for="(item, index) in benefitsList"
              v-if="index <= 1"
              :key="index"
            >
              <div class="section2-content-benefits-number">{{ item.number }}</div>
              <div class="section2-content-benefits-subtitle">{{ item.title }}</div>
              <div
                :class="
                  currentLanguage == 'en'
                    ? 'section2-content-benefits-subtext-en'
                    : 'section2-content-benefits-subtext'
                "
              >
                {{ item.subtext }}
              </div>
            </div>
          </div>

          <div id="section2-content-benefits-items">
            <div
              class="section2-content-benefits-item"
              v-for="(item, index) in benefitsList"
              v-if="index > 1"
              :key="index"
            >
              <div class="section2-content-benefits-number">{{ item.number }}</div>
              <div class="section2-content-benefits-subtitle">{{ item.title }}</div>
              <div
                :class="
                  currentLanguage == 'en'
                    ? 'section2-content-benefits-subtext-en'
                    : 'section2-content-benefits-subtext'
                "
              >
                {{ item.subtext }}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section2-spacing"></div>
    </div>
  </div>
</template>
<script scoped>
import{
  getJoinMemberInfoListData,
  getJoinBenefitsListData,
} from "@/api/getJoinData";
export default {
  beforeMount(){
    this.getCurrentMemberInfoData();
    this.getCurrentBenefitsData();
  },
  data() {
    return {
      memberInfoList:[],
      benefitsList:[],
      selectedInfo: 1,
    };
  },
  methods:{
    getCurrentMemberInfoData(){
      this.memberInfoList = getJoinMemberInfoListData(this.$i18n.locale);
    },
    getCurrentBenefitsData(){
      this.benefitsList = getJoinBenefitsListData(this.$i18n.locale);
    },
    
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },

  },
};
</script>

<style scoped>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#section0 {
  height: 70px;
}
#section2 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
#section2-content {
  display: flex;
  flex-direction: column;
  flex: 0.625;
}

.section2-spacing {
  flex: 0.1875;
}
#section2-content-member-circles {
  /* border: 2px red solid; */
  margin-top: 3vw;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 2.5vw;
}
.member-dashed-line {
  border: 1.5px #2775b6 dashed;
  position: absolute;
  top: 49%;
  width: 100%;
  z-index: 1;
}
.section2-content-member-circle {
  user-select: none;
  cursor: pointer;
  background: #ffffff;
  display: flex;
  /* flex:0.15; */
  border: 1px solid #2775b6;
  border-radius: 50%;
  width: 8vw;
  height: 8vw;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  z-index: 2;
  font-family: "AlibabaPuHuiTiB";
  font-size: 17px;
  text-align: center;
  color: #2775b6;
  padding: 1vw;
}

.section2-content-benefits-title,
.section2-content-member-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #3565a7;
  margin-top: 4vw;
  margin-bottom: 2.5vw;
}
#section2-content-member-info {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
}
.section2-content-member-subtitle {
  /* white-space: pre-wrap; */
  text-align: left;
  font-family: "AlibabaPuHuiTiH";
  font-size: 19px;
  color: #333333;
  background-color: #e6f4ff;
  padding: 20px;
}
.section2-content-member-subtext {
  flex: 0.9;
  text-align: left;
  font-family: "AlibabaPuHuiTiR";
  font-size: 17px;
  line-height: 30px;
  color: #2775b6;
  padding: 25px;
  padding-top: 1px;
  background-color: #f4faff;
  white-space: normal;
  padding-top: 20px;
}
#section2-content-benefits-items {
  flex-grow: 1;
  display: flex;
  flex-direction: row;
  /* justify-content: space-evenly; */
  justify-content: space-between;
  margin-bottom: 2vw;
}
.section2-content-benefits-item {
  width: 48%;
  min-width: 386px;
  /* height: 19vw; */
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  background-color: #fafafa;
  border: 1px solid rgba(39, 117, 182, 0.21);
}
.section2-content-benefits-number {
  align-self: center;
  background-color: #2775b6;
  color: white;
  font-size: 30px;
  font-family: "AlibabaPuHuiTiB";
  padding-left: 10px;
  padding-right: 10px;
  padding-top: 5px;
  padding-bottom: 5px;
}
.section2-content-benefits-subtitle {
  align-self: center;
  text-align: center;
  font-size: 17px;
  color: black;
  font-family: "AlibabaPuHuiTiH";
  margin-top: 25px;
  margin-bottom: 20px;
  margin-left: 2px;
  display: flex;
  margin-right: 2px;
}

.section2-content-benefits-subtext-en {
  align-self: center;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 20px;
  text-align: justify;
  font-size: 14px;
  letter-spacing: 0px;
  color: rgba(102, 102, 102, 1);
  font-family: "AlibabaPuHuiTiR";
  line-height: 28px;
}
.section2-content-benefits-subtext {
  align-self: center;
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 50px;
  text-align: justify;
  font-size: 16px;
  color: rgba(102, 102, 102, 1);
  font-family: "AlibabaPuHuiTiR";
  line-height: 40px;
  hyphens: auto;
}

/*实现按钮保持颜色功能*/
.active-button-style {
  background-color: #2775b6;
  color: white;
}
</style>
