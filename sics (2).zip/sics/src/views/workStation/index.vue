<template>
  <div class="container">
    <!--第一部分图片
        背景大图 + 标题-->
    <div class="work-station-background-box">
      <div class="work-station-gap" />
      <div class="work-station-background">
        <!-- <img src="/image/about/section1/section1_background.jpg" /> -->
        <div class="work-station-banner-text-box">
          <template v-if="currentLanguage == 'en'">
            <div class="work-station-banner-text-en">
              {{ $t("workStation.title") }}
            </div>
          </template>
          <template v-else>
            <div class="work-station-banner-text-ch">
              {{ $t("workStation.title") }}
            </div>
            <div class="work-station-banner-text-ch-2">
              {{ $t("workStation.subTitle") }}
            </div>
          </template>
        </div>
      </div>
    </div>

    <div class="current-path-box">
      <div class="current-path">
        <span style="cursor:pointer" @click="$router.push('/research')"> {{ $t("workStation.research") }}</span><i class="el-icon-arrow-right"></i
        ><span style="color: #2775b6">{{ $t("workStation.workStation") }}</span>
      </div>
    </div>
    <!--第二部分简介-->
    <div id="introduction">
      <div class="introduction-contents">
        <div class="introduction-contents-left">
          <div class="introduction-contents-left-subtext normalTextClass">
            {{ $t("workStation.introduction") }}
          </div>
        </div>
        <div class="introduction-contents-image-box">
        </div>
      </div>
    </div>
    <!--第三部分研究与学习资源-->
    <div id="research-resource">
      <div class="research-resource-header normalTitleClass">
        {{ $t("workStation.researchTitle") }}
      </div>
      <div class="research-resource-contents">
        <div class="research-resource-contents-text normalTextClass">
          {{ $t("workStation.researchText") }}
        </div>
        <div class="research-resource-contents-image-box">
          <div
            v-for="(specimen, index) in specimenList"
            class="research-resource-contents-image-item"
          >
            <div
              class="research-resource-contents-item-image"
              :style="{ backgroundImage: `url(${specimen.image})` }"
            >
              <div class="events-image-mask">
                {{ currentLanguage == "en" ? specimen.en : specimen.ch }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--第四部分科研设备-->
    <div id="equipments-box">
      <div class="equipments-background" />
      <div id="equipments">
        <div class="equipments-resource-header normalTitleClass">
          {{ $t("workStation.equipmentTitle") }}
        </div>
        <div class="equipments-contents">
          <div class="equipments-contents-text normalTextClass">
            {{ $t("workStation.equipmentText") }}
          </div>
          <div class="equipment-image-box">
            <div class="equipment-image-top-box">
              <div
                class="equipment-image-sides-image fullbac"
                :style="{ backgroundImage: `url(${equipmentListSides[0].image})` }"
              >
                <div class="events-image-mask">
                  {{
                    currentLanguage == "en"
                      ? equipmentListSides[0].en
                      : equipmentListSides[0].ch
                  }}
                </div>
              </div>
              <div class="equipment-image-center-box">
                <div
                  v-for="(equipment, index) in equipmentListCenter"
                  class="equipment-image-center-image fullbac"
                  :style="{ backgroundImage: `url(${equipment.image})` }"
                >
                  <div class="events-image-mask">
                    {{ currentLanguage == "en" ? equipment.en : equipment.ch }}
                  </div>
                </div>
              </div>
              <div
                class="equipment-image-sides-image fullbac"
                :style="{ backgroundImage: `url(${equipmentListSides[1].image})` }"
              >
                <div class="events-image-mask">
                  {{
                    currentLanguage == "en"
                      ? equipmentListSides[1].en
                      : equipmentListSides[1].ch
                  }}
                </div>
              </div>
            </div>
            <div class="equipment-image-bottom-box">
              <div
                v-for="(equipment, index) in equipmentListBottom"
                class="equipment-image-bottom-image fullbac"
                :style="{ backgroundImage: `url(${equipment.image})` }"
              >
                <div class="events-image-mask">
                  {{ currentLanguage == "en" ? equipment.en : equipment.ch }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--第五部分研学基地-->
    <div id="study-base-box">
      <div id="study-base">
        <div class="research-resource-header normalTitleClass">
          {{ $t("workStation.studyTitle") }}
        </div>
        <div class="study-contents">
          <div class="study-contents-text normalTextClass">
            {{ $t("workStation.studyText") }}
          </div>
        </div>
      </div>
    </div>
    <div class="study-image-box-outer">
        <div class="study-image-box-bac" />
        <div class="study-image-box">
          <div v-for="(studyimage, index) in studyList" class="study-image-item">
            <div
              class="study-item-image"
              :style="{ backgroundImage: `url(${studyimage})` }"
            ></div>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import { getEquipmentList, getSpecimenList } from "@/api/getWorkStationData";
export default {
  name: "about",
  methods: {},
  data() {
    return {
      studyList: [
        "/image/workStation/study/1.png",
        "/image/workStation/study/2.png",
        "/image/workStation/study/3.png",
      ],
      equipmentList: [],
      specimenList: [],
      equipmentListSides: [],
      equipmentListCenter: [],
      equipmentListBottom: [],
      currentPageName: "about",
    };
  },
  created() {
    this.equipmentList = getEquipmentList();
    this.specimenList = getSpecimenList();
    // 拆分设备列表，用于不同区域的设备图像显示
    for (var i = 0, len = this.equipmentList.length; i < len; i++) {
      if (this.equipmentList[i].position == "side")
        this.equipmentListSides.push(this.equipmentList[i]);
      else if (this.equipmentList[i].position == "bottom")
        this.equipmentListBottom.push(this.equipmentList[i]);
      else if (this.equipmentList[i].position == "center")
        this.equipmentListCenter.push(this.equipmentList[i]);
    }
    // console.log("this.equipmentListSides :", this.equipmentListSides)
    // console.log("this.equipmentListBottom :", this.equipmentListBottom)
    // console.log("this.equipmentListCenter :", this.equipmentListCenter)
    this.$store.commit("state/updatePageHeaderBackcolor", "rgba(255,255,255,255,1)");
  },
  methods: {},
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  // width: 100vw;
  height: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 0.5vw;
}

.work-station-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #2775b6;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  margin-top: 4.5vw;
}
.work-station-background-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100vh;
  .work-station-gap {
    // height: 4.2vw;
    height: 65px;
  }
  .work-station-background {
    height: calc(100vh - 4.2vw);
    width: 100%;
    background-image: url("/image/workStation/banner.jpg");
    background-position: center right 30%;
    background-size: cover;
  }
}
.work-station-banner-text-box {
  // border: 1px red solid;
  width: 100%;
  height: 61%;
  display: flex;
  flex-direction: column;
  align-items: left;
  justify-content: flex-end;
  .work-station-banner-text-en {
    margin-left: 10%;
    color: #ffffff;
    // margin-bottom: 20vh;
    font-size: 5.1vw;
    text-align: left;
    letter-spacing: 0.2vw;
    line-height: 5.7vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
    white-space: pre-wrap;
  }
  .work-station-banner-text-ch,
  .work-station-banner-text-ch-2 {
    color: #ffffff;
    margin-left: 12%;
  }
  .work-station-banner-text-ch {
    // border: 1px red solid;
    font-size: 5.5vw;
    text-align: left;
    letter-spacing: 0.2vw;
    line-height: 8vw;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .work-station-banner-text-ch-2 {
    // border: 1px red solid;
    font-size: 2vw;
    text-align: left;
    letter-spacing: 0.2vw;
    line-height: 3vw;
    font-family: "AlibabaPuHuiTiB", sans-serif;
    margin-bottom: 7%;
  }
}

.normalTitleClass {
  font-family: "AlibabaPuHuiTiH";
  font-size: 2.4vw;
}

.normalTextClass {
  // font-size: 1.2vw;
  // line-height: 1.9vw;
  text-align: justify;
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.4vw;
  line-height: 2.4vw;
  letter-spacing: 0.05vw;
  // font-weight: bold;
}

.blueBoldTextClass {
  font-size: 1.4vw;
  font-weight: bold;
  color: #2775b6;
}
.current-path-box {
  // border: 2px solid red;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  width: 70vw;
  margin: auto;
  margin-top: 2%;
  margin-bottom: 1%;

  .current-path {
    font-size: 1.3vw;
    font-family: "AlibabaPuHuiTiR";
    margin-top: 15px;
    align-self: left;
  }
}
#introduction {
  // border: 2px solid red;
  // height: 70vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
  margin-bottom: 5%;
}
// 主框体样式
.introduction-contents {
  // flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  // height: 15vw;
  margin-top: 3vw;
  // 左侧文字按钮样式
  .introduction-contents-left {
    flex: 0.55;
    height: 100%;
    // border: 2px solid blue;
    display: flex;
    flex-direction: column;
    align-self: flex-start;
    justify-content: flex-start;
    .introduction-contents-left-subtext {
      // flex: 0.3;
      // margin-top: 4vw;
      // border: 2px solid red;
      color: #333333;
    }
  }
  // 右侧图像样式
  .introduction-contents-image-box {
    // border: 2px solid red;
    flex: 0.37;
    // height: 100%;
    height: 15vw;
    display: flex;
    flex-direction: column;
    align-self: baseline;
    justify-content: flex-start;
    background-image: url("/image/workStation/introduction.jpg");
    background-position: center center;
    background-size: 100%;
    transition: background-size 0.8s ease;
  }
  .introduction-contents-image-box:hover {
    background-size: 120%;
  }
  // .introduction-contents-image {
  //   height: 15vw;
  //   object-fit: cover;
  // }
  // }
}
#research-resource {
  // border: 2px solid red;
  // height: 70vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
  margin-bottom: 5%;
}
.research-resource-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #2775b6;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  margin-top: 4.5vw;
}
// 主框体样式
.research-resource-contents {
  // flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  height: 100%;
  margin-top: 1.5vw;
  // 文字样式
  .research-resource-contents-text {
    // flex: 0.55;
    // height: 100%;
    // border: 2px solid blue;
    display: flex;
    flex-direction: column;
    align-self: flex-start;
    justify-content: flex-start;
    color: #333333;
  }
  // 图像样式
  .research-resource-contents-image-box {
    // border: 2px solid red;
    margin-top: 5%;
    // height: 100%;
    height: 12vw;
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    .research-resource-contents-image-item {
      width: 23%;
      height: 100%;
      .research-resource-contents-item-image {
        position: relative;
        // border: 2px solid black;
        width: 100%;
        height: 100%;
        // object-fit: cover;
        // background-position: center center;
        // background-size: cover;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-end;
        background-position: center center;
        background-size: 100%;
        transition: background-size 0.8s ease;
      }
    }
  }
}

.events-image-mask {
  // visibility: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  // background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, #000000 100%);
  background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #000000 160%);
  color: #ffffff;
  font-size: 1.4vw;
  font-family: AlibabaPuHuiTiB;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  justify-content: center;
  opacity: 0;
}
.events-image-mask:hover {
  transition: all 0.5s;
  opacity: 1;
}

// 背景图自适应填满样式
.fullbac {
  background-position: center center;
  background-repeat: no-repeat;
}
.equipments-background {
  position: absolute;
  top: 2vw;
  width: 100%;
  height: 80%;
  z-index: -1;

  background-size: 100% 100%;
  background-image: url("/image/workStation/equipBac.jpg");
}

.equipments-box {
  // border: 4px solid blue;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 100%;
  height: 100%;
}
#equipments {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  // border: 2px solid red;
  margin: auto;
  margin-bottom: 5%;
}
.equipments-resource-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #ffffff;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  margin-top: 4.5vw;
}

// 主框体样式
.equipments-contents {
  // flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  height: 100%;
  margin-top: 1.5vw;
  // 文字样式
  .equipments-contents-text {
    // flex: 0.55;
    // height: 100%;
    // border: 2px solid blue;
    display: flex;
    flex-direction: column;
    align-self: flex-start;
    justify-content: flex-start;
    color: #ffffff;
  }
}
.equipment-image-box {
  // border: 2px solid red;
  margin-top: 2%;
  // height: 100%;
  height: 37vw;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;

  .equipment-image-top-box {
    width: 100%;
    height: 65%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    .equipment-image-sides-image {
      // border: 2px solid red;
      width: 19.5%;
      height: 100%;
      background-size: 140%;
    }

    .equipment-image-center-box {
      // border: 2px solid red;
      width: 60%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      flex-wrap: wrap;
      justify-content: space-between;

      .equipment-image-center-image {
        background-size: 120%;
        width: 32%;
        height: 48.5%;
      }
    }
  }

  .equipment-image-bottom-box {
    width: 100%;
    height: 33%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    .equipment-image-bottom-image {
      width: 24.4%;
      height: 100%;
      background-size: 120%;
    }
  }
}

// 研学基地
.study-base-box {
  // border: 4px solid blue;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 80vw;
  height: 100%;
}
#study-base {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
}
// 主框体样式

.study-contents {
  // flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  height: 100%;
  margin-top: 1.5vw;
  // 文字样式
  .study-contents-text {
    // flex: 0.55;
    // height: 100%;
    // border: 2px solid blue;
    display: flex;
    flex-direction: column;
    align-self: flex-start;
    justify-content: flex-start;
    color: #333333;
  }
}

.study-image-box-bac {
  position: absolute;
  margin-right: 1.1vw;
  top: 2.6vw;
  width: 74vw;
  height: 16vw;
  background-size: 100% 100%;
  background-image: url("/image/workStation/studyBac.png");
}
// 图像样式
.study-image-box-outer {
    // border: 2px solid blue;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 100%;
  height: 25vw;
  margin-bottom: 5%;
}
.study-image-box {
  // border: 2px solid red;
  margin-top: 5vw;
  // height: 100%;
  height: 12vw;
  width: 70vw;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  .study-image-item {
    // border: 2px solid red;
    width: 32%;
    height: 100%;
    .study-item-image {
      // border: 2px solid black;
      width: 100%;
      height: 100%;
      background-position: center center;
      background-size: 100%;
      transition: background-size 0.8s ease;
    }
    .study-item-image:hover {
      background-size: 120%;
    }
  }
}
</style>
