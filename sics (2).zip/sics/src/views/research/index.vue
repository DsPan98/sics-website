<template>
  <div class="container">
    <!--第一部分图片
        背景大图 + 标题-->
    <div class="research-background-box">
      <div class="research-gap" />
      <div class="research-background">
        <!-- <img src="/image/about/section1/section1_background.jpg" /> -->
        <div class="research-text-box">
          <template v-if="currentLanguage == 'en'">
            <div class="research-text-en">
              {{ $t("researchPage.researchBanner") }}
            </div>
          </template>
          <template v-else>
            <div class="research-text-ch">
              {{ $t("researchPage.researchBanner") }}
            </div>
          </template>
        </div>
      </div>
    </div>
    <!--第二部分工作站-->
    <div id="work-station">
      <div class="work-station-header normalTitleClass">
        {{ $t("researchPage.workStation") }}
      </div>
      <div class="work-station-contents">
        <div class="work-station-contents-left">
          <div class="work-station-contents-left-subtext normalTextClass">
            {{ $t("researchPage.workStationText") }}
          </div>
          <div class="work-station-contents-left-button" @click="$router.push('/workStation')"></div>
        </div>
        <div class="work-station-contents-image-box">
          <!-- <img
            src="/image/research/workStation.jpg"
            class="work-station-contents-image"
          /> -->
        </div>
      </div>
    </div>
    <!--第三部分基因库-->
    <div id="gene-bank">
      <div class="gene-bank-content">
        <div class="gene-bank-header normalTitleClass">
          {{ $t("researchPage.geneBank") }}
        </div>
        <div class="gene-bank-text normalTextClass">
          {{ $t("researchPage.geneBankText") }}
        </div>
        <div class="gene-bank-button-box">
          <div class="gene-bank-button" @click="navigateTo('/genebank')"></div>
        </div>
      </div>
    </div>

    <!--第四部分机器人柔性制样系统 沿用工作站部分样式-->
    <div id="work-station">
      <div class="work-station-header normalTitleClass">
        {{ $t("researchPage.roboticSystem") }}
      </div>
      <div class="work-station-contents">
        <div class="work-station-contents-left">
          <div class="work-station-contents-left-subtext normalTextClass">
            {{ $t("researchPage.roboticSystemText") }}
          </div>
          <!-- <div class="work-station-contents-left-button"></div> -->
        </div>
        <div class="robotics-contents-image-box"></div>
      </div>
    </div>

    <!--第五部分课题-->
    <div id="project-section">
      <div class="project-section-header normalTitleClass">
        {{ $t("researchPage.project") }}
      </div>
      <div class="project-section-contents">
        <div class="project-section-item-box">
          <div class="project-section-item">
            <div class="project-section-item-icon-box">
              <img
                src="/image/research/restoration.png"
                class="project-section-item-icon"
              />
            </div>
            <div class="project-section-item-text normalTextClass">
              {{ $t("researchPage.project1") }}
            </div>
          </div>
        </div>
        <div class="project-section-item-box">
          <div class="project-section-item">
            <div class="project-section-item-icon-box">
              <img src="/image/research/research.png" class="project-section-item-icon" />
            </div>
            <div class="project-section-item-text normalTextClass">
              {{ $t("researchPage.project2") }}
            </div>
          </div>
        </div>
        <div class="project-section-item-box">
          <div class="project-section-item">
            <div class="project-section-item-icon-box">
              <img
                src="/image/research/archaeology.png"
                class="project-section-item-icon"
              />
            </div>
            <div class="project-section-item-text normalTextClass">
              {{ $t("researchPage.project3") }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "about",
  methods: {},
  data() {
    return {
      currentPageName: "about",
    };
  },
  mounted() {
    this.$store.commit("state/updatePageHeaderBackcolor", "rgba(255,255,255,255,1)");
  },
  methods: {
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  // width: 100vw;
  height: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 0.5vw;
}

.research-background-box {
  /* border: 1px black solid; */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100vh;
  .research-gap {
    // height: 4.2vw;
    height: 65px;
  }
  .research-background {
    height: calc(100vh - 4.2vw);
    width: 100%;
    background-image: url("/image/research/banner.jpg");
    background-position: center center;
    background-size: cover;
  }
}

.research-text-box {
  // border: 1px red solid;
  width: 100%;
  height: 55%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  .research-text-en {
    color: #ffffff;
    // margin-bottom: 20vh;
    font-size: 5.1vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 5.5vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .research-text-ch {
    // border: 1px red solid;
    color: #ffffff;
    // margin-bottom: 8%;
    font-size: 5.5vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 8vw;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
}

.normalTitleClass {
  font-family: "AlibabaPuHuiTiH";
  font-size: 2.4vw;
}

.normalTextClass {
  // font-size: 1.2vw;
  // line-height: 1.9vw;
  text-align: justify;
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.4vw;
  line-height: 2.4vw;
  letter-spacing: 0.05vw;
  // font-weight: bold;
}

.blueBoldTextClass {
  font-size: 1.4vw;
  font-weight: bold;
  color: #2775b6;
}

#work-station {
  // border: 2px solid red;
  // height: 70vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
  margin-bottom: 5%;
}
.work-station-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #2775b6;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  margin-top: 4.5vw;
}
// 主框体样式
.work-station-contents {
  // flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  // height: 15vw;
  margin-top: 3vw;
  // 左侧文字按钮样式
  .work-station-contents-left {
    flex: 0.55;
    height: 100%;
    // border: 2px solid blue;
    display: flex;
    flex-direction: column;
    align-self: flex-start;
    justify-content: space-between;
    .work-station-contents-left-subtext {
      // flex: 0.3;
      // margin-top: 4vw;
      // border: 2px solid red;
      color: #333333;
    }
    .work-station-contents-left-button {
      margin-top: 3vw;
      width: 4vw;
      height: 4vw;
      z-index: 2;
      // flex: 0.15;
      // border: 2px solid red;
      background-image: url("/image/button/rightArrowBlueBorderImage.png");
      background-size: 100% 100%;
      cursor: pointer;
    }
    .work-station-contents-left-button:hover {
      // border-radius: 50%;
      // background-color: #2775b6;
      background-image: url("/image/button/rightArrowBlueContentImage.png");
    }
  }
  // 右侧图像样式
  .work-station-contents-image-box {
    // border: 2px solid red;
    flex: 0.37;
    // height: 100%;
    height: 15vw;
    display: flex;
    flex-direction: column;
    align-self: baseline;
    justify-content: flex-start;

    background-image: url("/image/research/workStation.jpg");
    background-position: center center;
    background-size: 102%;
    transition: background-size 0.8s ease;
  }
  .work-station-contents-image-box:hover {
    background-size: 120%;
  }
}
.robotics-contents-image-box {
  // border: 2px solid red;
  flex: 0.37;
  height: 15vw;
  display: flex;
  flex-direction: column;
  align-self: baseline;
  justify-content: flex-start;

  background-image: url("/image/research/robotics.jpg");
  background-position: center center;
  background-size: 101%;
  transition: background-size 0.8s ease;
}
.robotics-contents-image-box:hover {
  background-size: 120%;
}
#gene-bank {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 100%;
  height: 34vw;
  // margin: auto;
  margin-top: 5%;
  margin-bottom: 5%;
  background-image: url("/image/research/geneBank.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
}
.gene-bank-content {
  // border: 2px solid white;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  width: 70vw;
  height: 100%;

  // margin: auto;
  .gene-bank-header {
    color: #ffffff;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    margin-top: 5%;
  }
  .gene-bank-text {
    margin-top: 5%;
    color: #ffffff;
  }
  .gene-bank-button-box {
    margin-top: 5%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    .gene-bank-button {
      width: 4vw;
      height: 4vw;
      background-size: 100% 100%;
      background-image: url("/image/button/rightArrowImage.png");
      cursor: pointer;
    }

    .gene-bank-button:hover {
      background-image: url("/image/button/rightArrowImageClick.png");
    }
  }
}

#project-section {
  // border: 2px solid red;
  // height: 70vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
  margin-bottom: 5%;
}
.project-section-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #2775b6;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  margin-top: 4.5vw;
}
// 主框体样式
.project-section-contents {
  // border: 2px solid red;
  width: 100%;
  height: 15vw;
  margin-top: 3vw;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-evenly;
  .project-section-item-box {
    // border: 2px solid red;
    width: 33%;
    height: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    .project-section-item {
      // border: 2px solid blue;
      width: 40%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      .project-section-item-icon-box {
        width: 100%;
        height: 100%;
        // border: 2px solid red;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        .project-section-item-icon {
          width: 70%;
          // border: 2px solid red;
        }
      }
      .project-section-item-text {
        // border: 2px solid red;
      }
    }
  }
}
</style>
