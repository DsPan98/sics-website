<template>
  <div class="container">
    <!-- banner部分+“以瓷为媒...”句子 -->
    <div id="section1">
      <div id="section1-background">
        <div class="section1-background-circle" />
        <div class="section1-background-left1" />
        <div class="section1-background-left2" />
        <div class="section1-background-left3" />
        <div class="section1-background-right1" />
        <div class="section1-background-right2" />
        <div class="section1-background-right3" />
        <div class="section1-text-box">
          <template v-if="currentLanguage == 'en'">
            <div class="section1-text-en">
              <!-- {{ $t("section1.title") }} -->
              Society of International<br />Ceramic Studies
            </div>
          </template>
          <template v-else>
            <div class="section1-text">
              {{ $t("section1.title") }}
            </div>
            <div class="section1-text-2">
              <!-- {{ $t("section1.title") }} -->
              Society of International Ceramic Studies
            </div>
          </template>
        </div>
        <div class="section1-scrollDown-box">
          <div class="section1-scrollDown" @click="scrollTo('scrollPositioning')"></div>
        </div>
      </div>
      <div id="section1-info">
        <div class="section1-subtext">
          {{ $t("section1.porcelainSeg1")
          }}<span class="section1-highlight">{{ $t("section1.porcelainSeg2") }}</span
          >{{ $t("section1.porcelainSeg3") }}<br />
          {{ $t("section1.porcelainSeg4")
          }}<span class="section1-highlight">{{ $t("section1.porcelainSeg5") }}</span
          >{{ $t("section1.porcelainSeg6") }}
        </div>
        <div class="section1-about-label" @click="navigateTo('/about')">
          {{ $t("section1.button") }} <i class="el-icon-arrow-right"></i>
        </div>
      </div>
    </div>
    <div id="scrollPositioning" />
    <!-- 国际瓷器联盟工作站 & 古陶瓷基因库 -->
    <div id="section2">
      <div id="section2-workstation">
        <div id="section2-workstation-left">
          <div class="section2-workstation-text">
            {{ $t("section2.workStation") }}
          </div>
          <div id="section2-workstation-subtext-block">
            <div class="section2-workstation-subtext">
              {{ $t("section2.archaeology") }}<br />{{ $t("section2.restoration")
              }}<br />{{ $t("section2.research") }}
            </div>
          </div>
          <div id="section2-left-button-block">
            <div
              class="section2-left-button"
              :hide-on-click="false"
              trigger="hover"
              @click="navigateTo('/workstation')"
            >
              {{ $t("section2.workStation_label") }}
            </div>
          </div>
        </div>
        <div id="section2-workstation-right">
          <!-- <div class="section2-workstation-yellow-ball"></div>
          <div class="section2-workstation-blue-ball"></div> -->
        </div>
      </div>
      <div id="section2-genebank">
        <div id="section2-genebank-left">
          <div class="section2-genebank-text">
            {{ $t("section2.geneBank") }}
          </div>

          <div id="section2-genebank-subtext-block">
            <div class="section2-genebank-subtext">
              <span class="section2-highlight">1372<i class="el-icon-top"/></span>{{ $t("section2.sets") }}<br />
              <span class="section2-highlight">2412<i class="el-icon-top"/></span>{{ $t("section2.specimens")
              }}<br />
              {{ $t("section2.dataSeg1")
              }}<span class="section2-highlight">{{ $t("section2.dataSeg2") }}<i class="el-icon-top"/></span
              >{{ $t("section2.dataSeg3") }}
            </div>
          </div>
          <div id="section2-right-button-block">
            <!-- <div class="section2-right-button">
              <router-link active-class="active" to="/about/genebank">{{
                $t("section2.genebank_label")
              }}</router-link>
              
            </div> -->
            <div
              class="section2-right-button"
              :hide-on-click="false"
              trigger="hover"
              @click="navigateTo('/genebank')"
            >
              {{ $t("section2.genebank_label") }}
            </div>
          </div>
        </div>
        <div id="section2-genebank-right">
          <!-- <div class="section2-genebank-yellow-ball-box">
            <div class="section2-genebank-yellow-ball"></div>
          </div>
          <div class="section2-genebank-blue-ball-box">
            <div class="section2-genebank-blue-ball"></div>
          </div> -->
        </div>
      </div>
    </div>
    <!-- 新闻与活动 -->
    <div id="section3">
      <div class="section3-header-text">{{ $t("section3.news") }}</div>
      <div id="section3-content" @mouseenter="changeImgBtn()" @mouseleave="restore">
        <div id="section3-content-left">
          <!-- <img class="section3-content-left-img" :src="`${currentNews.image}`"/> -->
          <div id="section3-content-left-news">
            <div
              class="section3-left-button"
              style="cursor: pointer"
              @click="prevNews"
            ></div>
            <div
              @click="navigateWithId(currentNews)"
              style="cursor: pointer"
              :hide-on-click="false"
              trigger="hover"
              class="section3-content-left-news-backgroundImage"
              :style="{ backgroundImage: `url(${currentNews.image})` }"
            ></div>
            <div
              class="section3-right-button"
              style="cursor: pointer"
              @click="nextNews"
            ></div>
          </div>
          <div id="section3-content-left-header">
            {{ currentNews.text }}
            <!-- <span class="align-to-right-date">{{ currentNews.date }}</span> -->
          </div>
        </div>
        <div id="section3-content-right">
          <div
            @click="navigateWithId(news)"
            style="cursor: pointer;"
            :hide-on-click="false"
            trigger="hover"
            id="section3-content-right-news"
            v-for="(news, index) in currentNewsList"
            v-if="index != currentNewsIndex"
            :key="index"
          >
            <div
              class="section3-content-right-news-backgroundImage"
              :style="{ backgroundImage: `url(${news.image})` }"
            ></div>
            <div id="section3-content-right-news-info">
              <div id="section3-content-right-news-text-block">
                <div class="section3-content-right-news-text">
                  {{ news.text }}
                </div>
              </div>
              <!-- <div class="section3-content-right-news-date">
                {{ news.date }}
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 讲座、会议等四个card -->
    <div id="section4">
      <div
        class="section4-child"
        v-for="(events, index) in currentSection4List"
        @click="navigateTo('/events')"
        :key="index"
      >
        <div class="section4-child-content-box">
          <div class="section4-child-number">{{ events.number }}</div>
          <div class="section4-child-text">{{ events.text }}</div>
          <div class="section4-child-subtext">{{ events.subtext }}</div>
        </div>
        <div class="section4-child-button-block-box">
          <div id="section4-child-button-block">
            <div class="section4-child-button"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- 青花秘境线上展览 -->
    <div id="section5">
      <img
        src="/image/home/section5/qinghuamijing.jpg"
        style="display: block; margin-left: auto; margin-right: auto; width: 90%"
      />
      <div id="section5-block">
        <div class="section5-text">
          {{ $t("section5.text1") }}<br />{{ $t("section5.text2") }}
        </div>
        <div class="section5-subtext">{{ $t("section5.subtext") }}</div>
        <div id="section5-button-block">
          <div
            class="section5-button"
            style="cursor: pointer"
            onclick="window.open('https://mj3d.bjthua.com/')"
          ></div>
        </div>
      </div>
    </div>
    <div id="section6">
      <div id="section6-header">
        <div class="section6-text">{{ $t("section6.join") }}</div>
      </div>
      <div id="section6-content">
        <div id="section6-content-icon1">
          <div class="section6-content-icon1-image"></div>
          <div class="section6-content-icon1-text">
            {{ $t("section6.global") }}
          </div>
        </div>
        <div id="section6-content-icon2">
          <div class="section6-content-icon2-image"></div>
          <div class="section6-content-icon2-text">
            {{ $t("section6.goals") }}
          </div>
        </div>
        <div id="section6-content-icon3">
          <div class="section6-content-icon3-image"></div>
          <div class="section6-content-icon3-text">
            {{ $t("section6.support") }}
          </div>
        </div>
        <div id="section6-content-icon4">
          <div class="section6-content-icon4-image"></div>
          <div class="section6-content-icon4-text">
            {{ $t("section6.restoration") }}
          </div>
        </div>
      </div>
      <div id="section6-button-section">
        <div class="section6-button" style="cursor: pointer" @click="navigateTo('/join')">
          {{ $t("section6.join") }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {
  getHomeNewsData,
  getHomeNewsDataById,
  getHomeLecturesData,
} from "@/api/getHomeData";
export default {
  name: "homeView2",
  beforeMount() {
    this.getCurrentNewsData();
  },
  created() {
    // 每次进入界面时，先清除之前的所有定时器，然后启动新的定时器
    clearInterval(this.timer);
    this.timer = null;
    //当程序进来的时候，打开定时器，令起自动轮播
    this.timer = setInterval(() => {
      if (this.currentNewsIndex == 3) {
        this.currentNewsIndex = 0;
      } else this.currentNewsIndex++;
    }, 3000);
  },
  destroyed() {
    clearInterval(this.timer);
  },
  methods: {
    getImageUrl(name) {
      return new URL(`${name}`, import.meta.url).href;
    },
    //当鼠标悬停的时候关闭定时器
    changeImgBtn() {
      clearInterval(this.timer);
    },
    // 当鼠标离开的时候打开定时器
    restore() {
      this.timer = setInterval(() => {
        if (this.currentNewsIndex == 3) {
          this.currentNewsIndex = 0;
        } else this.currentNewsIndex++;
      }, 3000);
    },
    getCurrentNewsData() {
      this.newsDataList = getHomeNewsData(this.$i18n.locale);
    },
    scrollTo(sectionId) {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: "smooth" });
      }
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    //for section3 left carousel functions
    nextNews() {
      this.currentNewsIndex = (this.currentNewsIndex + 1) % this.newsDataList.length;
    },
    prevNews() {
      this.currentNewsIndex =
        (this.currentNewsIndex - 1 + this.newsDataList.length) % this.newsDataList.length;
    },
    navigateToQinghua() {
      this.$router.push({
        name: "exhibitionsDetail",
        params: {
          exhibitionsId: 5,
        },
      });
    },
    navigateWithId(news) {
      this.$router.push({
        name: news.link,
        params: {
          newsId: news.id,
          eventsId: news.id,
        },
      });
    },
    navigateExhibitionsWithId(id) {
      this.$router.push({
        name: "exhibitionsDetail",
        params: {
          newsId: id,
        },
      });
    },
  },

  data() {
    return {
      currentNewsIndex: 0, //for section3 left carousel function
      newsDataList: [],
    };
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
    currentNewsList() {
      return getHomeNewsData(this.$i18n.locale);
    },
    currentNews() {
      return this.currentNewsList[this.currentNewsIndex];
    },
    currentSection4List() {
      return getHomeLecturesData(this.$i18n.locale);
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  width: 100%;
  height: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 0.5vw;
}

/*10.07 css style*/
#section1 {
  /* border: 1px blue solid; */
  width: 100%;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 0;
  /* padding-bottom: 5%; */
}
#section1-background {
  width: 100%;
  height: 100vh;
  /* border: 1px black solid; */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  // background-image: url("/image/home/section1/section1_background.jpg");
  background-image: url("/image/home/animation/bac.jpg");
  background-position: center center;
  background-size: cover;
}
.section1-background-circle {
  top: 19%;
  position: absolute;
  background-image: url("/image/home/animation/circle.png");
  background-position: center center;
  background-size: cover;
  width: 35vw;
  height: 35vw;
  animation: circle 54s ease-in-out infinite alternate;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
@-webkit-keyframes circle {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes circle {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes breathlight {
  from {
    opacity: 1.5;
    // filter:contrast(200%);;
    text-shadow: 0 0 1px #ecebd5, 0 0 2px #ecebd5, 0 0 3px #f4f3e5;
  }

  to {
    opacity: 0.7;
  }
}
.section1-background-left1{
  top: 20%;
  left: -11%;
  position: absolute;
  background-image: url("/image/home/animation/left1.png");
  background-position: center center;
  background-size: cover;
  width: 25vw;
  height: 57vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}

.section1-background-left2{
  top: 16%;
  left: 19%;
  position: absolute;
  background-image: url("/image/home/animation/left2.png");
  background-position: center center;
  background-size: cover;
  width: 8.5vw;
  height: 28.8vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  animation-delay: -1.5s;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
.section1-background-left3{
  top: 13.4%;
  left: 33.4%;
  position: absolute;
  background-image: url("/image/home/animation/left3.png");
  background-position: center center;
  background-size: cover;
  width: 6vw;
  height: 8.1vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  animation-delay: -1.1s;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
.section1-background-right3{
  top: 12%;
  right: 35.6%;
  position: absolute;
  background-image: url("/image/home/animation/right3.png");
  background-position: center center;
  background-size: cover;
  width: 5vw;
  height: 9.4vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  animation-delay: -0.9s;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
.section1-background-right2{
  top: 17%;
  right: 19%;
  position: absolute;
  background-image: url("/image/home/animation/right2.png");
  background-position: center center;
  background-size: cover;
  width: 11vw;
  height: 27vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  animation-delay: -0.7s;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
.section1-background-right1{
  top: 28%;
  right: -15%;
  position: absolute;
  background-image: url("/image/home/animation/right1.png");
  background-position: center center;
  background-size: cover;
  width: 30vw;
  height: 53vw;
  animation: arrowmove 8s ease-in-out infinite alternate;
  animation-delay: -0.5s;
  // animation-delay: calc(var(--animationDelay) * 0.5s);
}
@keyframes arrowmove {
  0% {
    transform: translateY(-10px)
  }

  25% {
    transform: translateY(0px)
  }

  50% {
    transform: translateY(-5px)
  }

  75% {
    transform: translateY(0px)
  }

  100% {
    transform: translateY(-5px)
  }
}

.section1-text-box {
  // border: 1px red solid;
  width: 100%;
  height: 70%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  .section1-text-en {
    color: #2775b6;
    margin-bottom: 7vh;
    font-size: 5.1vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 5.5vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .section1-text {
    // border: 1px red solid;
    color: #2775b6;
    // margin-bottom: 8%;
    font-size: 6vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 6vw;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .section1-text-2 {
    color: #2775b6;
    margin-bottom: 9vh;
    font-size: 2.1vw;
    text-align: center;
    letter-spacing: 0.2vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
}
.section1-scrollDown-box {
  /* border: 1px black solid; */
  width: 100%;
  height: 30%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  .section1-scrollDown {
    // border: 1px black solid;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    margin-bottom: 7%;
    // margin-bottom: 4%;
    // border-radius: 50%;
    width: 70px;
    height: 70px;
    z-index: 2;
    // background: rgba(255, 255, 255, 0.4);
    background-image: url("/image/home/section1/arrow_down_button.png");
    background-size: 100% 100%;
    cursor: pointer;
  animation: breathlight 2s ease-in-out infinite alternate;
    .section1-scrollDown-img {
      width: 40px;
    }
  }
  .section1-scrollDown:hover {
    background-image: url("/image/home/section1/arrow_down_button_hover.png");
    background-size: 100% 100%;
  }
}
#section1-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: -3.5%;
  // margin-top: 3.5%;
  margin-bottom: 40px;
  z-index: 2;
  background-position: center;
  background-color: white;
  border: 1px solid rgba(200, 200, 200, 0.2);
  // box-shadow:rgba(149, 157, 165, 0.2) 0px 8px 24px;
  box-shadow: rgba(100, 100, 111, 0.2) 0px 2px 6px 0px;
  // border: 5px solid rgba(200, 200, 200, 1);
  border-radius: 50vw 50vw 50vw 50vw;
  // border-radius: 90px;
  height: 250px;
  width: 85%;

  .section1-subtext {
    // border: 5px solid rgba(200, 200, 200, 1);
    margin-top: 1%;
    // padding-top: 1%;
    text-align: center;
    font-weight: bold;
    font-family: "AlibabaPuHuiTiR";
    font-size: 30px;
    letter-spacing: 0.2vw;
    z-index: 2;
  }
  .section1-about-label {
    // margin-top: 12px;
    margin-top: 1%;
    position: relative;
    font-size: 18px;
    font-family: "AlibabaPuHuiTiR";
    background-color: rgba(255, 255, 255, 0.5);
    border: 1px solid #2775b6;
    border-radius: 3px;
    padding: 3px 6px 3px 6px;
    cursor: pointer;

    text-align: center;
    white-space: nowrap;
    color: #2775b6;
    // z-index: 3;
  }
  .section1-about-label:hover {
    // border: 1px solid red;
    background-color: #2775b6;
    color: white;
    text-decoration: none;
  }
}
/*highlight for 媒 and 探索*/
.section1-highlight {
  font-size: 1.2em;
  color: #2775b6;
}

/*section4*/
#section4 {
  flex-grow: 1;
  width: 75%;
  object-fit: cover;
  position: relative;
  display: flex;
  flex-direction: row;
  align-self: center;
  justify-content: space-evenly;
  padding-top: 5vw;
  padding-bottom: 5vw;
  gap: 5%;
}
.section4-child {
  border: 2px #2275b6 solid;
  height: 20vw;
  padding-left: 1%;
  padding-right: 0.5%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 1;
  background-color: white;
  cursor: pointer;
}
.section4-child-number {
  // border: 2px red solid;
  position: relative;
  text-align: right;
  font-size: 3vw;
  font-family: "AlibabaPuHuiTiB";
  color: #b0b0b0;
  opacity: 0.2;
  padding-right: 8%;
}
.section4-child-content-box {
  // height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
.section4-child-text {
  // border: 2px red solid;
  flex: 0.2;
  position: relative;
  font-size: 1.5vw;
  font-family: "AlibabaPuHuiTiB";
  text-align: left;
  white-space: nowrap;
  justify-content: center;
  transform: translateY(10%);
}
.section4-child-subtext {
  // border: 2px red solid;
  font-size: 0.95vw;
  position: relative;
  flex: 0.25;
  text-align: justify;
  justify-content: center;
  color: #9f9f9f;
  font-family: "AlibabaPuHuiTiR";
  // text-align:left;
}
.section4-child-button-block-box {
  // border: 2px red solid;
  // height: 100%;
  height: 5vw;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
#section4-child-button-block {
  // border: 2px red solid;
  height: 3vw;
  // margin-bottom: 2vw;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
}
.section4-child-button {
  position: relative;
  flex: 0.3;

  z-index: 2;
  background-size: contain;
  background-repeat: no-repeat;
  background-image: url("/image/home/section4/arrow_bottomright_white.png");
}

.section4-child:hover {
  background-color: #2275b6;
  color: white;
}
.section4-child:hover .section4-child-subtext {
  color: white;
}
.section4-child:hover .section4-child-number {
  color: #ffffff;
}
.section4-child:hover .section4-child-button {
  background-image: url("/image/home/section4/arrow_bottomright_black.png");
}

#section5 {
  position: relative;
  align-self: center;
  width: 84%;
  display: flex;
}

/*section5*/
.section5-text {
  flex: 0.2;
  color: white;
  font-family: "AlibabaPuHuiTiB";
  font-size: 2vw;
  white-space: nowrap;
}
.section5-subtext {
  flex: 0.2;
  font-size: 1.2vw;
  font-family: "AlibabaPuHuiTiR";
  color: white;
}
#section5-block {
  position: absolute;
  left: 8%;
  width: 82%;
  height: 100%;
  flex-direction: column;
  justify-content: center;
  display: flex;
}
#section5-button-block {
  height: 4.2vw;
  flex: 0.2;
  z-index: 2;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
}
.section5-button {
  flex: 0.05;
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  // background-image: url("/image/home/section5/arrow_bottomright_black.png");
  background-image: url("/image/button/rightArrowImageClick.png");
}
.section5-button:hover {
  // background-image: url("/image/home/section5/arrow_bottomright_white.png");
  background-image: url("/image/button/rightArrowImage.png");
}
/*section4 end*/
#scrollPositioning {
  // border: 3px red solid;
  position: absolute;
  top: 85vh;
  width: 100%;
  height: 0;
  z-index: 99;
}
/*section2 style*/
#section2 {
  // border: 4px solid red;
  flex-grow: 1;
  position: relative;
  display: flex;
  flex-direction: row;

  width: 75%;
  align-self: center;
  z-index: 0;
  justify-content: space-between;
  background-repeat: no-repeat;
  background-size: contain;

  margin-bottom: 2%;

  background-image: url("/image/home/section2/section2_background.png");
}
/*section2:layer1*/
#section2-workstation {
  // border: 4px solid blue;
  flex-grow: 1;
  flex: 0.5;
  display: flex;
  flex-direction: row;
  height: 18.5vw;
  justify-content: right;
}
#section2-genebank {
  // border: 4px solid red;
  flex: 0.5;
  display: flex;
  justify-content: center;
  flex-direction: row;

  background-repeat: no-repeat;
  background-size: cover;
  background-image: url("/image/home/section2/section2_background_right.png");

  overflow: hidden;
}

/*section2:layer2*/
#section2-workstation-left {
  // border: 2px solid red;
  flex: 0.45;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
#section2-workstation-right {
  flex: 0.5;
  position: relative;
  background-position: right;
  background-image: url("/image/home/section2/section2_workstation_label.jpg");
  background-size: contain;
  margin-top: 7%;
  transform: translateY(4%) translateX(-13%);
  margin-bottom: 7%;
  background-repeat: no-repeat;
}
@keyframes move {
  0% {
    offset-distance: 100%;
  }
  50% {
    offset-distance: 0%;
  }
  100% {
    offset-distance: 100%;
  }
}
.section2-workstation-yellow-ball {
  position: absolute;
  width: 1.6vw;
  height: 1.6vw;
  margin-top: 6%;
  margin-left: 58%;
  // transform: translateY(4%) translateX(2vw);
  background-image: url("/image/home/section2/yellow_circle.png");
  background-size: 100% 100%;

  offset-path: path(
    "M0.524688131,133.97219 C0.524688131,160.171797 28.6975994,184.018897 55.8585897,181.503779 C83.01958,178.988661 103.127214,167.477436 106.851239,140.145455 C110.575265,112.813474 89.9351985,96.6648462 67.0807949,87.8804143 C44.2263912,79.0959823 32.4104485,80.7249202 21.5849985,72.2745767 C0.524688131,55.8349038 6.6527049,17.7105988 26.7664518,8.70258925 C68.5562948,-10.0131333 97.5445838,3.24607035 113.731319,48.4802001"
  );
  // offset-anchor : top -10vw;;
  animation: move 10000ms infinite alternate ease-in-out;
  animation-delay: -5000ms;
}
.section2-workstation-blue-ball {
  position: absolute;
  width: 1.6vw;
  height: 1.6vw;
  margin-top: 6%;
  margin-left: 58%;
  background-image: url("/image/home/section2/s_blue_circle.png");
  background-size: 100% 100%;
  offset-path: path(
    "M0.524688131,133.97219 C0.524688131,160.171797 28.6975994,184.018897 55.8585897,181.503779 C83.01958,178.988661 103.127214,167.477436 106.851239,140.145455 C110.575265,112.813474 89.9351985,96.6648462 67.0807949,87.8804143 C44.2263912,79.0959823 32.4104485,80.7249202 21.5849985,72.2745767 C0.524688131,55.8349038 6.6527049,17.7105988 26.7664518,8.70258925 C68.5562948,-10.0131333 97.5445838,3.24607035 113.731319,48.4802001"
  );
  // offset-anchor : top -10vw;;
  animation: move 10000ms infinite alternate ease-in-out;
}
.section2-genebank-yellow-ball-box {
  position: absolute;
  // border: 2px red solid;
  margin-top: -9%;
  margin-left: 71%;
  width: 10%;
  transform: rotate(90deg);
}
.section2-genebank-blue-ball-box {
  position: absolute;
  // border: 2px red solid;
  margin-top: 28%;
  margin-left: 56%;
  width: 10%;
  transform: rotate(90deg);
}
.section2-genebank-yellow-ball {
  background-image: url("/image/home/section2/yellow_circle.png");
  background-size: 100% 100%;
  width: 1.6vw;
  height: 1.6vw;

  offset-path: path(
    "M174.996029,-29.2018492 L133.006699,-29.3369809 C76.4289073,-29.3369809 30.5626378,16.4139623 30.5626378,72.8506108 C30.5626378,129.287259 76.4289073,175.036267 133.006699,175.036267 L171.652377,175.036267"
  );
  // offset-anchor : top -10vw;;
  animation: move 6000ms infinite alternate ease-in-out;
}
.section2-genebank-blue-ball {
  background-image: url("/image/home/section2/n_blue_circle.png");
  background-size: 100% 100%;
  width: 1.6vw;
  height: 1.6vw;

  offset-path: path(
    "M84.0511403,-10.8434471 L61.1524139,-10.8434471 C34.6837463,-10.8434471 13.2266517,10.7894559 13.2266517,37.4749942 C13.2266517,64.1605325 34.6837463,85.7934356 61.1524139,85.7934356 L86.1655142,85.9269249"
  );
  // offset-anchor : top -10vw;;
  animation: move 6000ms infinite alternate ease-in-out;
}
#section2-genebank-left {
  flex: 0.45;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
#section2-genebank-right {
  flex: 0.4;
  background-image: url("/image/home/section2/section2_genebank_label.png");
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 7%;
  margin-bottom: 7%;
  transform: translateY(7%);
}
/*section2-layer3*/
.section2-workstation-text {
  display: flex;
  font-size: 1.5vw;
  font-family: "AlibabaPuHuiTiB";
  color: white;
  text-align: left;
  white-space: nowrap;
  margin-top: 18%;
}
#section2-workstation-subtext-block {
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-bottom: 5%;
}

.section2-workstation-subtext {
  font-size: 1vw;
  font-family: "AlibabaPuHuiTiR";
  color: white;
  text-align: left;
  letter-spacing: 0.1vw;
  line-height: 1.5vw;
}
#section2-left-button-block {
  display: flex;
  justify-content: flex-start;
  flex-direction: row;
  margin-bottom: 18%;
}
.section2-left-button:hover,
.section2-left-button,
.section2-left-button a {
  flex: 0.3;
  font-family: "AlibabaPuHuiTiR";
  color: #2275b6;
  white-space: nowrap;
  border: white 2px solid;
  background-color: white;
  text-align: center;

  font-size: 1.2vw;
  cursor: pointer;
}

.section-left-button a {
  font-size: 1.2vw;
  color: #2275b6;
}

.section2-left-button:hover {
  text-decoration: none;
  background-color: #cbe6fd;
  // color: white;
}

#section2-genebank-subtext-block {
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-bottom: 5%;
}
.section2-genebank-text {
  font-size: 1.5vw;
  font-family: "AlibabaPuHuiTiB";
  background-size: contain;
  color: white;
  text-align: left;
  white-space: nowrap;
  margin-top: 18%;
}
.section2-genebank-subtext {
  font-size: 1vw;
  font-family: "AlibabaPuHuiTiR";
  color: white;
  text-align: left;
  line-height: 1.5vw;
  letter-spacing: 0.1vw;
}

.section2-highlight {
  font-family: "AlibabaPuHuiTiB";
  color: #fcd43d;
}
#section2-right-button-block {
  // border: 2px solid red;
  display: flex;
  justify-content: flex-start;
  flex-direction: row;
  margin-bottom: 18%;
}
.section2-right-button:hover,
.section2-right-button {
  flex: 0.3;
  font-family: "AlibabaPuHuiTiR";
  color: white;
  border: 2px solid white;
  font-size: 1.2vw;
  text-align: center;
  white-space: nowrap;
  cursor: pointer;
}
.section2-right-button a {
  font-size: 1.2vw;
  color: white;
}

.section2-right-button:hover {
  text-decoration: none;
  background-color: #cbe6fd;
  color: #2275b6;
}

/*section3 layer0*/
#section3 {
  flex-grow: 1;
  width: 75%;
  align-self: center;
  object-fit: contain;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
/*section3 layer1*/
.section3-header-text {
  font-family: "AlibabaPuHuiTiH", sans-serif;
  color: #2775b6;
  font-size: 2.4vw;
  padding-top: 2%;
  padding-bottom: 1%;
}
#section3-content {
  display: flex;
  flex-direction: row;
  align-items: stretch;
  z-index: 0;
  justify-content: space-between;
  height: 20vw;
  gap: 2%;
  // border: 2px black solid;
}
/*section3 layer2*/
#section3-content-left {
  flex: 4.5;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  border: 2px solid rgba(200, 200, 200, 0.3);
}
#section3-content-right {
  flex: 5.5;
  display: flex;
  flex-direction: column;
  gap: 5%;
}

/*section3 layer3*/
#section3-content-left-news {
  flex: 0.88;
  display: flex;
  flex-direction: column;
  background-color: #2275b6;
  background: linear-gradient(
    to right,
    rgba(135, 206, 250, 0.2),
    rgba(135, 206, 250, 0.8),
    rgba(135, 206, 250, 0.2)
  );
}

.section3-content-left-img {
  // border: 2px black solid;
  position: absolute;
  width: 100%;
  opacity: 1;
  transition: all 1s ease-in-out;
  // -o-transition: all linear 500ms;
  //   -ms-transition: all linear 500ms;
  //   -moz-transition: all linear 500ms;
  //   -webkit-transition: all linear 500ms;

  // height: 2vw;
  z-index: 1;
}

#section3-content-left-header {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  flex: 0.16;
  // height: 4vw;
  position: relative;
  font-family: "AlibabaPuHuiTiB", sans-serif;
  color: black;
  font-size: 1.2vw;
  line-height: 1.3vw;
  padding-left: 1vw;
  background: #ffffff;
  z-index: 2;
  transition: all 2s ease-in-out;
}
.align-to-right-date {
  float: right;
  color: rgba(0, 0, 0, 0.5);
  font-size: 1vw;
  font-family: "AlibabaPuHuiTiR";
}
/*section3 layer4*/
.section3-content-left-news-backgroundImage {
  flex: 1;
  // background-size: cover;
  // background-repeat: no-repeat;
  // background-position: center;
  // background-image: url("/image/home/section1/section1_background.jpg");
  background-position: center center;
  background-size: cover;
  // transition: opacity .5s;
  transition: all 2s ease-in-out;
}
.section3-left-button,
.section3-right-button,
.section3-content-left-news-text,
.section3-content-left-news-date {
  position: absolute;
}
.section3-left-button {
  left: 2%;
  top: 40%;
  z-index: 2;
  width: 3vw;
  height: 3vw;
  background-size: 100%;
  background-image: url("/image/home/section3/left/section3_left_button.png");
}
.section3-right-button {
  right: 2%;
  top: 40%;
  z-index: 2;
  width: 3vw;
  height: 3vw;
  background-size: 100%;
  background-image: url("/image/home/section3/left/section3_right_button.png");
}
.section3-content-left-news-text {
  flex: 1;
  left: 11.6%;
  top: 4.2%;
  font-size: 1.45vw;
  letter-spacing: 0.1vw;
  font-family: "AlibabaPuHuiTib", sans-serif;
  color: white;
}

.section3-content-left-news-date {
  right: 10%;
  bottom: 15%;
  font-size: 1%;
  font-family: "AlibabaPuHuiTib", sans-serif;
  color: white;
}

#section3-content-right-news {
  display: flex;
  flex: 1;
  flex-direction: row;
  background-color: #f6f6f6;
}
#section3-content-right-news:hover {
  color: white;
}

#section3-content-right-news:hover #section3-content-right-news-info {
  background-color: #2275b6;
}

.section3-content-right-news-backgroundImage {
  flex: 1;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  position: relative;
}
#section3-content-right-news-info {
  flex: 3;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  // border: 2px black solid;
}
#section3-content-right-news-text-block {
  // width: 100%;
  // height: 100%;
  // background-color: #F6F6F6;
  // flex: 0.55;
  display: flex;
  flex-direction: row;
  justify-content: center;
}

.section3-content-right-news-text {
  margin-left: 2vw;
  flex: 1;
  text-align: left;
  font-size: 1vw;
  font-family: "AlibabaPuHuiTiB", sans-serif;
  line-height: 1.5vw;
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.section3-content-right-news-date {
  position: relative;
  flex: 0.05;
  text-align: right;
  transform: translateX(-3%);
  white-space: nowrap;
  font-family: "AlibabaPuHuiTiR";
}

#section6 {
  flex-grow: 1;
  width: 75%;
  display: flex;
  position: relative;
  align-self: center;
  flex-direction: column;
  justify-content: space-between;
  margin-top: 5%;
  margin-bottom: 3%;
}
#section6-header {
  position: relative;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  flex: 0.3;
}
.section6-text {
  text-align: center;
  flex: 0.1;
  color: #2775b6;
  font-family: "AlibabaPuHuiTiH";
  font-size: 2.4vw;
}
#section6-content {
  flex: 0.5;
  display: flex;
  flex-direction: row;
  align-items: top;
  position: relative;
  justify-content: space-around;
}
#section6-content-icon1,
#section6-content-icon2,
#section6-content-icon3,
#section6-content-icon4 {
  flex: 0.2;
  display: flex;
  flex-direction: column;
  justify-content: top;
  object-fit: cover;

  height: 16vw;
}
.section6-content-icon1-image,
.section6-content-icon2-image,
.section6-content-icon3-image,
.section6-content-icon4-image {
  flex: 0.7;
  object-fit: contain;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  margin-left: 24%;
  margin-right: 24%;
}
.section6-content-icon1-image {
  background-image: url("/image/home/section6/section6_icon1.png");
}
.section6-content-icon2-image {
  background-image: url("/image/home/section6/section6_icon2.png");
}
.section6-content-icon3-image {
  background-image: url("/image/home/section6/section6_icon3.png");
}
.section6-content-icon4-image {
  background-size: 85%;
  background-image: url("/image/home/section6/section6_icon4.png");
}
.section6-content-icon1-text,
.section6-content-icon2-text,
.section6-content-icon3-text,
.section6-content-icon4-text {
  flex: 0.2;
  object-fit: cover;
  font-family: "AlibabaPuHuiTiR", sans-serif;
  color: black;
  font-size: 1.2vw;
  text-align: center;
  position: relative;
}
#section6-button-section {
  position: relative;
  display: flex;
  justify-content: center;
  margin-top: 2%;
  flex: 0.2;
}
.section6-button {
  position: relative;
  background-color: #2275b6;
  border-radius: 0.1vw;
  padding-top: 0.5%;
  padding-bottom: 0.5%;
  padding-left: 5%;
  padding-right: 5%;
  align-content: center;
  color: white;
  font-family: "AlibabaPuHuiTiB";

  font-size: 1.2vw;
  align-self: center;
}
.section6-button a {
  color: white;
  font-family: "AlibabaPuHuiTiB";
  white-space: nowrap;
}
.section6-button a:hover {
  color: white;
  background-color: #2275b6;
}

#section7 {
  flex-grow: 1;
  align-self: center;
  width: 100%;
  background-size: contain;
  background-color: #144a74;
  background-repeat: no-repeat;
  background-position: center;
  flex-direction: column;
  justify-content: space-between;
  object-fit: cover;
  position: relative;
  margin: auto;
}
.section7-label {
  background-size: contain;
  background-repeat: no-repeat;
  align-self: left;
  background-image: url("/image/home/section7/sics_logo_transparent.png");
  height: 5vw;
  margin-left: 12.5%;
  margin-top: 3%;
  margin-right: 10%;
}
#section7-content {
  flex: 1;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  color: white;
  margin-top: 2%;
  margin-left: 11%;
  text-align: left;
  font-size: 2vw;
  font-family: AlibabaPuHuiTiB;
  margin-bottom: 5%;
}
#section7-content-left {
  flex: 0.6;
}
#section7-content-right {
  margin-left: 5%;
  flex: 0.4;
}
#section7-content-right-subtext a,
#section7-content-right-subtext:hover,
#section7-content-right-subtext {
  background-color: #144a74;
  color: white;
  font-family: "AlibabaPuHuiTiR";
}
.section7-content-left-text {
  margin: 3%;
  font-size: 1.8vw;
  font-family: "AlibabaPuHuiTiH";
}
.section7-content-left-subtext {
  margin: 3%;
  font-size: 1.5vw;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  font-family: "AlibabaPuHuiTiR";
}
.section7-content-right-text {
  margin: 3%;
  font-size: 1.8vw;
  font-family: "AlibabaPuHuiTiH";
}

.section7-content-right-link {
  margin: 3%;
  color: white;
  flex: 1;
  display: flex;
  font-size: 1.5vw;
  font-family: "AlibabaPuHuiTiR";
}
.section-content-right {
  flex: 1;
}
#section7-bottom {
  flex: 1;
  color: white;
  display: flex;
  flex-direction: row;
  gap: 3%;
  font-family: "AlibabaPuHuiTiR";
}
.section7-bottom-left {
  flex: 1;
  text-align: center;
  color: white;
  text-align: right;
}
.section7-bottom-right {
  flex: 1;
  text-align: center;
  color: white;
  text-align: left;
}
</style>
