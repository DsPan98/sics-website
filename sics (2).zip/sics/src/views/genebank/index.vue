  <!--基因库
比例问题 62.5 18.75
顶部图片占比100%
	文字左对齐 （leftmargin）18.75，右边约8.75？
	标题 无具体大小 目测75px 白 H，TOP:18.25%
	文字 40px -> 30px 白/黄 R/B 
	按钮：30px R 白-->
<template>
  <div id="container">
    <div id="section0"></div>
    <div id="section1">
      <img
        src="/image/genebank/genebank_background.jpg"
        class="section1-background-img"
      />
      <div id="section1-text">
        <div class="section1-title">{{ $t("genebank.geneBank") }}</div>
        <div class="section1-subtext">
          <span class="section1-highlight">1372<i class="el-icon-top"/></span>{{ $t("genebank.sets")
          }}<br />
          <span class="section1-highlight">2412<i class="el-icon-top"/></span
          >{{ $t("genebank.specimens") }}<br />
          {{ $t("genebank.dataSeg1")
          }}<span class="section1-highlight">{{ $t("genebank.dataSeg2") }}<i class="el-icon-top"/></span
          >{{ $t("genebank.dataSeg3") }}
        </div>
        <div id="section1-button" onclick="window.open('http://cgb.jdzyybwy.com:9930')">
          <div class="section1-button-text">{{ $t("genebank.explore") }}</div>
          <img class="section1-button-img" src="/image/genebank/genebank_arrow.png" />
        </div>
      </div>
    </div>
    <div id="section2">
      <div class="section2-item2-background"><img src="/image/genebank/genebank_background2.jpg"/></div>
      <div class="section2-spacing"></div>
      <div id="section2-info">
        <div id="section2-current">
          <span @click="navigateTo('/research')" style="cursor: pointer">{{ $t("genebank.research") }}</span><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6">{{
            $t("genebank.genebankCurrent")
          }}</span>
        </div>
        <div class="section2-introduction">
          {{ $t("genebank.introduction") }}
        </div>
        <div id="section2-child-block">
          <div
            class="section2-child"
            v-for="(item, index) in genebankList"
            :key="index"
          >
            <div :class="['section2-child-text', index % 2 === 0 ? 'left' : 'right', index===1?'special-style':'']">{{ item.text }}</div>
            <div :class="['section2-child-image', index % 2 === 0 ? 'right' : 'left']"><img :src="item.image"/></div>
          </div>
        </div>
      </div>
      <div class="section2-spacing"></div>
    </div>
  </div>
</template>

<script scoped>
import{
  getGenebankListData,
} from "@/api/getGeneBankData";
export default {
  beforeMount(){
    this.getCurrentGenebankData();
  },
  data() {
    return {
      genebankList:[],
    };
  },
  computed:{
  },
  methods:{
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    getCurrentGenebankData(){
      this.genebankList = getGenebankListData(this.$i18n.locale);
    }
  }
};
</script>

<style scoped>
#section0 {
  height: 70px;
}
#section1 {
  position: relative;
}
#section1-text {
  position: absolute;
  left: 18.75%;
  top: 18.25%;
  display: flex;
  flex-direction: column;
  flex: 1;
  flex-grow: 1;
  width: 700px;
  align-content: left;
}

.section1-title {
  font-size: 70px;
  font-family: "AlibabaPuHuiTiH";
  color: white;
  line-height: 100px;
  white-space: normal;
}
.section1-subtext {
  font-family: "AlibabaPuHuiTiR";
  color: white;
  font-size: 30px;
}
.section1-highlight {
  font-family: "AlibabaPuHuiTiB";
  color: #fcd43d;
  font-size: 30px;
}
#section1-button{
  display: flex;
  align-items: center;
  width:220px;
  flex-direction: row;
  justify-content: space-evenly;
  border:2px solid white;
  margin-top:20px;
  padding:5px;
}
.section1-button-text{
  font-size:26px;
  font-family:'AlibabaPuHuiTiR';
  color:white;
  white-space: nowrap;
  flex:0.6;
  word-spacing: 0;
}
#section1-button img{
  width:30px;
  height:auto;
}


#section1-button:hover .section1-button-text{
  color:#2775b6; 
  font-family: 'AlibabaPuHuiTiB';

}
#section1-button:hover{
  background-color:white;
}
#section1-button:hover .section1-button-img{
  content:url(/image/genebank/genebank_arrow_blue.png)
}

#section2 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 20px;
  margin-top: 30px;
  
}
.section2-spacing {
  flex: 0.1875;
}
#section2-info {
  display: flex;
  flex-direction: column;
  flex: 0.625;
}
.section2-current {
  font-size: 13.5px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 15px;
  margin-bottom: 60px;
  align-self: left;
}
.section2-introduction {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiB";
  color: #2775b6;
  margin-top: 50px;
}
#section2-child-block{
  flex-grow: 1;
  position: relative;
  display: flex;
  flex-direction: column;
  align-self: center;
  justify-content: space-between;
  padding-top: 20px;
  padding-bottom: 20px;

  height:1700px;
}
.section2-child{
  flex:0.23;
  display: flex;
  object-fit:contain;
  flex-direction: row;
  justify-content:space-between;
  
}
.section2-child-text{
  flex:0.5;
  display:flex;
  text-align: justify;
  font-size:18px;
  line-height: 27px;
  font-family: 'AlibabaPuHuiTiR';
}
.section2-child-image{
  flex:0.5;
  display:flex;
  object-position: center;
  flex-direction: column;
  justify-content:space-between;
  align-items:flex-start;

}
.section2-child-image img{
  object-fit:contain;
  object-position:center;
  align-self: center;
}


.left{
  order:1;
  flex:0.48;
}
.right{
  order:2;
  flex:0.48;
}
.section2-item2-background{
  position: absolute;
  top:28%;
}
.special-style{
  color:white;
}

</style>