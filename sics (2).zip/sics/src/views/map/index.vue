<!--section0:白色边框
    section1:背景图片以及标题
    section2：具体内容 地图介绍
    section3:探索地图


地图
1.比例问题 62.5 中间 18.75 两侧
2.顶部图片占比100
	内部title 100px -> 75px? H 白色
	title英文 40px -> 30px R 白色
	subtitle 60px -> 45px H 某种白灰色
	subtitle英文 30px -> 22px R 颜色同上
3.地图介绍 62.5中间
	地图介绍 40px ->30px H #3565A7
	subtext 26px -> 19px R #333333
4.探索地图 
	title 同上
	具体地图，占比百分之百 走马灯 carousel 中间图片62.5%的90% 
	下方文字 spacebtween 左右对齐62.5的90%， 26px -> 19px R #333333-> active时变B  #2775B6
地图
1.比例问题 62.5 中间 18.75 两侧
2.顶部图片占比100
	内部title 100px -> 75px? H 白色
	title英文 40px -> 30px R 白色
	subtitle 60px -> 45px H 某种白灰色
	subtitle英文 30px -> 22px R 颜色同上
3.地图介绍 62.5中间
	地图介绍 40px ->30px H #3565A7
	subtext 26px -> 19px R #333333
4.探索地图 
	title 同上
	具体地图，占比百分之百 走马灯 carousel 中间图片62.5%的90% 
	下方文字 spacebtween 左右对齐62.5的90%， 26px -> 19px R #333333-> active时变B  #2775B6-->
<template>
  <div id="container">
    <div id="section0"></div>
    <div id="section1">
      <img src="/image/map/map_background.jpg" class="section1-background-img" />
      <div id="section1-text">
        <div class="section1-title">{{ $t("map.title") }}</div>
        <div class="section1-title-en">{{ $t("map.titleEn") }}</div>
        <div class="section1-subtitle">{{ $t("map.subtitle") }}</div>
        <div class="section1-subtitle-en">{{ $t("map.subtitleEn") }}</div>
      </div>
    </div>
    <div id="section2">
      <div class="section2-spacing"></div>
      <div id="section2-content">
        <div class="section2-title">{{ $t("map.intro") }}</div>
        <div id="section2-content-info">
          <div class="section2-subtext">{{ $t("map.introSubtext") }}</div>
          <div class="section2-image">
            <img src="/image/map/map_image1.png" class="section2-img" />
          </div>
        </div>

        <div id="section2-button-block">
          <div
            class="section2-button"
            style="cursor: pointer"
            @click="navigateTo('/exhibitions')"
          ></div>
        </div>
      </div>
      <div class="section2-spacing"></div>
    </div>
    <div id="section3">
      <div id="section3-title-block">
        <div class="section3-spacing"></div>
        <div class="section3-title">{{ $t("map.discover") }}</div>
        <div class="section3-spacing"></div>
      </div>
      <!--carousel section-->
      <div id="section3-content-box">
        <div id="section3-content">
          <el-carousel
            :interval="2500"
            arrow="never"
            @change="handleChange"
            :autoplay="true"
            height="400px"
            type="card"
            style="text-align: center"
          >
            <el-carousel-item
              style="display: flex"
              v-for="(item, index) in mapList"
              :key="index"
            >
              <img :src="item.image" style="" />
            </el-carousel-item>
          </el-carousel>
        </div>
      </div>
      <div id="section3-menu">
        <div
          :class="chooseImageId == 0 ? 'section3-menu-choose-item' : 'section3-menu-item'"
        >
          {{ $t("map.bottomItem1") }}
        </div>
        <div
          :class="chooseImageId == 1 ? 'section3-menu-choose-item' : 'section3-menu-item'"
        >
          {{ $t("map.bottomItem2") }}
        </div>
        <div
          :class="chooseImageId == 2 ? 'section3-menu-choose-item' : 'section3-menu-item'"
        >
          {{ $t("map.bottomItem3") }}
        </div>
        <div
          :class="chooseImageId == 3 ? 'section3-menu-choose-item' : 'section3-menu-item'"
        >
          {{ $t("map.bottomItem4") }}
        </div>
      </div>
    </div>
  </div>
</template>
<script scoped>
export default {
  data() {
    return {
      chooseImageId: 0,
      mapList: [
        {
          title: "111",
          image: "/image/map/map_carousel1.jpg",
        },
        {
          title: "222",
          image: "/image/map/map_carousel2.jpg",
        },
        {
          title: "333",
          image: "/image/map/map_carousel3.png",
        },
        {
          title: "444",
          image: "/image/map/map_carousel4.jpg",
        },
      ],
    };
  },
  methods: {
    handleChange(now, before) {
      console.log("now: ", now);
      console.log("before: ", before);
      this.chooseImageId = now;
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
};
</script>
<style scoped>
#section0 {
  height: 70px;
}
#section1 {
  position: relative;
}
.section1-background-img {
  width: 1920px;
  height: auto;
}
#section1-text {
  position: absolute;
  left: 6.7%;
  top: 11%;
  display: flex;
  flex-direction: column;
  flex: 1;
  flex-grow: 1;
  width: 700px;
  align-content: left;
}
.section1-title {
  font-size: 70px;
  font-family: "AlibabaPuHuiTiH";
  color: white;
  line-height: 100px;
  white-space: normal;
}
.section1-title-en {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiR";
  color: white;
}
.section1-subtitle {
  font-size: 45px;
  font-family: "AlibabaPuHuiTiH";
  color: rgba(220, 220, 220, 0.6);
}
.section1-subtitle-en {
  font-size: 22px;
  font-family: "AlibabaPuHuiTiR";
  color: rgba(220, 220, 220, 0.6);
}
#section2 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-top: 50px;
  margin-bottom: 50px;
}
.section3-spacing,
.section2-spacing {
  flex: 0.1875;
}
#section2-content {
  flex: 0.625;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.section2-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #3565a7;
  margin-bottom: 40px;
  flex: 0.1;
}
#section2-content-info {
  flex: 0.6;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 30px;
}
.section2-subtext {
  flex: 0.6;
  font-size: 19px;
  font-family: "AlibabaPuHuiTiR";
  color: #333333;
  text-align: justify;
}
.section2-image {
  flex: 0.3;
  align-self: center;
}

#section2-button-block {
  flex: 0.1;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  margin-bottom: 20px;
  .section2-button {
    height: 60px;
    width: 60px;
    background-image: url("/image/button/rightArrowBlueBorderImage.png");
    background-size: 100% 100%;
  }
  .section2-button:hover {
    height: 60px;
    width: 60px;
    background-image: url("/image/button/rightArrowBlueContentImage.png");
    background-size: 100% 100%;
  }
}

.section2-button-img {
}
.section2-button-img:hover {
  background-color: #2775b6;
  border-radius: 50%;
  content: url("/image/button/rightArrowImage.png");
}
#section3 {
  flex: 1;
  flex-grow: 1;
  flex-direction: column;
  justify-content: space-between;
  display: flex;
  margin-bottom: 50px;
}
#section3-title-block {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.section3-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #3565a7;
  margin-bottom: 40px;
  flex: 0.625;
}
#section3-content {
  /* margin-left: 10%;
  margin-right: 10%; */
  width: 100%;
}
#section3-content-box {
  width: 100vw;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

#section3-menu {
  width: 100%;
  height: 4vw;
  margin-top: 1vw;
  /* border: 2px red solid; */
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.section3-menu-item {
  margin-left: 4vw;
  margin-right: 4vw;
  /* border: 2px red solid; */
  color: #333333;
  font-family: "AlibabaPuHuiTiR";
  font-size: 22px;
}
.section3-menu-choose-item {
  margin-left: 4vw;
  margin-right: 4vw;
  /* border: 2px red solid; */
  color: #2775b6;
  font-family: "AlibabaPuHuiTiB";
  font-size: 22px;
}
</style>
