<template>
  <div class="container">
    <!--第一部分图片
        背景大图 + 标题-->
    <div class="section1-background-box">
      <div class="section1-gap" />
      <div class="section1-background">
      <div class="section1-background-right1"/>
        <!-- <img src="/image/about/section1/section1_background.jpg" /> -->
        <div class="section1-text-box">
          <template v-if="currentLanguage == 'en'">
            <div class="section1-text-en">
              {{ $t("aboutPage.section1.title") }}
            </div>
          </template>
          <template v-else>
            <div class="section1-text">
              {{ $t("aboutPage.section1.title") }}
            </div>
            <div class="section1-text-2">
              {{ $t("aboutPage.section1.subTitle") }}
            </div>
          </template>
        </div>
      </div>
    </div>
    <!-- <div id="section1">
      <div id="section1-background">
        <img src="/image/about/section1/section1_background.jpg" />
      </div>
      <div id="section1-block">
        <div id="section1-text-block"></div>
      </div>
    </div> -->
    <!--第二部分简介使命
        左右结构 左边文字再分column 0.4:0.4 右侧图案以下面为主 保证左右的上与下部分对齐-->
    <div id="section2">
      <div id="section2-content-block">
        <div id="section2-content-intro">
          <div class="section2-content-intro-text normalTitleClass">
            {{ $t("aboutPage.introduction.title") }}
          </div>
          <div
            class="section2-content-intro-subtext"
            :class="
              currentLanguage == 'en'
                ? 'normalEnglishTextClass'
                : 'normalTextClass'
            "
          >
            {{ $t("aboutPage.introduction.text") }}
          </div>
        </div>
        <div id="section2-content-mission">
          <div class="section2-content-mission-text normalTitleClass">
            {{ $t("aboutPage.mission.title") }}
          </div>
          <template v-if="currentLanguage == 'en'">
            <div
              class="section2-content-mission-subtext normalEnglishTextClass"
            >
              {{ $t("aboutPage.mission.text") }}
            </div>
          </template>
          <template v-else>
            <div class="section2-content-mission-subtext normalTextClass">
              以<span class="blueBoldTextClass">“瓷器起源、传播与全球化”</span
              >为研究主线，推动相关领域的信息和资源在世界范围内的共建共享，打造相关学者和机构之间的国际交流合作新平台，共同促进瓷器及其相关文化的保护、传承和创新利用。
            </div>
          </template>
        </div>
      </div>
      <div class="section2-image-block">
        <img
          class="section2-image-top"
          src="/image/about/section2/biglogo.png"
        />
        <div class="section2-image-bottom">
          <div class="section2-image-bottom-mission-outbox">
            <div class="section2-image-bottom-mission-box">
              <img
                class="section2-image-bottom-mission1"
                src="/image/about/section2/missionRight1.png"
              />
            </div>
          </div>
          <div class="section2-image-bottom-mission-outbox">
            <div class="section2-image-bottom-mission-box">
              <img
                class="section2-image-bottom-mission2"
                src="/image/about/section2/missionRight2.png"
              />
            </div>
          </div>
          <div class="section2-image-bottom-mission-outbox">
            <div class="section2-image-bottom-mission-box">
              <img
                class="section2-image-bottom-mission3"
                src="/image/about/section2/missionRight3.png"
              />
            </div>
          </div>
          <div class="section2-image-bottom-mission-outbox">
            <div class="section2-image-bottom-mission-box">
              <img
                class="section2-image-bottom-mission4"
                src="/image/about/section2/missionRight4.png"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--第三部分宣言
        采用 上下 左右 上下结构-->
    <div id="section3">
      <div id="section3-block">
        <div class="section3-header normalTitleClass">
          {{ $t("aboutPage.declaration.title") }}
        </div>
        <div id="section3-content">
          <div class="section3-image"></div>
          <div id="section3-text-block">
            <div
              class="section3-subtext"
              :class="
                currentLanguage == 'en'
                  ? 'normalEnglishTextClass'
                  : 'normalTextClass'
              "
            >
              {{ $t("aboutPage.declaration.text") }}
            </div>
            <div class="section3-button-box">
              <div
                class="section3-button"
                :hide-on-click="false"
                trigger="hover"
                @click="navigateTo('/declaration')"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--第四部分章程-->
    <div id="section4">
      <div id="section4-articles">
        <div id="section4-articles-content">
          <div class="section4-articles-content-header normalTitleClass">
            {{ $t("aboutPage.rules.title") }}
          </div>
          <template v-if="currentLanguage == 'en'">
            <div
              class="section4-articles-content-subtext normalEnglishTextClass"
            >
              {{ $t("aboutPage.rules.text1") }}
            </div>
          </template>
          <template v-else>
            <div class="section4-articles-content-subtext normalTextClass">
              本联盟的名称为<span class="blueBoldTextClass"
                >“国际瓷器研究联盟”</span
              >（Society of International Ceramic Studies），简称SICS。
            </div>
          </template>
            <div class="section4-articles-content-button"                 :hide-on-click="false"
                trigger="hover"
                @click="navigateTo('/articles')"></div>
        </div>
      </div>
      <div class="section4-articles-image-box">
        <template v-if="currentLanguage == 'en'">
          <img
            src="/image/about/section4/articlesEn.png"
            class="section4-articles-image"
          />
        </template>
        <template v-else>
          <img
            src="/image/about/section4/articlesCh.png"
            class="section4-articles-image"
          />
        </template>
      </div>
    </div>

    <!--第五部分成员-->
    <div id="section5">
      <div class="section5-title normalTitleClass">
        {{ $t("aboutPage.member.title") }}
      </div>
      <div class="section5-member-box">
        <div
          v-show="showCountryListFlag == 1"
          v-for="(country, index) in showCountryList1"
          :key="country.id"
        >
          <div class="countryBox">
            <div class="countryImageBox">
              <img class="countryImage" :src="`${country.image}`" />
            </div>

            <div class="countryTitleBox">
              {{ currentLanguage == "en" ? country.en : country.ch }}
            </div>
          </div>
        </div>
        <div
          v-show="showCountryListFlag == 2"
          v-for="(country, index) in showCountryList2"
          :key="country.id"
        >
          <div class="countryBox">
            <div class="countryImageBox">
              <img class="countryImage" :src="`${country.image}`" />
            </div>

            <div class="countryTitleBox">
              {{ currentLanguage == "en" ? country.en : country.ch }}
            </div>
          </div>
        </div>
      </div>
      <div class="section5-member-switch-box">
        <div
          :class="
            showCountryListFlag == 1
              ? 'section5-member-switch-full-dot'
              : 'section5-member-switch-empty-dot'
          "
          @click="changeCountryList(1)"
        />
        <div
          :class="
            showCountryListFlag == 2
              ? 'section5-member-switch-full-dot'
              : 'section5-member-switch-empty-dot'
          "
          @click="changeCountryList(2)"
        />
      </div>
      <div class="section5-member-info-box">
        {{ $t("aboutPage.member.info") }}
      </div>
    </div>
  </div>
</template>

<script>
import { getCountryList } from "@/api/getAboutData";
export default {
  name: "about",

  data() {
    return {
      countryList: [],
      showCountryListFlag: 1,
      showCountryList1: [],
      showCountryList2: [],
      currentPageName: "about",
    };
  },
  mounted() {
    this.countryList = getCountryList();
    this.showCountryList1 = this.countryList.slice(0, 10);
    this.showCountryList2 = this.countryList.slice(10, 19);
    // console.log("this.showCountryList:", this.showCountryList);
    // console.log("this.countryList:", this.countryList);
    this.$store.commit(
      "state/updatePageHeaderBackcolor",
      "rgba(255,255,255,255,1)"
    );
  },
  methods: {
    changeCountryList(pageNum) {
      console.log("this.showCountryListFlag:", this.showCountryListFlag);
      console.log("this.pageNum:", pageNum);
      if (pageNum != this.showCountryListFlag) {
        this.showCountryListFlag = pageNum;
      }
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  // width: 100vw;
  height: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 0.5vw;
}

.section1-background-box {
  /* border: 1px black solid; */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100vh;
  .section1-gap {
    // height: 4.2vw;
    height: 65px;
  }
  .section1-background {
    height: calc(100vh - 4.2vw);
    width: 100%;
    // background-image: url("/image/about/section1/section1_background.jpg");
    background-image: url("/image/about/animation/bac.jpg");
    background-position: center center;
    background-size: cover;
  }
}
.section1-background-right1 {

  top: 57%;
  right: 9.5%;
  position: absolute;
  background-image: url("/image/about/animation/right1.png");
  background-position: center center;
  background-size: cover;
  width: 17.5vw;
  height: 17.5vw;
  animation: circle 100s linear infinite alternate;
}

@keyframes circle {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.section1-text-box {
  // border: 1px red solid;
  width: 100%;
  height: 70%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  .section1-text-en {
    color: #333333;
    margin-bottom: 20vh;
    font-size: 5.1vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 5.5vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .section1-text {
    // border: 1px red solid;
    color: #333333;
    // margin-bottom: 8%;
    font-size: 5.5vw;
    text-align: center;
    letter-spacing: 0.2vw;
    line-height: 8vw;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
  .section1-text-2 {
    color: #333333;
    margin-bottom: 9.9vh;
    font-size: 2.7vw;
    text-align: center;
    letter-spacing: 0.2vw;
    font-weight: 900;
    font-family: "AlibabaPuHuiTiH", sans-serif;
  }
}

#section2 {
  width: 85%;
  margin-left: 15%;
  position: relative;
  // margin: auto;
  display: flex;
  flex-grow: 1;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 3%;
  margin-bottom: 5%;
  height: 70vw;
  // border: 2px solid red;
}
#section2-content-block {
  display: flex;
  flex: 0.4;
  flex-direction: column;
  justify-content: space-around;
}
#section2-content-mission,
#section2-content-intro {
  // border: 2px solid blue;
  flex: 0.48;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
.section2-content-mission-subtext,
.section2-content-intro-subtext {
  // border: 2px solid red;
  margin-top: 2vw;
  flex: 0.75;
}

.section2-content-intro-text,
.section2-content-mission-text {
  // margin-top: 1vw;
  color: #2775b6;
}

.normalTitleClass {
  font-family: "AlibabaPuHuiTiH";
  font-size: 2.4vw;
}

.normalTextClass {
  // font-size: 1.2vw;
  // line-height: 1.9vw;
  text-align: justify;
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.4vw;
  line-height: 2.8vw;
  letter-spacing: 0.05vw;
  // font-weight: bold;
}

.normalEnglishTextClass {
  text-align: justify;
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.3vw;
  line-height: 2.1vw;
  letter-spacing: 0vw;
}

.blueBoldTextClass {
  font-size: 1.4vw;
  font-weight: bold;
  color: #2775b6;
}

.section2-image-block {
  display: flex;
  flex: 0.55;
  flex-direction: column;
  justify-content: flex-start;
  // border: 2px solid blue;
  .section2-image-top {
    // flex: 0.45;
    margin-top: 9.5vw;
    // border: 2px solid red;
    width: 20vw;
    min-width: 200px;
  }
  .section2-image-bottom {
    margin-top: 15vw;
    height: 100%;
    // border: 2px solid red;
    // display: flex;
    // flex-direction: column;
    // justify-content: flex-end;
    .section2-image-bottom-mission-outbox {
      width: 100%;
      flex-direction: row;
      justify-content: flex-end;
      display: flex;
      .section2-image-bottom-mission-box {
        // border: 2px solid red;
        height: 5.7vw;
        // width: 100%;
        // flex-direction: column;
        // justify-content: flex-end;
        // display: flex;
        margin-bottom: 3vw;
      }
      .section2-image-bottom-mission1,
      .section2-image-bottom-mission2,
      .section2-image-bottom-mission3,
      .section2-image-bottom-mission4 {
        height: 100%;
      }
      .section2-image-bottom-mission1 {
      }
      .section2-image-bottom-mission2 {
      }
      .section2-image-bottom-mission3 {
      }
      .section2-image-bottom-mission4 {
      }
    }
  }
}

#section3 {
  display: flex;
  flex-direction: row;
  object-fit: contain;
  justify-content: center;
  background-color: #2775b6;
  height: 31vw;
  margin-bottom: 5%;
}
#section3-block {
  flex: 0.7;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}
.section3-header {
  flex: 0.2;
  color: white;
}
#section3-content {
  flex: 0.7;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  // border: 2px solid yellow;
}
.section3-image {
  // flex: 0.33;
  // border: 2px solid red;
  height: 16vw;
  width: 35vw;
  background-image: url("/image/about/section3/declarationImage.png");
  background-position: center center;
  background-size: cover;
}
#section3-text-block {
  // flex: 0.67;
  width: 100%;
  height: 100%;
  // border: 2px solid purple;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  padding-left: 2vw;
}
.section3-subtext {
  // flex: 0.55;
  // border: 2px red solid;
  color: white;
}
.section3-button-box {
  height: 6vw;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  cursor: pointer;
  //border: 2px solid purple;
}
.section3-button {
  width: 4vw;
  height: 4vw;
  z-index: 2;
  // background: rgba(255, 255, 255, 0.4);
  background-size: 100% 100%;
  background-image: url("/image/button/rightArrowImage.png");
}
.section3-button:hover {
  background-image: url("/image/button/rightArrowImageClick.png");
}

#section4 {
  // border: 2px solid red;
  // height: 70vw;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 70vw;
  margin: auto;
  margin-bottom: 5%;
}
#section4-articles {
  flex: 0.6;
  // border: 2px solid blue;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
}
#section4-members {
  flex: 0.4;
  // border: 2px solid blue;
}

#section4-articles-content {
  // flex: 0.6;
  // border: 2px purple solid;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
.section4-articles-image-box {
  padding-top: 2vw;
  height: 28vw;
  flex: 0.3;
  // border: 1px solid red;
  // background-image: url("/image/about/section4/articlesCh.png");
  // background-size: 100%;
  // background-color: red;
}
.section4-articles-image {
  width: 100%;
}
.section4-articles-content-header {
  // flex: 0.2;
  // border: 2px solid red;
  color: #2775b6;
}
.section4-articles-content-subtext {
  // flex: 0.3;
  margin-top: 4vw;
  // border: 2px solid red;
}
.section4-articles-content-button {
  margin-top: 3vw;
  width: 4vw;
  height: 4vw;
  z-index: 2;
  // flex: 0.15;
  // border: 2px solid red;
  background-image: url("/image/button/rightArrowBlueBorderImage.png");
  background-size: 100% 100%;
  cursor: pointer;
}
.section4-articles-content-button:hover {
  // border-radius: 50%;
  // background-color: #2775b6;
  background-image: url("/image/button/rightArrowBlueContentImage.png");
}

#section5 {
  // border: 2px solid red;
  height: 36vw;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  width: 70vw;
  margin: auto;
}
.section5-title {
  // border: 2px solid red;
  color: #2775b6;
}
.section5-member-box {
  // display: flex;
  // flex-direction: row;
  // justify-content: space-evenly;

  display: flex;
  justify-content: space-evenly;
  flex-wrap: wrap;

  margin-top: 2vw;
  width: 100%;
  height: 22vw;
  // border: 2px solid red;
}

.countryBox {
  // border: 2px solid blue;
  width: 13vw;
  height: 90%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;

  .countryImageBox {
    // border: 2px solid red;
    height: 70%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    .countryImage {
      height: 100%;
      filter: drop-shadow(#f4f4f4 0px 0px 8px);
    }
  }

  .countryTitleBox {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: AlibabaPuHuiTiR;
    color: #333333;
    font-size: 1.1vw;
    // height: 80%;
    width: 100%;
    margin-top: 0.2vw;
    // border: 2px solid red;
  }
}

.section5-member-switch-box {
  margin-top: 1vw;
  // border: 2px solid blue;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.section5-member-switch-full-dot {
  width: 1vw;
  height: 1vw;
  border-radius: 50%;
  border: 1px #3565a7 solid;
  background-color: #3565a7;
  margin: 0 0.3vw 0 0.3vw;
}

.section5-member-switch-empty-dot {
  width: 1vw;
  height: 1vw;
  border-radius: 50%;
  border: 1px #3565a7 solid;
  margin: 0 0.3vw 0 0.3vw;
  cursor: pointer;
}

.section5-member-info-box {
  margin-top: 1vw;
  // border: 2px solid black;
  font-size: 1.3vw;
  line-height: 2vw;
  font-family: AlibabaPuHuiTiR;
  color: #b3b3b3;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
}
</style>
