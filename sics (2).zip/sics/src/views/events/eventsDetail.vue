
<template>
  <div id="container">
    <div id="section0"></div>
    <!--section1包括新闻与...详情部分
            section2包括其他所有部分-->
    <div id="section1">
      <div class="section1-spacing"></div>
      <div id="section1-text">
        <div class="section1-current">
          <span @click="navigateTo('/newsAndEvent')" style="cursor: pointer">{{
            $t("eventsList.newsAndEvents")
          }}</span
          ><i class="el-icon-arrow-right"></i
          ><span @click="navigateTo('/events')" style="cursor: pointer">{{
            $t("eventsList.eventsList")
          }}</span
          ><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6; cursor: pointer" 
          @click="navigateTo('/events')"
            >{{ currentEventsData.type }}{{ $t("eventsList.space")}}{{ $t("eventsList.details") }}</span
          >
        </div>
        <div class="section1-title">{{ currentEventsData.title }}</div>
        <div class="section1-host">
          <img
            src="/image/miscellaneous/host_detail.jpg"
            style="width: 12px; margin-right: 5px"
          />{{ $t("eventsList.host") }}{{ currentEventsData.host }}
        </div>
        <div class="section1-date">
          <img
            src="/image/miscellaneous/time_detail.jpg"
            style="width: 12px; margin-right: 5px"
          />{{ $t("eventsList.dates") }}{{ currentEventsData.date }}
        </div>
        <div class="section1-subtext"><span style="word-spacing: 1.5em">{{ $t("miscellaneous.space") }}</span>{{ currentEventsData.subtext }}
        </div>
        <img
          :src="currentEventsData.image"
          style="width: 75%; align-self: center"
        />
        <div class="section1-site">
          <img
            src="/image/miscellaneous/link.jpg"
            style="width: 10px; margin-right: 5px"
          />{{ $t("eventsList.more")
          }}<a :href="currentEventsData.site" style="color: #0086ff" target="_blank">{{
            currentEventsData.site
          }}</a>
        </div>
      </div>
      <div class="section1-spacing"></div>
    </div>
  </div>
</template>
  
<script>
import { getEventsData } from "@/api/getData";
export default {
  name: "article",
  methods: {},
  data() {
    return {
      // 当前新闻数据对象
      currentEventsData: {},
    };
  },
  beforeMount() {
    console.log("this.$route.params:", this.$route.params.eventsId);
    var eventsId;
    // 根据ID获取currentNewsData，单独建立一个数据获取函数是为了和后面可能存在的后端做前期准备
    if(this.$route.params.eventsId == undefined || this.$route.params.eventsId == null) {
      if(this.$store.state.state.eventsId == undefined || this.$store.state.state.eventsId == null){
        // 缓存中也没有，直接跳转新闻列表
        this.$router.push('/news')
      }
      else {
        // 缓存中有
        eventsId = this.$store.state.state.eventsId;
      }
    }
    // 有路径参数，更新缓存
    else {
      this.$store.commit(
      "state/updateEventsId",
      this.$route.params.eventsId
    );
    eventsId = this.$route.params.eventsId;
    }
    this.getCurrentEventsData(eventsId);
  },
  mounted() {},
  methods: {
    getCurrentEventsData(id) {
      // 根据id及语言获取数据
      this.currentEventsData = getEventsData(id, this.$i18n.locale);
      console.log("this.currentEventsData:", this.currentEventsData);
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
};
</script>

<style scoped>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#section0 {
  height: 70px;
  width: 1024px;
}

#section1 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
.section1-spacing {
  flex: 0.1875;
}

.section1-current {
  font-size: 13.5px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 15px;
  margin-bottom: 10px;
}
#section1-text {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 0.625;
}
.section1-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #2775b6;
  text-align: center;
  margin-bottom: 20px;
}
.section1-date,
.section1-host {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiB";
  margin-top: 10px;
}
.section1-site,
.section1-subtext {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 30px;
  margin-bottom: 25px;
  white-space: pre-wrap;
}
.section1-subtext {
  text-align: justify;
}
</style>
  