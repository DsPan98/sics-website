<template>
    <div id="container">
      <div id="s0"></div>
      <div id="s1">
        <img
          src="/image/articles/articles_background.jpg"
          class="s1-background-img"
        />
        <div class="s1-title">
          {{ $t("declaration.title") }} 
        </div>
      </div>
      <div id="s2">
        <div class="s2-spacing"></div>
        <div id="s2-text">
          <div class="s2-current">
            <span @click="navigateTo('/about')" style="cursor: pointer">{{ $t("declaration.about") }}</span><i class="el-icon-arrow-right"></i
            ><span style="color: #2775b6">{{ $t("declaration.declaration") }}</span>
          </div>
          <div class="s2-title">{{ $t("declaration.declaration") }}</div>
          <div class="s2-subtitle">{{ $t("declaration.subtitle") }}</div>
          <div class="s2-subtext">{{$t("declaration.subtext")}}</div>
        </div>
        <div class="s2-spacing"></div>
      </div>
    </div>
  </template>
  
  <script>
  export default{
    name:"declaration",
    methods:{
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  }
  }
  </script>
  
  <style>
  #container {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex-grow: 1;
    flex: 1;
  }
  #s0 {
    height: 70px;
  }
  #s1 {
    position: relative;
    background-color: black;
  }
  .s1-background-img {
    width: 1920px;
    height: auto;
    opacity: 0.6;
    filter: alpha(opacity=60);
  }
  .s1-title {
    position: absolute;
    top: 48%;
    left: 47%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 45px;
    font-family: "AlibabaPuHuiTiH";
    white-space: nowrap;
    text-align: center;
  }
  #s2 {
    position: relative;
    display: flex;
    flex-direction: row;
    flex-grow: 1;
    justify-content: space-between;
    margin-bottom:5%;
  }
  .s2-spacing {
    flex: 0.1875;
  }
  #s2-text {
    display: flex;
    flex-direction: column;
    flex: 0.625;
  }
  .s2-current {
    font-size: 18px;
    font-family: "AlibabaPuHuiTiR";
    margin-top: 15px;
    margin-bottom: 10px;
  }
  .s2-title {
    font-size: 30px;
    font-family: "AlibabaPuHuiTiH";
    color: #2775b6;
    margin-top:2%;
    margin-bottom:3%;
  }
  .s2-subtitle{
    font-size: 20px;
  font-family: "AlibabaPuHuiTiB";
  color: black;
  margin-bottom: 20px;
  line-height: 33px;
  margin-top: 2%;
  }

  .s2-subtext{
    font-size: 20px;
    font-family: "AlibabaPuHuiTiR";
    white-space: pre-wrap;
    line-height: 35px;
    margin-bottom: 2%;
    text-align: justify;
  }
  </style>