<template>
  <div id="container">
    <div id="section0"></div>
    <!--section1包括新闻与...详情部分
            section2包括其他所有部分-->

    <div id="section1">
      <div class="section1-spacing"></div>
      <div id="section1-text">
        <div class="section1-current">
          <span @click="navigateTo('/newsAndEvent')" style="cursor: pointer">{{ $t("newsList.newsAndEvents") }}</span><i class="el-icon-arrow-right"></i
          ><span @click="navigateTo('/news')" style="cursor: pointer">{{ $t("newsList.newsList") }}</span><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6"
            >{{ $t("newsList.news") }}{{ $t("newsList.details") }}</span
          >
        </div>
        <div class="section1-title">{{ currentNewsData.title }}</div>
        <div class="section1-host">
          {{ $t("newsList.source") }}{{ currentNewsData.source }} |
          {{ $t("newsList.date") }}{{ currentNewsData.date }}
        </div>
        <img :src="currentNewsData.image" style="width: 75%; align-self: center;" />
        <div class="section1-subtext" style="white-space: pre-wrap;"><span style="word-spacing: 1.5em">{{$t("miscellaneous.space")}}</span>{{currentNewsData.subtext}}</div>
        <div class="section1-site">
          <img src="/image/miscellaneous/link.jpg" style="width:10px;margin-right:5px"/>{{ $t("newsList.more") }}<a :href="currentNewsData.site" target="_blank"
           style="color:#0086FF">{{ currentNewsData.site }}</a
        >
        </div>
      </div>
      <div class="section1-spacing"></div>
    </div>
  </div>
</template>
  
<script>
import { getNewsData, newsList_en } from "@/api/getData";
export default {
  name: "article",
  methods: {},
  data() {
    return {
      // 当前新闻数据对象
      currentNewsData: {},
    };
  },
  beforeMount() {
    // console.log("this.$route.params:", this.$route.params.newsId);
    // console.log("this.$store.state.newsId:", this.$store.state.state.newsId);
    var newsid;
    // 根据ID获取currentNewsData，单独建立一个数据获取函数是为了和后面可能存在的后端做前期准备
    if(this.$route.params.newsId == undefined || this.$route.params.newsId == null) {
      if(this.$store.state.state.newsId == undefined || this.$store.state.state.newsId == null){
        // 缓存中也没有，直接跳转新闻列表
        this.$router.push('/news')
      }
      else {
        // 缓存中有
        newsid = this.$store.state.state.newsId;
      }
    }
    // 有路径参数，更新缓存
    else {
      this.$store.commit(
      "state/updateNewsId",
      this.$route.params.newsId
    );
    newsid = this.$route.params.newsId;
    }
    
    // return this.$store.state.state.pageHeaderBackcolor;
    this.getCurrentNewsData(newsid);
  },
  mounted() {},
  methods: {
    getCurrentNewsData(id) {
      // 根据id及语言获取数据
      this.currentNewsData = getNewsData(id, this.$i18n.locale);
      console.log("this.currentNewsData:", this.currentNewsData);
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
};
</script>

<style scoped>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#section0 {
  height: 70px;
  width: 1024px;
}

#section1 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
.section1-spacing {
  flex: 0.1875;
}

.section1-current {
  font-size: 13.5px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 15px;
  margin-bottom: 20px;

}
#section1-text {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 0.625;
}
.section1-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #2775b6;
  text-align: center;
  margin-bottom: 20px;
}
.section1-host {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  color: rgba(102,102,102,1);
  margin-bottom: 30px;

}
.section1-site,
.section1-subtext {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 20px;
  margin-bottom: 25px;
}
.section1-subtext{
  text-align: justify;
}
.section1-image {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  height: 200px;
}

</style>
  