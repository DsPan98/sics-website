<template>
  <div id="container">
    <div id="s0"></div>
    <div id="s1">
      <img src="/image/news/news_background.jpg" class="s1-background-img" />
      <div class="s1-title">
        {{ $t("newsList.title") }}
      </div>
    </div>
    <div id="s2">
      <div class="s2-spacing"></div>
      <div id="s2-content">
        <div class="s2-current">
          <span @click="navigateTo('/newsAndEvent')" style="cursor: pointer">{{ $t("newsList.newsAndEvents") }}</span><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6;">{{ $t("newsList.newsList") }}</span>
        </div>
        <div class="s2-title">{{ $t("newsList.newsList") }}</div>
        <div id="s2-content-news-block">
          <div
            class="s2-content-news"
            v-for="(news, index) in currentNewsList"
            :key="index"
          >
            <div id="s2-content-news-block1">
              <div class="s2-content-title"
                style="cursor: pointer"
                @click="navigateWithId(news.id)">
                {{ news.title }}
              </div>
            </div>
            <div class="s2-content-subtext">{{ news.subtext }}</div>
            <div id="s2-content-event-block3">
              <div id="s2-content-hostAndDate">
                <div class="s2-content-date-icon">
                  <img
                    src="/image/miscellaneous/time_list.jpg"
                    style="width: 10px; margin-right: 5px"
                  />
                </div>
                <div class="s2-content-date-text">{{ news.date }}</div>
              </div>
              <div
                class="s2-content-button"
                style="cursor: pointer"
                :hide-on-click="false"
                trigger="hover"
                @click="navigateWithId(news.id)"
              >
                <img src="/image/events/events_arrow.png" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="s2-spacing"></div>
    </div>
  </div>
</template>
    
  <script>
import { newsList_zh, newsList_en } from "@/api/getData";
export default {
  name: "newsList",
  methods: {
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    /*
      navigateWithParam(list){
          this.$router.push({
              name:'newsDetail',
              params:{
                  subtext:list.subtext,
                  type:list.type,
                  host:list.host,
                  date:list.date,
              }
          })
      },*/
    navigateWithId(id) {
      this.$router.push({
        name: "newsDetail",
        params: {
          newsId: id,
        },
      });
    },
  },
  data() {
    return {
      newsList_zh: newsList_zh,
      newsList_en: newsList_en,
    };
  },
  computed: {
    currentNewsList() {
      if (this.$i18n.locale === "en") {
        return this.newsList_en;
      }
      return this.newsList_zh;
    },
  },
};
</script>
  <style scoped>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#s0 {
  height: 70px;
}
#s1 {
  position: relative;
  background-color: black;
}
.s1-title {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 60px;
  font-family: "AlibabaPuHuiTiH";
  white-space: nowrap;
  text-align: center;
}
.s1-background-img {
  width: 1920px;
  height: auto;
  opacity: 0.6;
}
#s2 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
.s2-spacing {
  flex: 0.1875;
}
#s2-content {
  display: flex;
  flex-direction: column;
  flex: 0.625;
}
.s2-current {
  font-size: 13.5px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 25px;
  margin-bottom: 10px;
}
.s2-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #2775b6;
}
#s2-content-news-block {
  flex-grow: 1;
  flex: 1;
  display: flex;
  position: relative;
  flex-direction: column;
  justify-content: space-between;
  margin-top: 25px;
}
#s2-content-news-block1 {
  flex: 1;
  display: flex;
  position: relative;
  flex-direction: row;
  justify-content: space-between;
}
.s2-content-news {
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  border-bottom: 1px solid #dbdbdb;
}
.s2-content-news:hover {
  background-color: #f9f9f9;
}

.s2-content-title {
  font-size: 20px;
  font-family: "AlibabaPuHuiTiB";
  color: #2775b6;
  line-height: 33px;
  flex: 0.8;
  display: flex;
  margin-top: 10px;
}
.s2-content-subtext {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  white-space: pre-wrap;
  line-height: 33px;
  margin-bottom: 2%;
  text-align: justify;
}

#s2-content-hostAndDate {
  font-size: 15px;
  font-family: "AlibabaPuHuiTiB";
  white-space: pre-wrap;
  line-height: 33px;
  margin-bottom: 2%;
  flex: 0.8;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
}
.s2-content-button {
  position: relative;
  display: flex;
  flex: 0.06;
  margin: auto;
}
#s2-content-event-block3 {
  flex: 1;
  flex-direction: row;
  justify-content: space-between;
  display: flex;
}

.s2-content-button:hover {
  display: contain;
  height: 20px;
  content: url(/image/events/events_arrow_hover.png);
}
</style>