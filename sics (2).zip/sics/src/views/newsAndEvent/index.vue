<template>
  <div class="container">
    <!--第一部分图片-->
    <div class="banner-background-box">
      <div class="banner-top-gap" />
      <div class="banner-background">
        <div
          class="banner-background-image"
          :style="{ backgroundImage: `url(${bannerList[currentBannerIndex]})` }"
        />
        <div class="banner-center-box">
          <div class="banner-center-left" @click="changeBannerImage()" />
          <div class="banner-center-right" @click="changeBannerImage()" />
        </div>
        <div class="banner-bottom-box">
          <div
            :class="
              currentBannerIndex == 0
                ? 'banner-bottom-switch-full-dot'
                : 'banner-bottom-switch-empty-dot'
            "
            @click="changeBannerImage(0)"
          />
          <div
            :class="
              currentBannerIndex == 1
                ? 'banner-bottom-switch-full-dot'
                : 'banner-bottom-switch-empty-dot'
            "
            @click="changeBannerImage(1)"
          />
        </div>
        <!-- <img src="/image/about/section1/section1_background.jpg" /> -->
      </div>
    </div>
    <!--第二部分展览-->
    <div id="exhibit">
      <div class="exhibit-title-box">
        <div class="exhibit-title normalTitleClass">
          {{ $t("newsAndEventsPage.exhibitTitle") }}
        </div>
        <div
          class="moreButtomClass"
          :hide-on-click="false"
          trigger="hover"
          @click="navigateTo('/exhibitions')"
        >
          {{ $t("newsAndEventsPage.more") }}
        </div>
      </div>
      <div class="exhibit-content-block">
        <div
          class="exhibit-content-item-box"
          v-for="(exhibit, index) in exhibitList"
          :key="index"
        >
          <div
            class="exhibit-content-img-box"
            @click="navigateExhibitionsWithId(exhibit.id)"
            :style="{ backgroundImage: `url(${exhibit.image})` }"
          ></div>
          <div class="exhibit-content-title-box">
            {{ currentLanguage == "en" ? exhibit.titleEn : exhibit.titleCh }}
          </div>
        </div>
      </div>
    </div>

    <!--第三部分活动-->
    <div class="events-class">
      <div class="events-box-class">
        <div class="events-title-box">
          <div class="events-title normalTitleClass">
            {{ $t("newsAndEventsPage.eventsTitle") }}
          </div>
          <div
            class="moreButtomClass2"
            :hide-on-click="false"
            trigger="hover"
            @click="navigateTo('/events')"
          >
            {{ $t("newsAndEventsPage.more") }}
          </div>
        </div>
        <div
          class="events-content-box"
          @mouseenter="changeImgBtn()"
          @mouseleave="restore"
        >
          <div
            @click="navigateEventsWithId(eventsList[0].id)"
            class="events-content-left-box"
            :style="{ backgroundImage: `url(${eventsList[0].image})` }"
          >
            <div
              class="events-image-mask"
            />
            <div class="events-content-left-button-box">
              <div
                class="events-content-left-button"
                style="cursor: pointer"
                v-on:click.stop="prevEvents()"
              />
              <div
                class="events-content-right-button"
                style="cursor: pointer"
                v-on:click.stop="nextEvents()"
              />
            </div>
            <div class="events-content-left-title eventTitleClass">
              {{
                currentLanguage == "en"
                  ? eventsList[0].titleEn
                  : eventsList[0].titleCh
              }}
            </div>
          </div>
          <div class="events-content-right-box">
            <div
              class="events-content-right-child-box"
              @click="navigateEventsWithId(eventsList[1].id)"
              :style="{ backgroundImage: `url(${eventsList[1].image})` }"
            >
              <div class="events-image-mask" />
              <div class="events-content-right-child-title eventTitleClass">
                {{
                  currentLanguage == "en"
                    ? eventsList[1].titleEn
                    : eventsList[1].titleCh
                }}
              </div>
            </div>
            <div
              class="events-content-right-child-box"
              @click="navigateEventsWithId(eventsList[2].id)"
              :style="{ backgroundImage: `url(${eventsList[2].image})` }"
            >
              <div class="events-image-mask" />
              <div class="events-content-right-child-title eventTitleClass">
                {{
                  currentLanguage == "en"
                    ? eventsList[2].titleEn
                    : eventsList[2].titleCh
                }}
              </div>
            </div>
            <div
              class="events-content-right-child-box"
              @click="navigateEventsWithId(eventsList[3].id)"
              :style="{ backgroundImage: `url(${eventsList[3].image})` }"
            >
              <div class="events-image-mask" />
              <div class="events-content-right-child-title eventTitleClass">
                {{
                  currentLanguage == "en"
                    ? eventsList[3].titleEn
                    : eventsList[3].titleCh
                }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!--第四部分新闻-->
    <div id="news">
      <div class="news-title-box">
        <div class="news-title normalTitleClass">
          {{ $t("newsAndEventsPage.newsTitle") }}
        </div>
        <div
          class="moreButtomClass"
          :hide-on-click="false"
          trigger="hover"
          @click="navigateTo('/news')"
        >
          {{ $t("newsAndEventsPage.more") }}
        </div>
      </div>
      <div class="news-content-block">
        <div
          class="news-content-item-box"
          v-for="(news, index) in newsList"
          :key="news.id"
        >
          <div class="news-content-item">
            <div
              class="news-content-item-left"
              :style="{ backgroundImage: `url(${news.image})` }"
            ></div>
            <div class="news-content-item-right">
              <div class="news-content-item-right-title news-title-class">
                {{ currentLanguage == "en" ? news.titleEn : news.titleCh }}
              </div>
              <div class="news-content-item-right-content news-content-class">
                {{ currentLanguage == "en" ? news.contentEn : news.contentCh }}
              </div>
              <div
                class="news-content-item-right-button"
                @click="navigateNewsWithId(news.id)"
              >
                <div class="news-content-item-right-arrow" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getExhibit, getNews, getEvents } from "@/api/getNewsEventData";
export default {
  name: "about",
  methods: {},
  data() {
    return {
      // 定时器
      timer: null,
      // 活动定时器
      eventsTimer: null,
      // banner图像列表
      bannerList: [
        "/image/newsAndEvent/banner/banner1.png",
        "/image/join/join_background.jpg",
      ],
      currentBannerIndex: 0,
      // 展览列表
      exhibitList: [],
      // 新闻列表
      newsList: [],
      // 活动列表
      eventsList: [],
    };
  },
  beforeMount() {
    this.exhibitList = getExhibit();
    this.newsList = getNews();
    this.eventsList = getEvents();
    this.$store.commit(
      "state/updatePageHeaderBackcolor",
      "rgba(255,255,255,255,1)"
    );
  },
  created() {
    // 每次进入界面时，先清除之前的所有定时器，然后启动新的定时器
    clearInterval(this.timer);
    clearInterval(this.eventsTimer);
    this.timer = null;
    //当程序进来的时候，打开定时器，令起自动轮播
    this.timer = setInterval(() => {
      if (this.currentBannerIndex != 0) this.currentBannerIndex = 0;
      else this.currentBannerIndex = 1;
    }, 3000);

    // 活动定时器
    this.eventsTimer = null;
    this.eventsTimer = setInterval(() => {
      this.nextEvents();
    }, 3000);
  },
  destroyed() {
    clearInterval(this.timer);
    clearInterval(this.eventsTimer);
  },
  methods: {
    //当鼠标悬停的时候关闭定时器
    changeImgBtn() {
      clearInterval(this.eventsTimer);
    },
    // 当鼠标离开的时候打开定时器
    restore() {
      this.eventsTimer = setInterval(() => {
        this.nextEvents();
      }, 3000);
    },
    changeBannerImage(id = -1) {
      clearInterval(this.timer);
      if (id == -1) {
        if (this.currentBannerIndex != 0) this.currentBannerIndex = 0;
        else this.currentBannerIndex = 1;
      } else if (this.currentBannerIndex != id) this.currentBannerIndex = id;
    },
    nextEvents() {
      // 下一条活动，把第一条填到末尾 eventsList
      let templist = this.eventsList;
      var first = templist.shift(); //取数组第一项
      templist.push(first); //插入数组最后一位
      this.eventsList = templist;
    },
    prevEvents() {
      // 上一条活动，把最后一条填到开始 eventsList
      let templist = this.eventsList;
      var last = templist.pop(); //取数组最后一项
      templist.unshift(last); //插入数组第一位
      this.eventsList = templist;
      // console.log("end this.eventsList： ", this.eventsList);
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    /*实现走马灯活动具体跳转页面*/
    navigateEventsWithId(id) {
      console.log(id);
      this.$router.push({
        name: "eventsDetail",
        params: {
          eventsId: id,
        },
      });
    },
    navigateNewsWithId(id) {
      console.log(id);
      this.$router.push({
        name: "newsDetail",
        params: {
          newsId: id,
        },
      });
    },
    navigateExhibitionsWithId(id){
      console.log(id);
      this.$router.push({
        name:"exhibitionsDetail",
        params:{
          exhibitionsId: id,
        },
      })
    },
  },
  computed: {
    currentLanguage() {
      return this.$i18n.locale;
    },
  },
};
</script>
<style lang="less" scoped>
.container {
  width: 100%;
  height: auto;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  min-height: 0.5vw;
}
.moreButtomClass {
  font-family: "AlibabaPuHuiTiR";
  font-size: 1vw;
  line-height: 1.2vw;
  color: #2775b6;
  border: 2px #2775b6 solid;
  padding: 2px 14px 2px 14px;
  border-radius: 9%;
  cursor: pointer;
}
.moreButtomClass:hover {
  background: #2775b6;
  color: #ffffff;
}
.moreButtomClass2 {
  font-family: "AlibabaPuHuiTiR";
  font-size: 1vw;
  line-height: 1.2vw;
  color: #ffffff;
  border: 2px #ffffff solid;
  padding: 2px 14px 2px 14px;
  border-radius: 9%;
  cursor: pointer;
}
.moreButtomClass2:hover {
  background: #ffffff;
  border: 2px #2775b6 solid;
  color: #2775b6;
}

.normalTitleClass {
  font-family: "AlibabaPuHuiTiH";
  font-size: 2.4vw;
}

.normalTextClass {
  text-align: justify;
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.3vw;
  line-height: 2.8vw;
  letter-spacing: 0.05vw;
  // font-weight: bold;
}
.banner-background-box {
  // position: relative;
  /* border: 1px black solid; */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100vh;
  .banner-top-gap {
    // height: 4.2vw;
    height: 65px;
  }
  .banner-background {
    height: calc(100vh - 4.2vw);
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;

    .banner-background-image {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-position: center center;
      background-size: cover;
      transition: all 2s ease-in-out;
    }
    .banner-center-box {
      width: 100%;
      // border: 2px red solid;
      margin-top: 35vh;
      height: 14vh;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      .banner-center-right,
      .banner-center-left {
        height: 100%;
        width: 3.7vw;
        background: rgba(255, 255, 255, 0.5);
        background-size: 40% 40%;
        background-repeat: no-repeat;
        background-position: center center;
        cursor: pointer;
      }
      .banner-center-left {
        margin-left: 8vw;
        background-image: url("/image/newsAndEvent/banner/left.png");
      }
      .banner-center-right {
        margin-right: 8vw;
        background-image: url("/image/newsAndEvent/banner/right.png");
      }
    }

    .banner-bottom-box {
      width: 100%;
      // border: 2px black solid;
      margin-bottom: 3vw;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;

      .banner-bottom-switch-full-dot,
      .banner-bottom-switch-empty-dot {
        width: 15px;
        height: 15px;
        border-radius: 50%;
        margin: 0 0.6vw 0 0.6vw;
      }
      .banner-bottom-switch-empty-dot {
        background-color: #ffffff;
        cursor: pointer;
      }

      .banner-bottom-switch-full-dot {
        background-color: #2775b6;
      }
    }
  }
}

#exhibit {
  // border: 2px solid red;
  display: flex;
  flex-direction: column;
  // object-fit: contain;
  justify-content: flex-start;
  // height: 31vw;
  width: 70vw;
  margin-bottom: 5%;
  margin-top: 3%;
}
.exhibit-title-box {
  // flex: 0.2;
  // border: 2px solid blue;
  width: 100%;
  // height: 4vw;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  .exhibit-title {
    color: #2775b6;
  }
}
.exhibit-content-block {
  // border: 2px solid red;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  margin-top: 2vw;
  width: 100%;
  height: 41.5vw;

  .exhibit-content-item-box {
    // border: 2px solid blue;
    width: 34vw;
    height: 48%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-end;
    color: #333333;
    cursor: pointer;
    // filter: drop-shadow(#f4f4f4 0px 0px 8px);
    .exhibit-content-img-box {
      // border: 2px solid blue;
      height: 81%;
      width: 34vw;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      background-position: center center;
      background-size: 100%;
      transition: background-size 0.8s ease;
    }

    .exhibit-content-img-box:hover {
      background-size: 120%;
    }
    .exhibit-content-title-box {
      border-left: 2px #2775b6 solid;
      border-right: 2px #2775b6 solid;
      border-bottom: 2px #2775b6 solid;
      width: 34vw;
      height: 20%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: AlibabaPuHuiTiR;
      font-size: 1.4vw;
      font-weight: bold;
      // height: 80%;
      width: 100%;
    }
  }
  .exhibit-content-item-box:hover {
    background: #2775b6;
    color: #ffffff;
  }
}

.events-class {
  width: 100%;
  background: #2775b6;
  height: 46vw;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  margin-bottom: 5%;
  margin-top: 3%;

  .events-box-class {
    // border: 2px solid red;
    display: flex;
    flex-direction: column;
    // object-fit: contain;
    justify-content: flex-start;
    // height: 31vw;
    width: 70vw;
    margin-bottom: 5%;
    margin-top: 3%;

    .events-title-box {
      // flex: 0.2;
      // border: 2px solid blue;
      width: 100%;
      // height: 4vw;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      .events-title {
        color: #ffffff;
      }
    }

    .events-content-box {
      // border: 2px white solid;
      width: 100%;
      height: 32vw;
      margin-top: 2vw;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      .events-content-left-box {
        // border: 2px red solid;
        width: 71%;
        height: 100%;
        background-position: center center;
        background-size: cover;
        transition: all 2s ease-in-out;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        cursor: pointer;
        .events-content-left-title {
          width: 100%;
          height: 5vw;
          // border: 2px white solid;
          margin-bottom: 1.4vw;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        .events-content-left-button-box {
          width: 100%;
          height: 7vw;
          // border: 2px white solid;
          margin-top: 27%;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;
          .events-content-left-button,
          .events-content-right-button {
            width: 4vw;
            height: 4vw;
            background-size: 100%;
            z-index: 5;
          }
          .events-content-left-button {
            margin-left: 6%;
            background-image: url("/image/home/section3/left/section3_left_button.png");
          }
          .events-content-right-button {
            margin-right: 6%;
            background-image: url("/image/home/section3/left/section3_right_button.png");
          }
        }
      }
      .events-content-right-box {
        // border: 2px yellow solid;
        width: 27%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        //pointer-events: none;
        .events-content-right-child-box {
          width: 100%;
          height: 31%;
          // border: 2px white solid;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-end;
          background-position: center center;
          background-size: 100%;
          cursor: pointer;

          .events-content-right-child-title {
            width: 100%;
            height: 3vw;
            // border: 2px white solid;
            margin-bottom: 0.1vw;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }
}
.events-image-mask {
  position: absolute;
  width: 100%;
  height: 100%;
  // background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, #000000 100%);
  background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #000000 160%);
}
.eventTitleClass {
  font-family: "AlibabaPuHuiTiR";
  font-size: 1.2vw;
  color: #ffffff;
}

#news {
  // border: 2px solid red;
  display: flex;
  flex-direction: column;
  // object-fit: contain;
  justify-content: flex-start;
  // height: 31vw;
  width: 70vw;
  margin-bottom: 5%;
  margin-top: 3%;
}
.news-title-box {
  // flex: 0.2;
  // border: 2px solid blue;
  width: 100%;
  // height: 4vw;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  .news-title {
    color: #2775b6;
  }
}
.news-content-block {
  // border: 2px solid red;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  margin-top: 2vw;
  width: 100%;
  height: 55vw;
  .news-content-item-box {
    border-bottom: 2px solid #e8e8e8;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    height: 30%;
    width: 100%;
    .news-content-item {
      // border: 2px solid purple;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      height: 82%;
      width: 100%;
      .news-content-item-left {
        // border: 2px solid blue;
        height: 100%;
        width: 35%;
        background-repeat: no-repeat;
        background-size: 100%;
        background-position: center;
        transition: background-size 0.8s ease;
        cursor: pointer;
      }
      .news-content-item-left:hover {
        background-size: 120%;
        // transform: scale(1.4);
      }
      .news-content-item-right {
        // border: 2px solid blue;
        height: 100%;
        width: 63%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        .news-content-item-right-title {
          width: 100%;
          cursor: pointer;
          // border: 2px solid red;
        }
        .news-content-item-right-content {
          width: 100%;
          // border: 2px solid red;
        }
        .news-content-item-right-button {
          width: 100%;
          // border: 2px solid red;
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          align-items: center;
        }
      }
    }
  }
}

.news-content-item-right-arrow {
  height: 1.6vw;
  width: 4.2vw;
  background-image: url("/image/events/events_arrow.png");
  background-size: 100% 100%;
  cursor: pointer;
}
.news-content-item-right-arrow:hover {
  background-image: url("/image/events/events_arrow_hover.png");
}
.news-title-class {
  font-size: 1.4vw;
  font-family: AlibabaPuHuiTiR;
  font-weight: bold;
  color: #2775b6;
}
.news-content-class {
  font-size: 1.2vw;
  font-family: AlibabaPuHuiTiR;
  color: #333333;
  letter-spacing: 0.1vw;

  word-break: break-all;
  /* autoprefixer: ignore next */
  display: -webkit-box;
  /* autoprefixer: ignore next */
  -webkit-line-clamp: 3; //超出几行
  /* autoprefixer: ignore next */
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
