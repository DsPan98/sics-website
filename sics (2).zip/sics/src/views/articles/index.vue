<template>
  <div id="container">
    <div id="s0"></div>
    <div id="s1">
      <img
        src="/image/articles/articles_background.jpg"
        class="s1-background-img"
      />
      <div class="s1-title">
        {{ $t("articles.title") }}
      </div>
    </div>
    <div id="s2">
      <div class="s2-spacing"></div>
      <div id="s2-text">
        <div class="s2-current">
          <span @click="navigateTo('/about')" style="cursor: pointer">{{
            $t("articles.about")
          }}</span
          ><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6">{{ $t("articles.articles") }}</span>
        </div>
        <div class="s2-title">{{ $t("articles.articles") }}</div>
        <div
          id="s2-text-blocks"
          v-for="(item, index) in articlesList"
          :key="index"
        >
          <div class="s2-text-chapter">
            <div class="s2-text-chapter-title">{{ item.title }}</div>
            <div class="s2-text-chapter-subtext">{{ item.subtext }}</div>
          </div>
        </div>
      </div>
      <div class="s2-spacing"></div>
    </div>
  </div>
</template>

<script>
import { getArticlesListData } from "@/api/getArticlesData";
export default {
  name: "articles",
  methods: {
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
    getCurrentArticlesListData() {
      this.articlesList = getArticlesListData(this.$i18n.locale);
    },
  },
  data() {
    return {
      articlesList: [],
    };
  },
  beforeMount() {
    this.getCurrentArticlesListData();
  },
  mounted() {},
};
</script>

<style>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#s0 {
  height: 70px;
}
#s1 {
  position: relative;
  background-color: black;
}
.s1-background-img {
  width: 1920px;
  height: auto;
  opacity: 0.6;
  filter: alpha(opacity=60);
}
.s1-title {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 45px;
  font-family: "AlibabaPuHuiTiH";
  white-space: nowrap;
  text-align: center;
}
#s2 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
.s2-spacing {
  flex: 0.1875;
}
#s2-text {
  display: flex;
  flex-direction: column;
  flex: 0.625;
}
.s2-current {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 15px;
  margin-bottom: 10px;
}
.s2-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #2775b6;
}
.s2-text-chapter-title,
.s2-text-chapter1-title,
.s2-text-chapter2-title,
.s2-text-chapter3-title,
.s2-text-chapter4-title,
.s2-text-chapter5-title {
  font-size: 20px;
  font-family: "AlibabaPuHuiTiB";
  color: #2775b6;
  margin-bottom: 15px;
  line-height: 33px;
  margin-top: 2%;
}
.s2-text-chapter-subtext,
.s2-text-chapter1-subtext,
.s2-text-chapter2-subtext,
.s2-text-chapter3-subtext,
.s2-text-chapter4-subtext,
.s2-text-chapter5-subtext {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  white-space: pre-wrap;
  line-height: 33px;
  margin-bottom: 2%;
  /* border:2px solid red; */
}
</style>