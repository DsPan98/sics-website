<template>
  <div id="container">
    <div id="section0"></div>
    <!--section1包括新闻与...详情部分
            section2包括其他所有部分-->
    <div id="section1">
      <div class="section1-spacing"></div>
      <div id="section1-text">
        <div class="section1-current">
          <span @click="navigateTo('/newsAndEvent')" style="cursor: pointer">{{ $t("exhibitionsList.newsAndEvents") }}</span><i class="el-icon-arrow-right"></i
          ><span @click="navigateTo('/exhibitions')" style="cursor: pointer">{{ $t("exhibitionsList.exhibitionsList") }}</span><i class="el-icon-arrow-right"></i
          ><span style="color: #2775b6">{{$t("exhibitionsList.exhibitions")}}{{ $t("exhibitionsList.details") }}</span
          >
        </div>
        <div class="section1-title">{{ currentExhibitionsData.title }}</div>
        <div class="section1-host"><img src="/image/miscellaneous/location_detail.jpg" style="width:10px; margin-right:5px"/>{{ $t("exhibitionsList.location") }}{{ currentExhibitionsData.host }}</div>
        <div class="section1-date"><img src="/image/miscellaneous/time_detail.jpg" style="width:10px; margin-right:5px"/>{{ $t("exhibitionsList.dates") }}{{ currentExhibitionsData.date }}</div>
        <div class="section1-subtext" style="white-space: pre-wrap;"><span style="word-spacing: 1.5em">{{$t("miscellaneous.space")}}</span>{{ currentExhibitionsData.subtext }}</div>
        <img :src="currentExhibitionsData.image" style="width: 75%; align-self: center;"/>
        <div class="section1-site">
          <img src="/image/miscellaneous/link.jpg" style="width:10px;margin-right:5px"/>{{ $t("exhibitionsList.more") }}<a :href="currentExhibitionsData.site" target="_blank"
           style="color:#0086FF; font-family:'AlibabaPuHuiTiR'; font-size:18px">{{ currentExhibitionsData.site }}</a
        >
        </div>
      </div>
      <div class="section1-spacing"></div>
    </div>
  </div>
</template>
  
<script>
import { getExhibitionsData } from "@/api/getData";
export default {
  name: "article",
  methods: {},
  data() {
    return {
      // 当前新闻数据对象
      currentExhibitionsData: {},
    };
  },
  beforeMount() {
    // console.log("this.$route.params:", this.$route.params.exhibitionsId);
    var exhibitionsId;
    // 根据ID获取currentNewsData，单独建立一个数据获取函数是为了和后面可能存在的后端做前期准备
    if(this.$route.params.exhibitionsId == undefined || this.$route.params.exhibitionsId == null) {
      if(this.$store.state.state.exhibitionsId == undefined || this.$store.state.state.exhibitionsId == null){
        // 缓存中也没有，直接跳转新闻列表
        this.$router.push('/news')
      }
      else {
        // 缓存中有
        exhibitionsId = this.$store.state.state.exhibitionsId;
      }
    }
    // 有路径参数，更新缓存
    else {
      this.$store.commit(
      "state/updateExhibitionsId",
      this.$route.params.exhibitionsId
    );
    exhibitionsId = this.$route.params.exhibitionsId;
    }
    this.getCurrentExhibitionsData(exhibitionsId);
  },
  mounted() {},
  methods: {
    getCurrentExhibitionsData(id) {
      // 根据id及语言获取数据
      this.currentExhibitionsData = getExhibitionsData(id, this.$i18n.locale);
      console.log("this.currentExhibitionsData:", this.currentExhibitionsData);
    },
    navigateTo(path) {
      console.log(path);
      this.$router.push(path); // 或者使用 this.$router.replace(path);
    },
  },
};
</script>

<style scoped>
#container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-grow: 1;
  flex: 1;
}
#section0 {
  height: 70px;
  width: 1024px;
}

#section1 {
  position: relative;
  display: flex;
  flex-direction: row;
  flex-grow: 1;
  justify-content: space-between;
  margin-bottom: 5%;
}
.section1-spacing {
  flex: 0.1875;
}

.section1-current {
  font-size: 13.5px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 15px;
  margin-bottom: 10px;
}
#section1-text {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 0.625;
}
.section1-title {
  font-size: 30px;
  font-family: "AlibabaPuHuiTiH";
  color: #2775b6;
  text-align: center;
  margin-bottom: 20px;
}
.section1-date,
.section1-host {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiB";
  margin-top: 20px;
}
.section1-site,
.section1-subtext {
  font-size: 18px;
  font-family: "AlibabaPuHuiTiR";
  margin-top: 20px;
  margin-bottom: 30px;
}
.section1-subtext{
  text-align: justify;

}
</style>
  