<!---
<script setup>
</script>
-->
<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default{
  mounted() {
  },
  beforeDestroy() {
  },
  methods: {
  }
}
</script>
<style scoped></style>
